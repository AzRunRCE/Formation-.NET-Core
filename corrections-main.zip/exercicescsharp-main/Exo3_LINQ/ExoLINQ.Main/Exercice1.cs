﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExoLINQ.Main
{
    internal class Exercice1 : ExerciceBase
    {
        public Exercice1() { number = 1; name = "Requêtes simples"; }

        protected override void Content()
        {
            List<int> entiers = new List<int> { 4, 5, 2, 3, 1, 1, 0, 5, 8, 9, 10, 15, 16, 20, 21, 4, 5 };

            var query1 = entiers.Where(i => i > 5);
            ConformRequestResult(query1, x => x);

            var query2 =  entiers.Where(i => i >= 15 && i < 20);
            ConformRequestResult(query2, x => x);

            var query3 = entiers.Where(i => i > 2 && i < 20).Where(i => i % 2 == 0).Where(i => i != 8);
            ConformRequestResult(query3, x => x);

            List<string> fruits = new List<string>() { "Banane", "Ananas", "Cerise", "Framboise", "Groseilles", "Pomme", "Poire", "Tomate", "Kiwi", "Raisin", "Mangue", "Datte" };
            var query4 = fruits.Where(x => x.Length > 5);
            ConformRequestResult(query4, x => x);

            var query5 = fruits.Where(x => x.First() == 'P' && x.Length > 4 && x.Contains('o') && !x.Contains('m'));
            ConformRequestResult(query5, x => x);

            var query6 = fruits.OrderBy(x => x.Length);
            ConformRequestResult(query6, x => x);
        }
    }
}
