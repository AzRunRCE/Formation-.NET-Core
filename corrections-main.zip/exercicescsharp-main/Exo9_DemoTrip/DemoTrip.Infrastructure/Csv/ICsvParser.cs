﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoTrip.Infrastructure.Csv
{
    public interface ICsvParser<T>
    {
        char GetSeparator();
        public T Parse(string[] values);
    }
}
