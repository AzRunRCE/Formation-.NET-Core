﻿using Exo7_EF.Core.Interfaces.Core;
using Exo7_EF.Core.Interfaces.Infrastructure;
using Exo7_EF.Core.Entities;
using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using TinyCsvParser;
using Exo7_EF.Infrastructure.Csv.CsvMapping;

namespace Exo7_EF.Infrastructure.Csv.Parser
{
    public class CsvFileParser
    {
        private readonly MyCsvParser<Warehouse> WarehouseParser;
        private readonly MyCsvParser<Customer> CustomerParser;
        private readonly MyCsvParser<Article> ArticleParser;
        private readonly MyCsvParser<Order> OrderParser;
        private readonly MyCsvParser<OrderDetail> OrderDetailParser;

        public List<Warehouse> Warehouses { get; private set; }
        public List<Customer> Customers { get; private set; }
        public List<Article> Articles { get; private set; }
        public List<Order> Orders { get; private set; }
        public List<OrderDetail> OrderDetails { get; private set; }

        public CsvFileParser()
        {
            WarehouseParser = new MyCsvParser<Warehouse>(new CsvWarehouseMapping());
            CustomerParser = new MyCsvParser<Customer>(new CsvCustomerMapping());
            ArticleParser = new MyCsvParser<Article>(new CsvArticleMapping());
            OrderParser = new MyCsvParser<Order>(new CsvOrderMapping());
            OrderDetailParser = new MyCsvParser<OrderDetail>(new CsvOrderDetailMapping());

            Warehouses = [];
            Customers = [];
            Articles = [];
            Orders = [];
            OrderDetails = [];
        }

        public T ParseLine<T>(string line) where T : class
        {
            switch (typeof(T).Name)
            {

                case nameof(Warehouse):
                    return WarehouseParser.ParseLine(line) as T;
                case nameof(Customer):
                    return CustomerParser.ParseLine(line) as T;
                case nameof(Article):
                    return ArticleParser.ParseLine(line) as T;
                case nameof(Order):
                    return OrderParser.ParseLine(line) as T;
                case nameof(OrderDetail):
                    return OrderDetailParser.ParseLine(line) as T;
                default:
                    throw new Exception ($"Could not find a parser of type: {nameof(T)}");
            }
        }

        public string GetLine<T>(T data) where T : class
        {
            switch (typeof(T).Name)
            {

                case nameof(Warehouse):
                    return WarehouseParser.GetLine(data as Warehouse);
                case nameof(Customer):
                    return CustomerParser.GetLine(data as Customer);
                case nameof(Article):
                    return ArticleParser.GetLine(data as Article);
                case nameof(Order):
                    return OrderParser.GetLine(data as Order);
                case nameof(OrderDetail):
                    return OrderDetailParser.GetLine(data as OrderDetail);
                default:
                    throw new Exception($"Could not find a parser of type: {nameof(T)}");
            }
        }

        public void ParseAllFromFile(string[] fileContent)
        {
            string lastTypeDelimiter = "";

            for (int i = 0; i < fileContent.Length; i++)
            {
                if (string.IsNullOrWhiteSpace(fileContent[i]))
                    continue;

                if (fileContent[i][0] == '#')
                {
                    lastTypeDelimiter = fileContent[i];
                    i++;
                }
                else
                {
                    switch (lastTypeDelimiter)
                    {
                        default:
                        case "# Warehouses":
                            Warehouses.Add(WarehouseParser.ParseLine(fileContent[i]));
                            break;
                        case "# Customers":
                            Customers.Add(CustomerParser.ParseLine(fileContent[i]));
                            break;
                        case "# Articles":
                            Articles.Add(ArticleParser.ParseLine(fileContent[i]));
                            break;
                        case "# Orders":
                            Orders.Add(OrderParser.ParseLine(fileContent[i]));
                            break;
                        case "# OrderDetails":
                            OrderDetails.Add(OrderDetailParser.ParseLine(fileContent[i]));
                            break;
                    }
                }
            }
        }
    }
}
