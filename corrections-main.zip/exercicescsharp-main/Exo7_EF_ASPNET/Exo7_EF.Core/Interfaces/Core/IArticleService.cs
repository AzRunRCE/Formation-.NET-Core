﻿using Exo7_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Core.Interfaces.Core
{
    public interface IArticleService
    {
        // Method to add new article
        Task<Article> Add(Article article);

        // Method to Get all artilces
        Task<List<Article>> GetAll();


        // Method to update the stock quantity of an Article
        Task<Article> UpdateArticleStock(int itemId, int quantity);

        // Method to fetch all Articles that are below given stock
        Task<List<Article>> GetArticlesBelowStock(int stock);

        // Method to get total sales for each Article
        Task<Dictionary<Article, int>> GetTotalSalesPerArticle();
    }
}
