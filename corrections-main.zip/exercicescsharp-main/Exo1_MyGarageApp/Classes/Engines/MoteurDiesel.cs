﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGarageApp.Engines
{
    public class MoteurDiesel : Moteur
    {
        public MoteurDiesel(string cylindre, double prix) : base(cylindre, prix)
        {
            type = TypeMoteur.DIESEL;
        }
    }
}
