﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Core.Entities
{
    public class Address : ValueObject
    {
        public string RoadName { get; set; }
        public int PostalCode { get; set; }
        public string City { get; set; }

        public Address() { }

        public Address(string roadName,  int postalCode, string city)
        {
            RoadName = roadName;
            PostalCode = postalCode;
            City = city;
        }

        public override string ToString()
        {
            return $"{RoadName}, {PostalCode} {City}";
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return RoadName;
            yield return PostalCode;
            yield return City;
        }
    }
}
