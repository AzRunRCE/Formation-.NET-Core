﻿using MyGarageApp.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace MyGarageApp.Engines
{
    [JsonDerivedType(typeof(MoteurDiesel), typeDiscriminator: "diesel")]
    [JsonDerivedType(typeof(MoteurElectrique), typeDiscriminator: "electrique")]
    [JsonDerivedType(typeof(MoteurEssence), typeDiscriminator: "essence")]
    [JsonDerivedType(typeof(MoteurHybride), typeDiscriminator: "hybride")]
    public class Moteur
    {
        [JsonInclude]
        protected TypeMoteur type;
        [JsonInclude]
        private string cylindre;
        [JsonInclude]
        private double prix;

        public Moteur(string cylindre, double prix)
        {
            this.cylindre = cylindre;
            this.prix = prix;
        }

        public override string ToString()
        {
            return $"Moteur {type} {cylindre}";
        }

        public double GetPrix()
        {
            return prix;
        }
    }
}
