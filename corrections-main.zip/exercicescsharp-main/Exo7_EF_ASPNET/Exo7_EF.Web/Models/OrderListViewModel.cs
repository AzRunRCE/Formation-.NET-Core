﻿namespace Exo7_EF.Web.Models
{
    public class OrderListViewModel : List<OrderViewModel>
    {
        public OrderListViewModel(IEnumerable<OrderViewModel> collection) : base(collection) { }
        public OrderListViewModel() : base() { }

        public bool IsAllOrderView => WarehouseId == 0;
        public int WarehouseId {  get; internal set; }

        public int CurrentPage {  get; internal set; }
        public int LastPage { get; internal set; }
        public bool CanGoToPreviousPage => CurrentPage > 0;
        public bool CanGoToNextPage => CurrentPage < LastPage - 1;
    }
}
