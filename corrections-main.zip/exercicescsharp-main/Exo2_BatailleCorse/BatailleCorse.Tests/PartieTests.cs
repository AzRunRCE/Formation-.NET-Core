﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BatailleCorse;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatailleCorse.Tests
{
    [TestClass()]
    public class PartieTests
    {
        [TestMethod()]
        public void AjouterJoueur_Ajoute_NbElement_De_Joueurs()
        {
            Partie partieTest = new Partie();
            partieTest.AjouterJoueur(new Joueur("Ronan"));
            Assert.AreEqual(1, partieTest.joueurs.NbElements);
            
            partieTest.AjouterJoueur(new Joueur("Emma"));
            Assert.AreEqual(2, partieTest.joueurs.NbElements);
        }

        [TestMethod()]
        public void AjouterJoueur_Ajoute_Premier_Joueur()
        {
            Partie partieTest = new Partie();
            partieTest.AjouterJoueur(new Joueur("Ronan"));
            partieTest.AjouterJoueur(new Joueur("Emma"));
            partieTest.AjouterJoueur(new Joueur("Julien"));
            Assert.AreEqual("Ronan", partieTest.joueurs.RetirerPremier().Name);
        }

        [TestMethod()]
        [ExpectedException(typeof(Exception))]
        public void DistribuerLesCartes_Lance_Exception_Quand_Pas_De_Joueurs()
        {
            Partie partieTest = new Partie();
            partieTest.DistribuerLesCartesAuxJoueurs();
        }

        [TestMethod()]
        [ExpectedException(typeof(Exception))]
        public void DistribuerLesCartes_Lance_Exception_Quand_Assez_De_Joueurs()
        {
            Partie partieTest = new Partie();
            partieTest.AjouterJoueur(new Joueur("Ronan"));
            partieTest.DistribuerLesCartesAuxJoueurs();
        }

        [TestMethod()]
        public void DistribuerLesCartes_Donne_Cartes_Equitablement_Sur_Joueurs_Pair()
        {
            Partie partieTest = new Partie();
            partieTest.AjouterJoueur(new Joueur("Ronan"));
            partieTest.AjouterJoueur(new Joueur("Emma"));
            partieTest.DistribuerLesCartesAuxJoueurs();
            Assert.AreEqual(16, partieTest.joueurs.RetirerPremier().Cartes.NbElements);
            Assert.AreEqual(16, partieTest.joueurs.RetirerPremier().Cartes.NbElements);
        }

        [TestMethod()]
        public void DistribuerLesCartes_Donne_Cartes_Equitablement_Sur_Joueurs_Impair()
        {
            Partie partieTest = new Partie();
            partieTest.AjouterJoueur(new Joueur("Ronan"));
            partieTest.AjouterJoueur(new Joueur("Emma"));
            partieTest.AjouterJoueur(new Joueur("Julien"));
            partieTest.DistribuerLesCartesAuxJoueurs();
            Assert.AreEqual(10, partieTest.joueurs.RetirerPremier().Cartes.NbElements   );
            Assert.AreEqual(11, partieTest.joueurs.RetirerPremier().Cartes.NbElements);
            Assert.AreEqual(11, partieTest.joueurs.RetirerPremier().Cartes.NbElements);
        }

        [TestMethod()]
        [ExpectedException(typeof(Exception))]
        public void Jouer_Lance_Exception_Quand_Pas_De_Joueurs()
        {
            Partie partieTest = new Partie();
            partieTest.Jouer();
        }

        [TestMethod()]
        [ExpectedException(typeof(Exception))]
        public void Jouer_Lance_Exception_Quand_Assez_De_Joueurs()
        {
            Partie partieTest = new Partie();
            partieTest.AjouterJoueur(new Joueur("Ronan"));
            partieTest.Jouer();
        }

        [TestMethod()]
        public void Jouer_Termine_Sans_Joueur_Remplit_JoueurGagnant_Et_Joueur_Gagnant_A_32_Cartes()
        {           
            Partie partieTest = new Partie();
            partieTest.AjouterJoueur(new Joueur("Ronan"));
            partieTest.AjouterJoueur(new Joueur("Emma"));
            partieTest.DistribuerLesCartesAuxJoueurs();
            partieTest.Jouer();
            Assert.AreEqual(0, partieTest.joueurs.NbElements);
            Assert.IsNotNull(partieTest.GetWinningPlayer());
            Assert.AreEqual(32, partieTest.GetWinningPlayer().Cartes.NbElements);
        }

        [TestMethod()]
        [ExpectedException(typeof(Exception))]
        public void GetWinningPlayer_Lance_Exception_S_Partie_Non_Jouee()
        {
            Partie partieTest = new Partie();
            partieTest.AjouterJoueur(new Joueur("Ronan"));
            partieTest.AjouterJoueur(new Joueur("Emma"));
            partieTest.GetWinningPlayer();
        }




        [TestMethod()]
        public void Defi_2_Cartes()
        {
            Partie partieTest = new Partie();
            Joueur premierJoueur = new Joueur("Ronan");
            premierJoueur.Cartes.AjouterALaFin(new Cartes.Carte(Cartes.Valeur.AS, Cartes.Couleur.PIQUE));

            Joueur secondJoueur = new Joueur("Emma");
            secondJoueur.Cartes.AjouterALaFin(new Cartes.Carte(Cartes.Valeur.SEPT, Cartes.Couleur.COEUR));

            partieTest.AjouterJoueur(premierJoueur);
            partieTest.AjouterJoueur(secondJoueur);

            partieTest.Jouer();

            Assert.AreEqual(2, partieTest.GetWinningPlayer().Cartes.NbElements);
            Assert.AreEqual(premierJoueur, partieTest.GetWinningPlayer());
        }

        [TestMethod()]
        public void Defi_3_Cartes()
        {
            Partie partieTest = new Partie();
            Joueur premierJoueur = new Joueur("Ronan");
            premierJoueur.Cartes.AjouterALaFin(new Cartes.Carte(Cartes.Valeur.AS, Cartes.Couleur.PIQUE));

            Joueur secondJoueur = new Joueur("Emma");
            secondJoueur.Cartes.AjouterALaFin(new Cartes.Carte(Cartes.Valeur.SEPT, Cartes.Couleur.COEUR));
            secondJoueur.Cartes.AjouterALaFin(new Cartes.Carte(Cartes.Valeur.HUIT, Cartes.Couleur.COEUR));

            partieTest.AjouterJoueur(premierJoueur);
            partieTest.AjouterJoueur(secondJoueur);

            partieTest.Jouer();

            Assert.AreEqual(3, partieTest.GetWinningPlayer().Cartes.NbElements);
            Assert.AreEqual(premierJoueur, partieTest.GetWinningPlayer());
        }

        [TestMethod()]
        public void DoubleDefi_4_Cartes()
        {
            Partie partieTest = new Partie();
            Joueur premierJoueur = new Joueur("Ronan");
            premierJoueur.Cartes.AjouterALaFin(new Cartes.Carte(Cartes.Valeur.AS, Cartes.Couleur.PIQUE));
            premierJoueur.Cartes.AjouterALaFin(new Cartes.Carte(Cartes.Valeur.HUIT, Cartes.Couleur.COEUR));
            premierJoueur.Cartes.AjouterALaFin(new Cartes.Carte(Cartes.Valeur.HUIT, Cartes.Couleur.COEUR));

            Joueur secondJoueur = new Joueur("Emma");
            secondJoueur.Cartes.AjouterALaFin(new Cartes.Carte(Cartes.Valeur.ROI, Cartes.Couleur.COEUR));

            partieTest.AjouterJoueur(premierJoueur);
            partieTest.AjouterJoueur(secondJoueur);

            partieTest.Jouer();

            Assert.AreEqual(4, partieTest.GetWinningPlayer().Cartes.NbElements);
            Assert.AreEqual(secondJoueur, partieTest.GetWinningPlayer());
        }

        [TestMethod()]
        public void JoueurActifJoueDerniereCarte_Et_Victoire_DonneCarte_Vainqueur()
        {
            Partie partieTest = new Partie();
            Joueur premierJoueur = new Joueur("Ronan");
            premierJoueur.Cartes.AjouterALaFin(new Cartes.Carte(Cartes.Valeur.DIX, Cartes.Couleur.PIQUE));

            Joueur secondJoueur = new Joueur("Emma");
            secondJoueur.Cartes.AjouterALaFin(new Cartes.Carte(Cartes.Valeur.SEPT, Cartes.Couleur.COEUR));

            partieTest.AjouterJoueur(premierJoueur);
            partieTest.AjouterJoueur(secondJoueur);

            partieTest.Jouer();

            Assert.AreEqual(2, partieTest.GetWinningPlayer().Cartes.NbElements);
            Assert.AreEqual(secondJoueur, partieTest.GetWinningPlayer());
        }

    }
}