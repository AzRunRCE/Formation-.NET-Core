﻿using Ardalis.Specification;
using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Interfaces.Infrastructure;
using Exo7_EF.Core.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Tests.Services
{
    [TestClass]
    public class ArticleServiceTests
    {
        [TestMethod]
        public void CanCreateService()
        {
            var service = new ArticleService(new Mock<IRepositoryBase<Article>>().Object, new Mock<IRepositoryBase<Order>>().Object);

            Assert.IsNotNull(service);
        }

        [TestMethod]
        public void Add_Adds_One_Item_In_Repository()
        {
            List<Article> articleRepo = new();
            var articleToAdd = new Article() { Price = 1 };

            var mockRepo = new Mock<IRepositoryBase<Article>>();
            mockRepo.Setup(x => x.AddAsync(It.IsAny<Article>(), default))
                .Callback((Article newArticle, CancellationToken token) => { articleRepo.Add(newArticle); });
            var service = new ArticleService(mockRepo.Object, new Mock<IRepositoryBase<Order>>().Object);

            service.Add(articleToAdd);

            Assert.AreEqual(1, articleRepo.Count);
        }

        [TestMethod]
        public void Add_Returns_Same_Item()
        {
            var service = new ArticleService(GetConfiguredMockRepository().Object, new Mock<IRepositoryBase<Order>>().Object);

            var articleToAdd = new Article() { Price = 1 };
            var addedArticle = service.Add(articleToAdd).Result;

            Assert.AreEqual(articleToAdd, addedArticle);
        }

        [TestMethod]
        public void Add_Adds_Item_With_Same_Id()
        {
            List<Article> articleRepo = new();
            var articleToAdd = new Article() { Id = 8, Price = 1 };

            var mockRepo = new Mock<IRepositoryBase<Article>>();
            mockRepo.Setup(x => x.AddAsync(It.IsAny<Article>(), default))
                .Callback((Article newArticle, CancellationToken token) => { articleRepo.Add(newArticle); });
            var service = new ArticleService(mockRepo.Object, new Mock<IRepositoryBase<Order>>().Object);

            service.Add(articleToAdd);

            Assert.IsTrue(articleRepo.Any(x => x.Id == articleToAdd.Id));
        }

        [TestMethod]
        public void GetAll_Returns_List_Of_Article_In_Repo()
        {
            List<Article> articleRepo = [new Article() { Id = 8, Price = 1 }];

            var mockRepo = new Mock<IRepositoryBase<Article>>();
            mockRepo.Setup(x => x.ListAsync(default)).ReturnsAsync(articleRepo);
            var service = new ArticleService(mockRepo.Object, new Mock<IRepositoryBase<Order>>().Object);

            var result = service.GetAll().Result;

            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(8, result[0].Id);
        }

        [TestMethod]
        public void GetArticleBelowStock_Returns_List_Article()
        {
            var mockRepo = GetConfiguredMockRepository();
            var service = new ArticleService(mockRepo.Object, new Mock<IRepositoryBase<Order>>().Object);

            var articlesBelowStock = service.GetArticlesBelowStock(5).Result;

            Assert.IsInstanceOfType<IEnumerable<Article>>(articlesBelowStock);
        }

        [TestMethod]
        public void GetArticleBelowStock_Returns_Only_Items_With_Stock_Inferior_To_Parameter()
        {
            var mockRepo = GetConfiguredMockRepository();
            var service = new ArticleService(mockRepo.Object, new Mock<IRepositoryBase<Order>>().Object);
            int stockToEvaluate = 5;

            var articlesBelowStock = service.GetArticlesBelowStock(stockToEvaluate).Result;

            Assert.AreEqual(2, articlesBelowStock.Count());
            Assert.IsFalse(articlesBelowStock.Any(x => x.StockQuantity >= stockToEvaluate));
        }

        [TestMethod]
        public void UpdateArticle_Returns_Article()
        {
            var mockRepo = GetConfiguredMockRepository();
            var service = new ArticleService(mockRepo.Object, new Mock<IRepositoryBase<Order>>().Object);

            var article = service.UpdateArticleStock(1, 40).Result;

            Assert.IsInstanceOfType<Article>(article);
        }

        [TestMethod]
        public void UpdateArticle_Returns_Article_With_Same_Id()
        {
            var mockRepo = GetConfiguredMockRepository();
            var service = new ArticleService(mockRepo.Object, new Mock<IRepositoryBase<Order>>().Object);

            var article = service.UpdateArticleStock(1, 40);

            Assert.AreEqual(1, article.Id);
        }

        [TestMethod]
        public void UpdateArticle_Returns_Article_With_Good_Quantity()
        {
            var mockRepo = GetConfiguredMockRepository();
            var service = new ArticleService(mockRepo.Object, new Mock<IRepositoryBase<Order>>().Object);

            var article = service.UpdateArticleStock(1, 40).Result;

            Assert.AreEqual(40, article.StockQuantity);
            Assert.AreEqual(40, mockRepo.Object.GetByIdAsync(1).Result.StockQuantity);
        }

        [TestMethod]
        public void GetTotalSalesPerArticles_Returns_Dictionnary()
        {
            var mockRepo = GetConfiguredMockRepository();
            var mockOrderRepo = new Mock<IRepositoryBase<Order>>();
            mockOrderRepo.Setup(x => x.ListAsync(default)).ReturnsAsync(new List<Order>());
            var service = new ArticleService(mockRepo.Object, mockOrderRepo.Object);

            var dictionnary = service.GetTotalSalesPerArticle().Result;

            Assert.IsInstanceOfType<Dictionary<Article, int>>(dictionnary);
        }

        [TestMethod]
        public void GetTotalSalesPerArticles_Returns_Articles_In_OrderList()
        {
            var mockRepo = new Mock<IRepositoryBase<Article>>();
            List<Article> articleRepo = new()
            {
                new Article(){ Id = 1, Price=1},
                new Article(){ Id = 2, Price=2},
            };
            mockRepo.Setup(x => x.ListAsync(default)).ReturnsAsync(articleRepo);

            var mockOrderRepo = new Mock<IRepositoryBase<Order>>();
            mockOrderRepo.Setup(x => x.ListAsync(default)).ReturnsAsync(
                new List<Order>()
                {

                new() { OrderDetails =
                [
                    new() {ArticleId = 1, Quantity = 1},
                    new() {ArticleId = 2, Quantity = 5}
                ] },
                new() { OrderDetails =
                [
                    new() {ArticleId = 1, Quantity = 2}
                ] },
                new(){ OrderDetails =
                [
                    new() { ArticleId = 2, Quantity = 3}
                ] }
                }
            );

            var service = new ArticleService(mockRepo.Object, mockOrderRepo.Object);

            var dictionnary = service.GetTotalSalesPerArticle().Result;

            Assert.AreEqual(2, dictionnary.Count);
            Assert.AreEqual(3, dictionnary[mockRepo.Object.ListAsync(default).Result.First(x => x.Id == 1)]);
            Assert.AreEqual(8, dictionnary[mockRepo.Object.ListAsync(default).Result.First(x => x.Id == 2)]);
        }

        private Mock<IRepositoryBase<Article>> GetConfiguredMockRepository()
        {
            var mockRepo = new Mock<IRepositoryBase<Article>>();
            List<Article> articleRepo = new()
            {
                new Article(){ Id = 1, StockQuantity = 1, Price=1},
                new Article(){ Id = 2, StockQuantity = 4, Price=3},
                new Article(){ Id = 3, StockQuantity = 10, Price=5},
                new Article(){ Id = 4, StockQuantity = 30, Price=7},
            };
            mockRepo.Setup(x => x.ListAsync(default)).ReturnsAsync(articleRepo);
            mockRepo.Setup(x => x.GetByIdAsync(It.IsAny<int>(), default)).ReturnsAsync((int x, CancellationToken token) => articleRepo.First(y => y.Id == x));

            mockRepo.Setup(x => x.ListAsync(It.IsAny<Specification<Article>>(), default))
                .ReturnsAsync((Specification<Article> spec, CancellationToken token) => spec.Evaluate(articleRepo).ToList());

            return mockRepo;
        }
    }
}
