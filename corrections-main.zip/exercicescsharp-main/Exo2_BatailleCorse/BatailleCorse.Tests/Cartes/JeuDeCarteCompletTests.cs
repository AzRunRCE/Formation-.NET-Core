﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BatailleCorse.Cartes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatailleCorse.Cartes.Tests
{
    [TestClass()]
    public class JeuDeCarteCompletTests
    {
        [TestMethod()]
        public void GetFreshAndShuffledCardsTest()
        {

            Carte[] jeuMelange = JeuDeCarteComplet.GetFreshAndShuffledCards();

            Carte[] jeuComplet = new Carte[32];
            for (int i = 0; i < (int)Couleur.Length; i++)
            {
                for (int j = 0; j < (int)Valeur.Length; j++)
                {
                    jeuComplet[i * (int)Valeur.Length + j] = new Carte((Valeur)j, (Couleur)i);
                }
            }

            Assert.AreEqual(jeuMelange.Length, jeuComplet.Length);
            CollectionAssert.AreNotEqual(jeuComplet, jeuMelange);
        }
    }
}