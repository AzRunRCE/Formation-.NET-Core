﻿using Exo6_EF.Core.Interfaces.Infrastructure;
using Exo6_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo6_EF.Infrastructure.Repositories
{
    public class SqlCustomerRepository : ICustomerRepository
    {
        private readonly ApplicationDbContext context;

        public SqlCustomerRepository(ApplicationDbContext context) => this.context = context;

        public void Add(Customer toAdd)
        {
            toAdd.Id = 0;
            context.Customers.Add(toAdd);
            context.SaveChanges();
        }

        public void Delete(int id)
        {
            context.Customers.Remove(context.Customers.Find(id));
            context.SaveChanges();
        }

        public IQueryable<Customer> GetAll()
        {
            return context.Customers.AsQueryable();
        }

        public void Update(int id, Customer toUpdate)
        {
            context.Customers.Update(toUpdate);
        }
    }
}
