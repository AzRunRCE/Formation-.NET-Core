﻿using Ardalis.GuardClauses;
using Ardalis.Specification;
using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Facades;
using Exo7_EF.Core.Interfaces.Facades;
using Exo7_EF.Core.Interfaces.Infrastructure;
using Exo7_EF.Core.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Tests.Services
{
    [TestClass]
    public class OrderServiceTests
    {
        [TestMethod]
        public void CanCreateService()
        {
            var service = new OrderService(new Mock<IRepositoryBase<Order>>().Object, new Mock<IOrderSubEntitiesFacade>().Object);

            Assert.IsNotNull(service);
        }

        [TestMethod]
        public void Add_Adds_Something_To_OrdersRepo()
        {
            var mockOrderRepo = new Mock<IRepositoryBase<Order>>();
            List<Order> orderRepo = new();
            mockOrderRepo.Setup(x => x.AddAsync(It.IsAny<Order>(), default))
                .Callback<Order, CancellationToken>((order, token) => orderRepo.Add(order));
            var service = new OrderService(mockOrderRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var result = service.Add(new Order()
            {
                OrderDetails = [new OrderDetail() { Article = new() }],
                ShippingAddress = new Address(),
                Customer = new(),
                Warehouse = new()
            }).Result;

            Assert.AreEqual(1, orderRepo.Count);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception), AllowDerivedTypes = true)]
        public void Add_Without_Details_Returns_Error()
        {
            var mockOrderRepo = new Mock<IRepositoryBase<Order>>();
            List<Order> orderRepo = new();
            mockOrderRepo.Setup(x => x.ListAsync(default)).ReturnsAsync(orderRepo);
            var service = new OrderService(mockOrderRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var result = service.Add(new Order()).Result;
        }

        [TestMethod]
        public void Add_With_Details_Adds_To_DetailRepo()
        {
            var mockOrderRepo = new Mock<IRepositoryBase<Order>>();
            List<Order> orderRepo = new();
            List<OrderDetail> orderDetailRepo = new();
            mockOrderRepo.Setup(x => x.AddAsync(It.IsAny<Order>(), default))
                .Callback<Order, CancellationToken>((x, token) => x.OrderDetails.ForEach(orderDetailRepo.Add));
            var service = new OrderService(mockOrderRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var result = service.Add(new Order()
            {
                OrderDetails = [new OrderDetail() { Article = new() }],
                ShippingAddress = new Address(),
                Customer = new(),
                Warehouse = new()
            }).Result;

            Assert.AreEqual(1, orderDetailRepo.Count);
        }

        [TestMethod]
        public void Add_With_Details_Adds_With_Same_Id()
        {
            var mockOrderRepo = new Mock<IRepositoryBase<Order>>();
            List<Order> orderRepo = new();
            List<OrderDetail> orderDetailRepo = new();
            mockOrderRepo.Setup(x => x.AddAsync(It.IsAny<Order>(), default))
                .Callback<Order, CancellationToken>((x, token) => x.OrderDetails.ForEach(orderDetailRepo.Add));
            var service = new OrderService(mockOrderRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var result = service.Add(new Order()
            {
                OrderDetails = [new OrderDetail() { Id = 1, Article = new() }],
                ShippingAddress = new Address(),
                Customer = new(),
                Warehouse = new()
            }).Result;

            mockOrderRepo.Verify(x => x.AddAsync(It.IsAny<Order>(), default), Times.Once);
            Assert.IsTrue(orderDetailRepo.Any(x => x.Id == 1));
        }

        [TestMethod]
        public void Add_Returns_Same_Item()
        {
            var mockRepo = new Mock<IRepositoryBase<Order>>();
            var orderToAdd = new Order()
            {
                OrderDetails = [new OrderDetail() { Article = new() }],
                ShippingAddress = new Address(),
                Customer = new(),
                Warehouse = new()
            };

            var service = new OrderService(mockRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var orderAdded = service.Add(orderToAdd).Result;

            Assert.AreEqual(orderToAdd, orderAdded);
        }

        [TestMethod]
        public void Add_Adds_Item_With_Same_Id()
        {
            var mockRepo = new Mock<IRepositoryBase<Order>>();
            List<Order> articleRepo = [];
            var orderToAdd = new Order()
            {
                Id = 1,
                OrderDetails = [new OrderDetail() { Article = new() }],
                ShippingAddress = new Address(),
                Customer = new(),
                Warehouse = new()
            };
            mockRepo.Setup(x => x.AddAsync(It.IsAny<Order>(), default)).Callback<Order, CancellationToken>((x, token) => articleRepo.Add(x));

            var service = new OrderService(mockRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var result = service.Add(orderToAdd).Result;

            Assert.IsTrue(articleRepo.Any(x => x.Id == orderToAdd.Id));
        }

        [TestMethod]
        public void Add_WithWarehouseId_Adds_Item_WithWarehouse()
        {
            var mockOrderRepo = new Mock<IRepositoryBase<Order>>();
            List<Order> articleRepo = [];
            var orderToAdd = new Order()
            {
                Id = 1,
                OrderDetails = [new OrderDetail() { Article = new() }],
                ShippingAddress = new Address(),
                Customer = new(),
                WarehouseId = 1
            };
            mockOrderRepo.Setup(x => x.AddAsync(It.IsAny<Order>(), default)).Callback<Order, CancellationToken>((order, token) => articleRepo.Add(order));

            var warehouseList = new List<Warehouse>() { new() { Id = 1 } };

            var mockFacade = new Mock<IOrderSubEntitiesFacade>();
            mockFacade.Setup(x => x.RecoverWarehouseCustomerAndArticleFromRepositories(It.IsAny<Order>()))
                .Callback<Order>(order =>
                {
                    order.Warehouse = warehouseList.First(x => x.Id == order.WarehouseId);
                });


            var service = new OrderService(mockOrderRepo.Object, mockFacade.Object);

            var result = service.Add(orderToAdd).Result;

            Assert.AreEqual(warehouseList.First().Id, articleRepo.First(x => x.Id == orderToAdd.Id).Warehouse.Id);
        }

        [TestMethod]
        public void Add_WithCustomerId_Adds_Item_WithCustomer()
        {
            var mockOrderRepo = new Mock<IRepositoryBase<Order>>();
            List<Order> orderRepo = [];
            var orderToAdd = new Order()
            {
                Id = 1,
                OrderDetails = [new OrderDetail() { Article = new() }],
                ShippingAddress = new Address(),
                CustomerId = 4,
                Warehouse = new()
            };
            mockOrderRepo.Setup(x => x.AddAsync(It.IsAny<Order>(), default)).Callback<Order, CancellationToken>((order, token) => orderRepo.Add(order));

            var customerList = new List<Customer>() { new() { Id = 4 } };

            var mockFacade = new Mock<IOrderSubEntitiesFacade>();
            mockFacade.Setup(x => x.RecoverWarehouseCustomerAndArticleFromRepositories(It.IsAny<Order>()))
                .Callback<Order>(order =>
                {
                    order.Customer = customerList.First(x => x.Id == order.CustomerId);
                });


            var service = new OrderService(mockOrderRepo.Object, mockFacade.Object);

            var result = service.Add(orderToAdd).Result;

            Assert.AreEqual(customerList.First().Id, orderRepo.First(x => x.Id == orderToAdd.Id).Customer.Id);
        }

        [TestMethod]
        public void Update_Changes_Order_With_Same_Id()
        {

            var mockRepo = new Mock<IRepositoryBase<Order>>();
            List<Order> orderList = [new Order()
            {
                Id = 1,
                Email = "Test",
                OrderStatus = "Waiting",
                OrderDetails = [new OrderDetail() { ArticleId = 1 }],
                ShippingAddress = new Address(),
            }];
            mockRepo.Setup(x => x.FirstOrDefaultAsync(It.IsAny<Specification<Order>>(), default))
                .ReturnsAsync((Specification<Order> spec, CancellationToken token) =>
                {
                    return spec.Evaluate(orderList).FirstOrDefault();
                });
            mockRepo.Setup(x => x.UpdateAsync(It.IsAny<Order>(), default))
                .Callback((Order order, CancellationToken token) => { orderList[orderList.FindIndex(x => x.Id == order.Id)] = order; });

            var mockFacade = new Mock<IOrderSubEntitiesFacade>();
            mockFacade.Setup(x => x.RecoverWarehouseCustomerAndArticleFromRepositories(It.IsAny<Order>()))
                .Callback<Order>(order =>
                {
                    order.Warehouse = new();
                    order.Customer = new();
                    order.OrderDetails.ForEach(x => x.Article = new() { Id = 1 });
                });

            var service = new OrderService(mockRepo.Object, mockFacade.Object);

            var editedOrder = new Order()
            {
                Id = 1,
                Email = "Modifie",
                OrderDetails = [new OrderDetail() { ArticleId = 1, UnitPrice = 1 }],
                ShippingAddress = new Address(),
                Warehouse = new(),
                Customer = new()
            };
            var result = service.Update(editedOrder).Result;

            Assert.AreEqual("Modifie", orderList.First().Email);
        }

        [TestMethod]
        public void DeleteOrder_Removes_One_Order_From_Repo()
        {
            int idToDelete = 1;
            var mockRepo = new Mock<IRepositoryBase<Order>>();
            List<Order> orderRepo = new()
            {
                new Order(){ Id = 1},
                new Order(){ Id = 2},
                new Order(){ Id = 3},
                new Order(){ Id = 4}
            };
            mockRepo.Setup(x => x.GetByIdAsync(It.IsAny<int>(), default))
                .ReturnsAsync((int id, CancellationToken token) => orderRepo.FirstOrDefault(x => x.Id == id));
            mockRepo.Setup(x => x.DeleteAsync(It.IsAny<Order>(), default))
                .Callback<Order, CancellationToken>((order, token) => orderRepo.Remove(orderRepo.First(x => x.Id == order.Id)));

            var service = new OrderService(mockRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var result = service.Delete(idToDelete);

            Assert.AreEqual(3, orderRepo.Count);
        }

        [TestMethod]
        public void DeleteOrder_Removes_Order_With_Same_Id()
        {
            int idToDelete = 1;
            var mockRepo = new Mock<IRepositoryBase<Order>>();
            List<Order> orderRepo = new()
            {
                new Order(){ Id = 1},
                new Order(){ Id = 2},
                new Order(){ Id = 3},
                new Order(){ Id = 4}
            };
            mockRepo.Setup(x => x.GetByIdAsync(It.IsAny<int>(), default))
                .ReturnsAsync((int id, CancellationToken token) => orderRepo.FirstOrDefault(x => x.Id == id));
            mockRepo.Setup(x => x.DeleteAsync(It.IsAny<Order>(), default))
                .Callback<Order, CancellationToken>((order, token) => orderRepo.Remove(orderRepo.First(x => x.Id == order.Id)));

            var service = new OrderService(mockRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var result = service.Delete(1);

            Assert.IsFalse(orderRepo.Any(x => x.Id == 1));
        }

        [TestMethod]
        public void GetAllByCustomer_Returns_Order_With_Same_CustomerId()
        {
            var mockRepo = new Mock<IRepositoryBase<Order>>();
            List<Order> orderRepo = new()
            {
                new Order(){ Id = 1, CustomerId=1},
                new Order(){ Id = 2, CustomerId=1},
                new Order(){ Id = 3, CustomerId=2},
                new Order(){ Id = 4, CustomerId=3},
            };
            mockRepo.Setup(x => x.ListAsync(It.IsAny<Specification<Order>>(), default))
                .ReturnsAsync((Specification<Order> spec, CancellationToken token) => spec.Evaluate(orderRepo).ToList());
            var service = new OrderService(mockRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            List<Order> orderList = service.GetAllByCustomerId(1).Result;

            Assert.AreEqual(2, orderList.Count());
            Assert.IsFalse(orderList.Any(x => x.CustomerId != 1));
        }

        [TestMethod]
        public void GetAverageOrderValue_Returns_Double()
        {
            var mockRepo = new Mock<IRepositoryBase<Order>>();
            mockRepo.Setup(x => x.ListAsync(default)).ReturnsAsync(new List<Order>());
            var service = new OrderService(mockRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var retour = service.GetAverageOrderValue().Result;

            Assert.IsInstanceOfType<double>(retour);
        }

        [TestMethod]
        public void GetAverageOrderValue_Returns_Average_From_All_Orders()
        {
            var mockRepo = new Mock<IRepositoryBase<Order>>();
            List<Order> articleRepo = new()
            {
                new Order(){TotalAmount=10},
                new Order(){TotalAmount=20},
                new Order(){TotalAmount=35},
                new Order(){TotalAmount=100},
            };
            mockRepo.Setup(x => x.ListAsync(default)).ReturnsAsync(articleRepo);
            var service = new OrderService(mockRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var retour = service.GetAverageOrderValue().Result;

            Assert.AreEqual(41.25, retour);
        }

        [TestMethod]
        public void GetAverageArticlePerOrder_Returns_Double()
        {
            var mockRepo = new Mock<IRepositoryBase<Order>>();
            mockRepo.Setup(x => x.ListAsync(default)).ReturnsAsync(new List<Order>());
            var service = new OrderService(mockRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var retour = service.GetAverageArticlePerOrder().Result;

            Assert.IsInstanceOfType<double>(retour);
        }

        [TestMethod]
        public void GetAverageArticlePerOrder_Returns_Average_ArticleCount_From_All_Orders()
        {
            var mockRepo = new Mock<IRepositoryBase<Order>>();
            List<Order> orderRepo = new()
            {
                new Order(){OrderDetails = new List<OrderDetail>(){new OrderDetail(), new OrderDetail(), new OrderDetail() } },
                new Order(){OrderDetails = new List<OrderDetail>(){new OrderDetail() }},
                new Order(){OrderDetails = new List<OrderDetail>(){new OrderDetail() }},
                new Order(){OrderDetails = new List<OrderDetail>(){new OrderDetail() , new OrderDetail() }},
            };
            mockRepo.Setup(x => x.ListAsync(default)).ReturnsAsync(orderRepo);
            var service = new OrderService(mockRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var retour = service.GetAverageArticlePerOrder().Result;

            Assert.AreEqual(1.75, retour);
        }

        [TestMethod]
        public void GetAllLight_Returns_List()
        {
            var mockRepo = new Mock<IRepositoryBase<Order>>();
            mockRepo.Setup(x => x.ListAsync(default)).ReturnsAsync(new List<Order>());
            var service = new OrderService(mockRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var retour = service.GetAllLightOrders().Result;

            Assert.IsInstanceOfType<List<Order>>(retour);
        }

        [TestMethod]
        public void GetAllLight_Returns_ElementsInRepo_Without_Data()
        {
            var mockOrderRepo = new Mock<IRepositoryBase<Order>>();
            mockOrderRepo.Setup(x => x.ListAsync(default)).ReturnsAsync([new Order() { WarehouseId = 1, CustomerId = 4 }]);

            var service = new OrderService(mockOrderRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var retour = service.GetAllLightOrders().Result;

            Assert.IsNull(retour[0].Warehouse);
            Assert.IsNull(retour[0].Customer);
        }

        [TestMethod]
        public void GetAllFull_Returns_ElementsInRepo_With_Data()
        {
            var customerList = new List<Customer>() { new() { Id = 4 } };
            var warehouseList = new List<Warehouse>() { new() { Id = 1 } };
            List<Order> orderList = [new Order() { Warehouse = warehouseList[0], Customer = customerList[0] }];

            var mockOrderRepo = new Mock<IRepositoryBase<Order>>();
            mockOrderRepo.Setup(x => x.ListAsync(It.IsAny<Specification<Order>>(), default))
                .ReturnsAsync((Specification<Order> spec, CancellationToken token) =>
                {
                    return spec.Evaluate(orderList).ToList();
                });

            var service = new OrderService(mockOrderRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var retour = service.GetAllFullOrders().Result;

            Assert.IsNotNull(retour[0].Warehouse);
            Assert.IsNotNull(retour[0].Customer);
            Assert.AreEqual(warehouseList[0].Id, retour[0].Warehouse.Id);
            Assert.AreEqual(customerList[0].Id, retour[0].Customer.Id);
        }

        [TestMethod]
        public void GetFullById_Returns_Order()
        {
            var customerList = new List<Customer>() { new() { Id = 4 } };
            var warehouseList = new List<Warehouse>() { new() { Id = 1 } };
            var orderList = new List<Order>() { new() { Id = 2, Warehouse = warehouseList[0], Customer = customerList[0] } };

            var mockOrderRepo = new Mock<IRepositoryBase<Order>>();
            mockOrderRepo.Setup(x => x.FirstOrDefaultAsync(It.IsAny<Specification<Order>>(), default))
                .ReturnsAsync((Specification<Order> spec, CancellationToken token) =>
                {
                    return spec.Evaluate(orderList).FirstOrDefault();
                });

            var service = new OrderService(mockOrderRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var retour = service.GetFullOrderById(2).Result;

            Assert.IsInstanceOfType<Order>(retour);
        }

        [TestMethod]
        public void GetFullById_Returns_Element_With_Data()
        {
            var mockOrderRepo = new Mock<IRepositoryBase<Order>>();
            var customerList = new List<Customer>() { new() { Id = 4 } };
            var warehouseList = new List<Warehouse>() { new() { Id = 1 } };

            var orderList = new List<Order>() { new() { Id = 2, Warehouse = warehouseList[0], Customer = customerList[0] } };
            mockOrderRepo.Setup(x => x.FirstOrDefaultAsync(It.IsAny<Specification<Order>>(), default))
                .ReturnsAsync((Specification<Order> spec, CancellationToken token) =>
                {
                    return spec.Evaluate(orderList).FirstOrDefault();
                });

            var service = new OrderService(mockOrderRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var retour = service.GetFullOrderById(2).Result;

            Assert.IsNotNull(retour.Warehouse);
            Assert.IsNotNull(retour.Customer);
            Assert.AreEqual(warehouseList[0].Id, retour.Warehouse.Id);
            Assert.AreEqual(customerList[0].Id, retour.Customer.Id);
        }

        [TestMethod]
        public void GetFullById_Returns_Element_With_Details()
        {
            var mockOrderRepo = new Mock<IRepositoryBase<Order>>();
            var customerList = new List<Customer>() { new() { Id = 4 } };
            var warehouseList = new List<Warehouse>() { new() { Id = 1 } };
            var articleList = new List<Article>() { new() { Id = 1, Name = "Test" } };

            var orderList = new List<Order>() { new() { Id = 2, Warehouse = warehouseList[0], Customer = customerList[0], OrderDetails = [new() { Article = articleList[0], OrderId = 2, Quantity = 1, UnitPrice = 10 }] } };
            mockOrderRepo.Setup(x => x.FirstOrDefaultAsync(It.IsAny<Specification<Order>>(), default))
                .ReturnsAsync((Specification<Order> spec, CancellationToken token) =>
                {
                    return spec.Evaluate(orderList).FirstOrDefault();
                });

            var service = new OrderService(mockOrderRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var retour = service.GetFullOrderById(2).Result;

            Assert.IsNotNull(retour.OrderDetails);
            Assert.IsNotNull(retour.OrderDetails[0]);
            Assert.AreEqual(articleList[0].Id, retour.OrderDetails[0].Article.Id);
            Assert.AreEqual(articleList[0].Name, retour.OrderDetails[0].Article.Name);
        }

        [TestMethod]
        public void GetFullFromWarehouse_Returns_Items_With_SameWarehouseId()
        {
            var mockOrderRepo = new Mock<IRepositoryBase<Order>>();

            var orderList = new List<Order>() {
                new() { Id = 2, WarehouseId = 1, CustomerId = 1, OrderDetails = [new() { ArticleId = 1, OrderId = 2, Quantity = 1, UnitPrice = 10 }] },
                new() { Id = 3, WarehouseId = 2, CustomerId = 1, OrderDetails = [new() { ArticleId = 1, OrderId = 3, Quantity = 1, UnitPrice = 10 }] }
            };

            mockOrderRepo.Setup(x => x.ListAsync(It.IsAny<Specification<Order>>(), default))
                .ReturnsAsync((Specification<Order> spec, CancellationToken token) =>
                {
                    return spec.Evaluate(orderList).ToList();
                });

            var service = new OrderService(mockOrderRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var retour = service.GetPaginedFullOrdersFromWarehouse(2, 5, 0).Result;

            Assert.IsFalse(retour.Any(x => x.WarehouseId != 2));
            Assert.AreEqual(1, retour.Count);
        }


        [TestMethod]
        public void GetFullFromWarehouse_Returns_All_Items_From_Page()
        {
            var mockOrderRepo = new Mock<IRepositoryBase<Order>>();

            var orderList = new List<Order>() {
                new() { Id = 2, WarehouseId = 1, CustomerId = 1, OrderDetails = [new() { ArticleId = 1, OrderId = 2, Quantity = 1, UnitPrice = 10 }] },
                new() { Id = 3, WarehouseId = 2, CustomerId = 1, OrderDetails = [new() { ArticleId = 1, OrderId = 3, Quantity = 1, UnitPrice = 10 }] }
            };

            mockOrderRepo.Setup(x => x.ListAsync(It.IsAny<Specification<Order>>(), default))
                .ReturnsAsync((Specification<Order> spec, CancellationToken token) =>
                {
                    return spec.Evaluate(orderList).ToList();
                });

            var service = new OrderService(mockOrderRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var retour = service.GetAllPaginedFullOrders(1, 1).Result;

            Assert.AreEqual(1, retour.Count);
            Assert.AreEqual(3, retour[0].Id);
        }

        [TestMethod]
        public void GetCount_Returns_Collection_Size()
        {
            var mockCustomerRepo = new Mock<IRepositoryBase<Order>>();
            var customerList = new List<Order>() { new() { Id = 1 }, new() { Id = 2 } };
            mockCustomerRepo.Setup(x => x.CountAsync(default)).ReturnsAsync(customerList.Count);
            var service = new OrderService(mockCustomerRepo.Object, new Mock<IOrderSubEntitiesFacade>().Object);

            var count = service.GetAllOrderCount().Result;

            Assert.AreEqual(2, count);
        }
    }
}
