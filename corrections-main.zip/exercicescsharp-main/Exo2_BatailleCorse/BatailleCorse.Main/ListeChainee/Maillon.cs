﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatailleCorse.ListeChainee
{
    public class Maillon<T> where T : class
    {
        public readonly T Valeur;
        public Maillon<T> Suivant;
        public Maillon(T valeur, Maillon<T> suivant = null)
        {
            Valeur = valeur;
            Suivant = suivant;
        }
    }
}
