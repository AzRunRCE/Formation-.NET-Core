﻿using Ardalis.Specification;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Specifications
{
    internal class GetFullLivreById : GetAllLivresBase
    {
        public GetFullLivreById(int id)
        {
            GetQueryWithDto().Where(x => x.LivreId == id).Take(1);
        }
    }
}
