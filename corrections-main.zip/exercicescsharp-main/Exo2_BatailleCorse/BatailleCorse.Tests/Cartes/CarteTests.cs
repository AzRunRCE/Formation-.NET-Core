﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BatailleCorse.Cartes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatailleCorse.Cartes.Tests
{
    [TestClass()]
    public class CarteTests
    {
        [TestMethod()]
        public void GetTentativesCountFromCardTest()
        {
            Carte testCard = new Carte(Valeur.SEPT, 0);
            Assert.AreEqual(0, testCard.GetTentativesCountFromCard());

            testCard = new Carte(Valeur.AS, 0);
            Assert.AreEqual(1, testCard.GetTentativesCountFromCard());

            testCard = new Carte(Valeur.ROI, 0);
            Assert.AreEqual(2, testCard.GetTentativesCountFromCard());

            testCard = new Carte(Valeur.DAME, 0);
            Assert.AreEqual(3, testCard.GetTentativesCountFromCard());

            testCard = new Carte(Valeur.VALET, 0);
            Assert.AreEqual(4, testCard.GetTentativesCountFromCard());
        }

        [TestMethod()]
        public void ToStringTest()
        {
            Carte testCard = new Carte(Valeur.NEUF, Couleur.PIQUE);
            Assert.AreEqual("NEUF de PIQUE", testCard.ToString());
        }
    }
}