﻿using Microsoft.AspNetCore.Identity;

namespace Core.Entities
{
    public class Livre
    {
        public int LivreId { get; set; }
        public string Content { get; set; }
        public DateTime CreatedDate { get; set; }
        public AcceptationStatus AcceptationStatus { get; set; }
        public EmpruntStatus EmpruntStatus { get; set; }

        //Id de l'utilisateur propriétaire du livre (issu de la Table AspNetUser)
        public string? UserId { get; set; }

        public virtual IdentityUser? User { get; set; }

    }

    public enum AcceptationStatus
    {
        Submitted,
        Approved,
        Rejected
    }

    public enum EmpruntStatus
    {
        Disponible,
        Emprunte
    }
}
