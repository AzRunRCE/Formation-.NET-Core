﻿namespace GarageManagementWithDotNetCore
{
    public class MaintenanceService : IMaintenanceService
    {
    }
}
