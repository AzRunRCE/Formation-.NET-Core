﻿namespace Exo7_EF.Core.Entities
{
    public enum OrderStatus
    {
        Waiting,
        Processing,
        Shipped,
        Delivered,
        Returned,
        Cancelled,
        Ended
    }
}
