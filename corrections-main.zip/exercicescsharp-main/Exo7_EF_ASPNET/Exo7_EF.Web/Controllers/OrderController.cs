﻿using Ardalis.GuardClauses;
using AutoMapper;
using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Interfaces.Core;
using Exo7_EF.Web.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Exo7_EF.Web.Controllers
{
    public class OrderController : Controller
    {

        private readonly IOrderService orderService;
        private readonly ICustomerService customerService;
        private readonly IWarehouseService warehouseService;
        private readonly IArticleService articleService;
        private readonly IMapper mapper;

        private const int NUMBER_OF_ORDERS_PER_PAGE = 5;

        public OrderController(IOrderService orderService, ICustomerService customerService, IWarehouseService warehouseService, IArticleService articleService, IMapper mapper)
        {
            this.customerService = customerService;
            this.warehouseService = warehouseService;
            this.articleService = articleService;
            this.orderService = orderService;
            this.mapper = mapper;
        }

        // GET: OrderController
        public async Task<IActionResult> Index(int warehouseId, int page)
        {
            List<Order> orderList;
            double ordersInViewCount;

            bool isAllOrderView = warehouseId == 0;

            if (isAllOrderView)
            {
                orderList = await orderService.GetAllPaginedFullOrders(NUMBER_OF_ORDERS_PER_PAGE, page);
                ordersInViewCount = await orderService.GetAllOrderCount();
            }
            else
            {
                orderList = await orderService.GetPaginedFullOrdersFromWarehouse(warehouseId, NUMBER_OF_ORDERS_PER_PAGE, page);
                ordersInViewCount = (await warehouseService.GetWarehouseById(warehouseId)).Orders.Count;
            }

            var orderViewModelList = new OrderListViewModel(orderList
                .Select(mapper.Map<OrderViewModel>))
            {
                WarehouseId = warehouseId
            };

            orderViewModelList.CurrentPage = page;
            orderViewModelList.LastPage = (int)Math.Ceiling(ordersInViewCount / NUMBER_OF_ORDERS_PER_PAGE);

            return View(orderViewModelList);
        }

        // GET: OrderController/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var order = mapper.Map<OrderViewModel>(await orderService.GetFullOrderById(id));
            return View(order);
        }

        // GET: OrderController/Create
        public async Task<IActionResult> Create(int warehouseId)
        {
            var newOrder = new OrderViewModel()
            {
                AvailableArticlesInStock = await GetSelectListFromArticlesInStock(),
                AvailableCustomers = await GetSelectListFromCustomers(),
                WarehouseId = warehouseId
            };

            return View(newOrder);
        }

        // POST: OrderController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(OrderViewModel orderViewModel)
        {
            try
            {
                var order = mapper.Map<Order>(orderViewModel);
                await orderService.Add(order);
                return RedirectToAction(nameof(Index), new { order.WarehouseId });
            }
            catch
            {
                orderViewModel.AvailableArticlesInStock = await GetSelectListFromArticlesInStock();
                return View(orderViewModel);
            }
        }

        // GET: OrderController/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var order = mapper.Map<OrderViewModel>(await orderService.GetFullOrderById(id));
            var articlesInStock = await articleService.GetAll();
            order.AvailableArticlesInStock = await GetSelectListFromArticlesInStock();
            order.AvailableCustomers = await GetSelectListFromCustomers();

            order.OrderDetails.ForEach(detail =>
            {
                detail.MaxQuantity = articlesInStock.First(x => x.Id == detail.ArticleId).StockQuantity;
                detail.CanEditQuantity = order.CanEditQuantity;
            });

            return View(order);
        }

        // POST: OrderController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(OrderViewModel orderViewModel)
        {
            try
            {
                var order = mapper.Map<Order>(orderViewModel);
                await orderService.Update(order);
                return RedirectToAction(nameof(Index), new { warehouseId = orderViewModel.WarehouseId });
            }
            catch
            {
                return RedirectToAction(nameof(Edit), new { id = orderViewModel.Id });
            }
        }

        // GET: OrderController/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var order = mapper.Map<OrderViewModel>(await orderService.GetFullOrderById(id));
            return View(order);
        }

        // POST: OrderController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, int warehouseId)
        {
            try
            {
                await orderService.Delete(id);
                return RedirectToAction(nameof(Index), new { warehouseId });
            }
            catch
            {
                return View(await orderService.GetFullOrderById(id));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> AddArticleToDetail(int articleId, int quantity, int orderId)
        {
            ArticleViewModel item = mapper.Map<ArticleViewModel>((await articleService.GetAll()).First(x => x.Id == articleId));
            OrderDetailViewModel orderDetail = new()
            {
                //DetailId = orderService.GetNextOrderDetailID(),
                OrderId = orderId,

                ArticleId = item.Id,
                ArticleName = item.Name,
                Quantity = quantity,
                UnitPrice = item.Price.ToString(),
                CanEditQuantity = true,
                MaxQuantity = item.StockQuantity,
            };
            return PartialView("~/Views/Shared/EditorTemplates/OrderDetailViewModel.cshtml", orderDetail);
        }

        private async Task<SelectList> GetSelectListFromArticlesInStock()
        {
            return new SelectList((await articleService.GetAll()).Select(mapper.Map<ArticleViewModel>), "Id", "FormattedString");
        }

        private async Task<SelectList> GetSelectListFromCustomers()
        {
            return new SelectList((await customerService.GetAllLight()), "Id", "Name");
        }
    }
}
