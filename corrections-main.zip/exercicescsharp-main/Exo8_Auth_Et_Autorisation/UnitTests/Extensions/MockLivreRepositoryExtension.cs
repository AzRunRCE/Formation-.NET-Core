﻿using Ardalis.Specification;
using Core.Entities;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTests.Extensions
{
    internal static class MockLivreRepositoryExtension
    {
        public static Mock<IRepositoryBase<Livre>> SetupGetByIdAsync(this Mock<IRepositoryBase<Livre>> mock, List<Livre> list)
        {
            MockGenericRepositoryExtension.SetupGetByIdAsync(mock, list, x => x.LivreId);
            return mock;
        }

        public static Mock<IRepositoryBase<Livre>> SetupUpdateAsync(this Mock<IRepositoryBase<Livre>> mock, List<Livre> list)
        {
            MockGenericRepositoryExtension.SetupUpdateAsync(mock, list, x => x.LivreId);
            return mock;
        }
    }
}
