﻿using Ardalis.Specification;
using Exo7_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Core.Specifications
{
    public class GetFullOrderById : Specification<Order>
    {
        public GetFullOrderById(int id)
        {
            Query.Where(x => x.Id == id).Take(1)
                .Include(x => x.OrderDetails).ThenInclude(x => x.Article).AsSplitQuery()
                .Include(x => x.Warehouse)
                .Include(x => x.Customer).AsSplitQuery();
        }
    }
}
