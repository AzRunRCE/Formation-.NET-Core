﻿using System.ComponentModel.DataAnnotations;

namespace Exo7_EF.Web.Models
{
    public class StatisticsViewModel
    {
        [Display(Name = "Articles with low stock")]
        public List<ArticleViewModel> ArticlesUnderStock { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        [Display(Name = "Average order total amount")]
        public double AverageAmountPerOrder { get; set; }

        [Display(Name = "Average order article count")]
        public int AverageArticleCountPerOrder { get; set; }

        [Display(Name = "Best Selling Article")]
        public ArticleViewModel BestSellingArticle { get; set; }

        [Display(Name = "Best Selling Article Count")]
        public int BestSellingArticleCount { get; set; }
    }
}
