﻿using AutoMapper;
using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Services;
using Exo7_EF.Web.Dto;
using Exo7_EF.Web.Models;

namespace Exo7_EF.Web
{
    public class WarehouseMapperProfile : Profile
    {
        public WarehouseMapperProfile()
        {
            CreateMap<Warehouse, WarehouseViewModel>()
                .ForPath(dest => dest.RoadName, opt => opt.MapFrom(src => src.Address.RoadName))
                .ForPath(dest => dest.PostalCode, opt => opt.MapFrom(src => src.Address.PostalCode))
                .ForPath(dest => dest.City, opt => opt.MapFrom(src => src.Address.City));

            CreateMap<WarehouseViewModel, Warehouse>()
                .ForPath(dest => dest.Address.RoadName, opt => opt.MapFrom(src => src.RoadName))
                .ForPath(dest => dest.Address.PostalCode, opt => opt.MapFrom(src => src.PostalCode))
                .ForPath(dest => dest.Address.City, opt => opt.MapFrom(src => src.City));

            CreateMap<Customer, BestCustomerViewModel>()
                .ForMember(dest => dest.FullAddress, opt => opt.MapFrom(src => $"{src.Address.RoadName}, {src.Address.PostalCode} {src.Address.City}"))
                .ForMember(dest => dest.OrdersCount, opt => opt.MapFrom(src => src.Orders.Count))
                .ForMember(dest => dest.TotalAmount, opt => opt.MapFrom(src => src.Orders.Sum(x => x.TotalAmount)))
                .ForMember(dest => dest.AverageAmount, opt => opt.MapFrom(src => src.Orders.Count == 0 ? 0 : src.Orders.Select(x => x.TotalAmount).Average()));

            CreateMap<Article, ArticleViewModel>();
            CreateMap<ArticleViewModel, Article>();

            CreateMap<Order, OrderViewModel>()
                .ForMember(dest => dest.CustomerName, opt => opt.MapFrom(src => src.Customer.Name))
                .ForMember(dest => dest.Shipping_RoadName, opt => opt.MapFrom(src => src.ShippingAddress.RoadName))
                .ForMember(dest => dest.Shipping_PostalCode, opt => opt.MapFrom(src => src.ShippingAddress.PostalCode))
                .ForMember(dest => dest.Shipping_City, opt => opt.MapFrom(src => src.ShippingAddress.City))
                .ForMember(dest => dest.WarehouseName, opt => opt.MapFrom(src => src.Warehouse.Name))
                .ForMember(dest => dest.WarehouseId, opt => opt.MapFrom(src => src.Warehouse.Id))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => Enum.Parse<OrderStatus>(src.OrderStatus)));


            CreateMap<OrderViewModel, Order>()
                .ForMember(dest => dest.CustomerId, opt => opt.MapFrom(src => src.CustomerId))
                .ForMember(dest => dest.ShippingAddress, opt => opt.MapFrom(src => new Address(src.Shipping_RoadName, int.Parse(src.Shipping_PostalCode), src.Shipping_City)))
                .ForMember(dest => dest.WarehouseId, opt => opt.MapFrom(src => src.WarehouseId))
                .ForMember(dest => dest.OrderStatus, opt => opt.MapFrom(src => src.Status.ToString()));

            CreateMap<OrderDetail, OrderDetailViewModel>()
                .ForMember(dest => dest.DetailId, opt => opt.MapFrom(src => src.Id))
                .ReverseMap()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.DetailId))
                .ForMember(dest => dest.Article, opt => opt.Ignore());

            CreateMap<Statistics, StatisticsViewModel>()
                .ForMember(dest => dest.BestSellingArticle, opt => opt.MapFrom(src => src.BestSellingArticle.Key))
                .ForMember(dest => dest.BestSellingArticleCount, opt => opt.MapFrom(src => src.BestSellingArticle.Value));

            CreateMap<Article, ArticleDto>()
                .ForMember(dest => dest.PriceWithCurrency, opt => opt.MapFrom(src => src.Price.ToString("C")));

        }
    }
}
