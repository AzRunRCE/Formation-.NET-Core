﻿using System;
using Microsoft.Extensions.DependencyInjection;

namespace GarageManagementWithDotNetCore
{
    class Program
    {
        static void Main(string[] args)
        {
            var serviceProvider = new ServiceCollection()
            .AddSingleton<IVehiculeRepository, SQLVehiculeRepository>()
            .AddSingleton<IVehiculeService, VehiculeService>()
            .AddSingleton<IMaintenanceService, MaintenanceService>()
            .AddSingleton<INotificationService, NotificationService>()
            .AddTransient<ILoggingService, ConsoleLoggingService>()
            .BuildServiceProvider();
            var VehiculeService = serviceProvider.GetService<IVehiculeService>();
            VehiculeService.RegisterVehicule("Toyota Corolla");
            //Console.ReadLine();
        }
    }
}
