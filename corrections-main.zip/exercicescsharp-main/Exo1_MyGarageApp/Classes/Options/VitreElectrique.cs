﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGarageApp.Options
{
    public class VitreElectrique : IOption
    {
        public double GetPrix()
        {
            return 212.35;
        }
    }
}
