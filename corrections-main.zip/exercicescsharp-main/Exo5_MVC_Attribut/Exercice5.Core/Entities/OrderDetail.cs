﻿using System.Diagnostics.CodeAnalysis;

namespace Exercice5.Core.Entities
{
    public class OrderDetail : IEqualityComparer<OrderDetail>
    {
        public int Id { get; set; }


        public int OrderId { get; set; }
        public Order Order { get; set; }

        public int ArticleId { get; set; }
        public Article Article { get; set; }

        public int Quantity { get; set; }

        public decimal UnitPrice { get; set; }

        public bool Equals(OrderDetail? x, OrderDetail? y)
        {
            return x.Quantity == y.Quantity && x.OrderId == y.OrderId && x.Id == y.Id && x.ArticleId == y.ArticleId;
        }

        public int GetHashCode([DisallowNull] OrderDetail obj)
        {
            HashCode hc = new HashCode();
            hc.Add(Id);
            hc.Add(OrderId);
            hc.Add(ArticleId);
            hc.Add(Quantity);
            return hc.ToHashCode();
        }
    }
}
