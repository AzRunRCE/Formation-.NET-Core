﻿using Exo7_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Core.Interfaces.Core
{
    public interface IWarehouseService
    {
        // Method to fetch all warehouses
        Task<List<Warehouse>> GetAllWarehouses();
        Task<Warehouse> Add(Warehouse toAdd);
        Task<Warehouse> GetWarehouseById(int warehouseId);
    }
}
