﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Infrastructure.Data;
using Core.Entities;
using Core.Interfaces.Services;
using Core.Dto;
using AutoMapper;
using Web.Models;
using Microsoft.AspNetCore.Authorization;
using Azure;

namespace TPBiblio.Controllers
{
    public class LivresController : BaseController
    {
        private readonly ILivreService livreService;
        private readonly IMapper mapper;
        private readonly UserManager<IdentityUser> userManager;
        public const string LastListViewedCookieKey = "Last_LivreList_Viewed";

        public LivresController(ILivreService livreService, IMapper mapper, UserManager<IdentityUser> userManager)
        {
            this.livreService = livreService;
            this.mapper = mapper;
            this.userManager = userManager;
        }

        // GET: Livres
        public async Task<IActionResult> Index()
        {
            Response.Cookies.Append(LastListViewedCookieKey, nameof(Index));

            if (User.IsInRole(Roles.BIBLIOTHECAIRE_NAME) || User.IsInRole(Roles.ADMIN_NAME))
            {
                return View((await livreService.GetApproved()).Select(mapper.Map<LivreViewModel>));
            }
            else
                return View((await livreService.GetDisponibles()).Select(mapper.Map<LivreViewModel>));
        }

        public async Task<IActionResult> MyBooks()
        {
            Response.Cookies.Append(LastListViewedCookieKey, nameof(MyBooks));

            return View((await livreService.GetFromUser(GetUser().Result.Id)).Select(mapper.Map<LivreViewModel>));
        }

        [Authorize(Roles = Roles.ADMIN_NAME)]
        public async Task<IActionResult> ListAll()
        {
            Response.Cookies.Append(LastListViewedCookieKey, nameof(ListAll));
            return View((await livreService.GetAllLivres()).Select(mapper.Map<LivreViewModel>));
        }

        [Authorize(Roles = Roles.BIBLIOTHECAIRE_NAME)]
        public async Task<IActionResult> ListSubmissions()
        {
            Response.Cookies.Append(LastListViewedCookieKey, nameof(ListSubmissions));
            return View((await livreService.GetSubmittedLivres()).Select(mapper.Map<LivreViewModel>));
        }

        // GET: Livres/Details/5m
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var livre = await livreService.GetOneWithItsUser(id.Value);
            if (livre == null)
            {
                return NotFound();
            }
            return View(mapper.Map<LivreViewModel>(livre));
        }

        // GET: Livres/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Livres/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(string Content)
        {
            if (ModelState.IsValid)
            {
                var response = await livreService.Create(new CreateLivreRequete(Content, await GetUser()));
                SetNotification($"Successfully created new Livre : {response.LivreId}", NotificationColor.Green);
                return RedirectToAction(nameof(MyBooks));
            }
            else
            {
                SetNotification($"Error creating Livre.", NotificationColor.Red);
                return View(Content);
            }
        }

        // GET: Livres/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var livre = await livreService.GetOne(id.Value);
            if (livre == null)
            {
                return NotFound();
            }
            return View(mapper.Map<LivreViewModel>(livre));
        }

        // POST: Livres/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, string content)
        {
            var livre = await livreService.GetOne(id);

            if (livre == null)
                return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    var response = await livreService.UpdateContent(new UpdateContentLivreRequete(id, content, await GetUser()));
                    SetNotification($"Successfully updated Livre : {response.Content}", NotificationColor.Green);

                    if (Request.Cookies.ContainsKey(LastListViewedCookieKey))
                        return RedirectToAction(Request.Cookies[LastListViewedCookieKey]);
                    else
                        return RedirectToAction(nameof(Index));
                }
                catch (Exception)
                {

                }
            }
            SetNotification($"Error updating Livre.", NotificationColor.Red);
            var livreViewModel = mapper.Map<LivreViewModel>(livre);
            livreViewModel.Content = content;
            return View(livreViewModel);
        }

        // GET: Livres/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var livre = await livreService.GetOne(id.Value);
            if (livre == null)
            {
                return NotFound();
            }

            return View(mapper.Map<LivreViewModel>(livre));
        }

        // POST: Livres/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await livreService.Delete(new DeleteLivreRequete(id, await GetUser()));

            SetNotification($"Successfully deleted your Livre", NotificationColor.Green);
            if (Request.Cookies.ContainsKey(LastListViewedCookieKey))
                return RedirectToAction(Request.Cookies[LastListViewedCookieKey]);
            else
                return RedirectToAction(nameof(Index));
        }

        // POST: Livres/Delete/5
        [Authorize(Roles = Roles.BIBLIOTHECAIRE_NAME)]
        [HttpPost, ActionName("EditEmprunt")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditEmpruntStatus(int id, EmpruntStatus EmpruntStatus)
        {
            var response = await livreService.UpdateEmpruntStatus(new UpdateEmpruntStatusRequete(id, await GetUser(), EmpruntStatus));
            SetNotification($"Successfully updated Livre : {response.Content}", NotificationColor.Green);
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = Roles.BIBLIOTHECAIRE_NAME)]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApproveOrReject(int id, AcceptationStatus status)
        {
            var livre = await livreService.GetOne(id);

            if (livre == null)
                return NotFound();

            if (livre.AcceptationStatus != AcceptationStatus.Submitted)
                return BadRequest();

            var response = await livreService.UpdateAcceptationStatus(new UpdateAcceptationLivreRequete(id, await GetUser(), status));
            SetNotification($"Successfully updated Livre : {response.Content}", NotificationColor.Green);
            return RedirectToAction(nameof(ListSubmissions));
        }

        private async Task<IdentityUser> GetUser()
        {
            return await userManager.GetUserAsync(User);
        }
    }
}
