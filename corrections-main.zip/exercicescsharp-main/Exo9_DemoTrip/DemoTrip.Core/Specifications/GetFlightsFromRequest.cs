﻿using Ardalis.Specification;
using DemoTrip.Core.Dtos;
using DemoTrip.Core.Entities;

namespace DemoTrip.Core.Specifications
{
    internal class GetFlightsFromRequest : Specification<Flight>
    {
        public GetFlightsFromRequest(SearchFlightRequest request) {
            Query.Where(fly => fly.Destination == request.Destination && fly.Origin == request.Origin && fly.DepartureTime >= request.DateFrom);
        }
    }
}