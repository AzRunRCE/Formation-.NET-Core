﻿using DemoTrip.Core.Dtos;
using DemoTrip.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoTrip.Infrastructure.Notifications
{
    public class FakeEmailReservationNotification : IReservationNotification
    {
        public Task NotifyTripBooked(BookTripResponse bookedTripResponse)
        {
            Console.WriteLine($"EMAIL : You have successfully reserved your trip to {bookedTripResponse.Destination}. " +
                $"You will be staying at the hotel {bookedTripResponse.HotelName} " +
                $"for a total price (including flying in) of {bookedTripResponse.TotalPrice:C}");
            return Task.CompletedTask;
        }
    }
}
