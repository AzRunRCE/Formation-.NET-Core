﻿using Ardalis.GuardClauses;
using Exo6_EF.Core.Entities;
using Exo6_EF.Core.Interfaces.Core;
using Exo6_EF.Core.Interfaces.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo6_EF.Core.Services
{
    public class WarehouseService : IWarehouseService
    {
        private readonly IWarehouseRepository warehouseRepository;

        public WarehouseService(IWarehouseRepository warehouseRepository)
        {
            this.warehouseRepository = warehouseRepository;
        }

        public IQueryable<Warehouse> GetAllWarehouses()
        {
            return warehouseRepository.GetAll();
        }

        public Warehouse Add(Warehouse warehouse)
        {
            Validate(warehouse);
            warehouseRepository.Add(warehouse);
            return warehouse;
        }

        private void Validate(Warehouse warehouse)
        {

        }
    }
}
