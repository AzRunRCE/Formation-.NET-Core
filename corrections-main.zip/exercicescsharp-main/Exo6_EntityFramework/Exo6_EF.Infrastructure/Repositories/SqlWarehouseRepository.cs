﻿using Exo6_EF.Core.Interfaces.Infrastructure;
using Exo6_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo6_EF.Infrastructure.Repositories
{
    public class SqlWarehouseRepository : IWarehouseRepository
    {
        private readonly ApplicationDbContext context;

        public SqlWarehouseRepository(ApplicationDbContext context) => this.context = context;

        public void Add(Warehouse warehouse)
        {
            warehouse.Id = 0;
            context.Warehouses.Add(warehouse);
            context.SaveChanges();
        }

        public IQueryable<Warehouse> GetAll()
        {
            return context.Warehouses.AsQueryable();
        }

        public void Update(int id, Warehouse warehouse)
        {
            context.Warehouses.Update(warehouse);
            context.SaveChanges();
        }

        public void Delete(int id)
        {
            context.Warehouses.Remove(context.Warehouses.Find(id));
            context.SaveChanges();
        }
    }
}
