﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exercice5.Core.Entities;

namespace Exercice5.UnitTests
{
    public class ApplicationDbContextMock
    {
        internal static List<Warehouse> Warehouses = new()
                {
                    new Warehouse()
                    {
                        Id = 1,
                        Name = "Entrepot de Paris",
                        Address = "10 rue du csharp",
                        PostalCode = 75000,
                        CodeAccesMD5 = new()
                        {
                            "840e998a22948adf5de39bd4f2b35da7",
                            "74b87337454200d4d33f80c4663dc5e5",
                        },

                    },
                    new Warehouse()
                    {
                        Id = 2,
                        Name = "Entrepot de Rennes",
                        Address = "10 rue du Lac",
                        PostalCode = 35000,
                        CodeAccesMD5 = new()
                        {
                            "840e998a22948adf5de39bd4f2b35da7",
                            "74b87337454200d4d33f80c4663dc5e5",
                        },

                    }
        };

        internal static List<Article> ArticleReferences { get; set; } =
             new List<Article>() {
                new() {
                    Id = 1,
                    Name = "Ordinateur Portable",
                    Description = "Ordinateur portable haute performance",
                    Price = 1200.00m,
                    StockQuantity = 50
                },
                new() {
                    Id = 2,
                    Name = "Smartphone",
                    Description = "Smartphone avec écran AMOLED",
                    Price = 800.00m,
                    StockQuantity = 100
                },
                new() {
                    Id = 3,
                    Name = "Tablette",
                    Description = "Tablette 10 pouces avec stylet",
                    Price = 600.50m,
                    StockQuantity = 30
                }
        };

        internal static List<Order> Orders { get; set; } = new List<Order>()
        {
                new() {
                        Id = 1,
                        WarehouseId = 1,
                        CustomerName = "John Doe",
                        Email = "johndoe@example.com",
                        ShippingAddress = "123 Main Street",
                        OrderDate = DateTime.Now,
                        TotalAmount = 2000.00,
                        Status = OrderStatus.Waiting
                },
               new() {
                    Id = 2,
                    WarehouseId = 1,
                    CustomerName = "John Doe",
                    Email = "bill.gate@example.com",
                    ShippingAddress = "One Microsoft Way",
                    OrderDate = DateTime.Now,
                    TotalAmount = 2000.00,
                    Status = OrderStatus.Processing
            },
               new() {
                    Id = 3,
                    WarehouseId = 2,
                    CustomerName = "John Doe",
                    Email = "bill.gate@example.com",
                    ShippingAddress = "One Microsoft Way",
                    OrderDate = DateTime.Now,
                    TotalAmount = 2000.00,
                    Status = OrderStatus.Processing
            }
        };

        internal static List<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>()
        {
                new() {
                    Id = 1,
                    OrderId = 1,
                    ArticleId = 2,
                    Quantity = 1,
                    UnitPrice = 1200.00m
                },
                new() {
                    Id = 2,
                    OrderId =1,
                    ArticleId = 2,
                    Quantity = 1,
                    UnitPrice = 800.00m
                },
                new() {
                    Id = 3,
                    OrderId =2,
                    ArticleId = 3,
                    Quantity = 1,
                    UnitPrice = 800.00m
                },
                new() {
                    Id = 4,
                    OrderId =3,
                    ArticleId = 3,
                    Quantity = 1,
                    UnitPrice = 800.00m
                }
        };

    }
}

