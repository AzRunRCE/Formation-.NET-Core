﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Exercice5.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exercice5.Core.Entities;
using Exercice5.Core.Interfaces.Infrastructure;
using Exercice5.UnitTests;
using Moq;

namespace Exercice5.Core.Services.Tests
{
    [TestClass()]
    public class WarehouseServiceTests
    {

        [TestMethod()]
        public void GetWarehouses_Returns_All()
        {
            var service = WarehouseServicesSetup();

            var allwarehouses = service.GetWarehouses();

            Assert.AreEqual(2, allwarehouses.Count);
        }

        [TestMethod()]
        public void Add_Adds_With_Same_Id()
        {
            var service = WarehouseServicesSetup();

            service.Add(new Warehouse() { Id = 3, Name = "Test" });
            var addedWarehouse = service.GetWarehouses().First(x => x.Id == 3);

            Assert.AreEqual(3, addedWarehouse.Id);
            Assert.AreEqual("Test", addedWarehouse.Name);
        }

        [TestMethod()]
        public void Remove_Removes_Id_From_Repo()
        {
            var service = WarehouseServicesSetup();

            service.Remove(service.GetWarehouses().First(x => x.Id == 2));

            var allwarehouses = service.GetWarehouses();

            Assert.IsFalse(allwarehouses.Any(x => x.Id == 3));
        }

        [TestMethod()]
        public void GenerateCodeTest()
        {
            var service = WarehouseServicesSetup();

            var code = service.GenerateCode(2);

            Assert.IsInstanceOfType<string>(code);
            Assert.AreEqual(3, service.GetWarehouses().First(x => x.Id == 2).CodeAccesMD5.Count);
        }

        [TestMethod()]
        public void Update_Changes_Warehouse_With_Same_Id()
        {
            var service = WarehouseServicesSetup();

            var code = service.GenerateCode(2);

            var newWarehouse = new Warehouse() { Id = 2, Address = "Testi", Name = "Hangar 501", PostalCode = 45000 };
            service.Update(newWarehouse, code);

            var updatedWarehouse = service.GetWarehouses().First(y => y.Id == 2);

            Assert.AreEqual(2, updatedWarehouse.Id);
            Assert.AreEqual("Testi", updatedWarehouse.Address);
            Assert.AreEqual("Hangar 501", updatedWarehouse.Name);
            Assert.AreEqual(45000, updatedWarehouse.PostalCode);
        }

        [TestMethod()]
        [ExpectedException(typeof(InvalidOperationException))]
        public void Update_Blocks_If_Invalid_Password()
        {
            var service = WarehouseServicesSetup();

            var newWarehouse = new Warehouse() { Id = 2, Address = "Testi", Name = "Hangar 501", PostalCode = 45000 };
            service.Update(newWarehouse, "FAUXMDP");
        }

        private WarehouseService WarehouseServicesSetup()
        {
            var warehouseRepository = new List<Warehouse>(ApplicationDbContextMock.Warehouses);

            var warehousesMock = new Mock<IWarehouseRepository>();
            warehousesMock.Setup(x => x.GetWarehouses()).Returns(warehouseRepository);

            return new WarehouseService(warehousesMock.Object);
        }
    }
}