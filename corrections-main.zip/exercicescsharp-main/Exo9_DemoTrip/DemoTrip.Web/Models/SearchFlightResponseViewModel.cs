﻿using DemoTrip.Core.Entities;

namespace DemoTrip.Web.Models
{
    internal class SearchFlightResponseViewModel
    {
        public List<Flight> Flights { get; set; }
    }
}