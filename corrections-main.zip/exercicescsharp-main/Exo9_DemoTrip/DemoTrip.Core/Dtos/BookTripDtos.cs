﻿namespace DemoTrip.Core.Dtos
{
    public record BookTripRequest(string Origin, string Destination, DateTime DateFrom, DateTime DateTo);
    public record BookTripResponse(bool Success, decimal TotalPrice, string HotelName, string Destination);
}
