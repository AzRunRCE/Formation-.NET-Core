﻿using Exo7_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Core.Interfaces.Core
{
    public interface ICustomerService
    {
        Task<List<Customer>> GetAllLight();
        Task<List<Customer>> GetAllWithOrders();
        Task<List<Customer>> GetBestCustomers(int numberOfCustomerToGet, int pageNumber);
        Task<Customer> Add(Customer customer);
        Task<Customer> UpdateName(int id,  string name);
        Task<Customer> UpdateAddress(int id, Address adress);
        Task DeleteCustomer(int id);
        Task<int> GetCustomerCount();
    }
}
