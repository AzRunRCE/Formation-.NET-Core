﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GarageManagementWithDotNetCore
{
    public interface ILoggingService
    {
        public void Log(string message);
    }
}
