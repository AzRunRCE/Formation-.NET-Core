﻿using Ardalis.Specification;
using Exo7_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Core.Specifications
{
    public class GetFullOrders : Specification<Order>
    {
        public GetFullOrders()
        {
            Query.OrderByDescending(x => x.OrderDate).ThenBy(x => x.TotalAmount).ThenBy(x => x.Id)
                .Include(x => x.OrderDetails).ThenInclude(x => x.Article).AsSplitQuery()
                .Include(x => x.Warehouse)
                .Include(x => x.Customer).AsSplitQuery();
        }
    }
}
