﻿using BatailleCorse.Cartes;
using BatailleCorse.ListeChainee;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatailleCorse
{
    public class Joueur
    {
        public readonly string Name;

        public Anneau<Carte> Cartes;
        
        public Joueur(string name)
        {
            Name = name;
            Cartes = new Anneau<Carte>();
        }

        public bool HasCards()
        {
            return Cartes.NbElements > 0;
        }

        public override string ToString()
        {
            return $"{Name}";
        }

    }
}
