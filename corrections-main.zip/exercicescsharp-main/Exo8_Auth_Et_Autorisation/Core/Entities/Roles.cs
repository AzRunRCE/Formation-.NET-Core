﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Entities
{
    public class Roles
    {
        public const string ADMIN_NAME = "administrator";
        public const int ADMIN_ID = 1;

        public const string BIBLIOTHECAIRE_NAME = "bibliothecaire";
        public const int BIBLIOTHECAIRE_ID = 2;

        public const string MEMBER_NAME = "membre";
        public const int MEMBER_ID = 3;
}
}
