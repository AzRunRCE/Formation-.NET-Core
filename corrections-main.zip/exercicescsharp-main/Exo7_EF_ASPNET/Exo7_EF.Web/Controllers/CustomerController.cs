﻿using AutoMapper;
using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Interfaces.Core;
using Exo7_EF.Web.Models;
using Microsoft.AspNetCore.Mvc;

namespace Exo7_EF.Web.Controllers
{
    public class CustomerController : Controller
    {
        private readonly ICustomerService customerService;
        private readonly IOrderService orderService;
        private readonly IMapper mapper;

        private const int NUMBER_OF_CUSTOMER_PER_PAGE = 3;

        public CustomerController(ICustomerService customerService, IOrderService orderService, IMapper mapper)
        {
            this.customerService = customerService;
            this.orderService = orderService;
            this.mapper = mapper;
        }

        public async Task<IActionResult> BestCustomers(int id)
        {
            var paginedCustomers = await customerService.GetBestCustomers(NUMBER_OF_CUSTOMER_PER_PAGE, id);

            var customers = new BestCustomerListViewModel(paginedCustomers.Select(mapper.Map<BestCustomerViewModel>));
            customers.CurrentPage = id;
            double customerCount = await customerService.GetCustomerCount();
            customers.LastPage = (int)Math.Ceiling(customerCount / NUMBER_OF_CUSTOMER_PER_PAGE);

            return View(customers);
        }
    }
}
