﻿using Exo6_EF.Core.Entities;
using Microsoft.EntityFrameworkCore;

internal class Program
{
    private static void Main(string[] args)
    {
        DisplayAllWarehouses();
        DisplayAllCustomers();
        DisplayAllArticles();
        DisplayAllOrders();
    }


    private static void InsertDefaultData()
    {
        using (var context = new ApplicationDbContext())
        {
            var warehouse = new Warehouse
            {
                Name = "Entrepot de Paris",
                Address = new Address("10 rue du csharp", 75000, "Paris"),
                CodeAccesMD5 = new List<string>
                        {
                             "840e998a22948adf5de39bd4f2b35da7" ,
                           "74b87337454200d4d33f80c4663dc5e5" 
                        }
            };

            var articles = new List<Article>
                    {
                        new Article { Name = "Ordinateur Portable", Description = "Ordinateur portable haute performance", Price = 1200.00m, StockQuantity = 50 },
                        new Article { Name = "Smartphone", Description = "Smartphone avec écran AMOLED", Price = 800.00m, StockQuantity = 100 },
                        new Article { Name = "Tablette", Description = "Tablette 10 pouces avec stylet", Price = 600.00m, StockQuantity = 30 }
                    };

            var orders = new List<Order>
                    {
                        new Order
                        {
                            Warehouse = warehouse,
                            CustomerId = 1,
                            Email = "johndoe@example.com",
                            ShippingAddress = new Address("123 Main Street",75000, "Paris"),
                            OrderDate = DateTime.Now,
                            TotalAmount = 2000.00d,
                            OrderStatus = "Processing",
                            OrderDetails = new List<OrderDetail>
                            {
                                new OrderDetail { Article = articles[1], Quantity = 1, UnitPrice = 1200.00m },
                                new OrderDetail { Article = articles[1], Quantity = 1, UnitPrice = 800.00m }
                            }
                        },
                        new Order
                        {
                            Warehouse = warehouse,
                            CustomerId = 2,
                            Email = "bill.gate@example.com",
                            ShippingAddress = new Address("One Microsoft Way",75000, "Paris"),
                            OrderDate = DateTime.Now,
                            TotalAmount = 2000.00d,
                            OrderStatus = "Processing",
                            OrderDetails = new List<OrderDetail>
                            {
                                new OrderDetail { Article = articles[2], Quantity = 1, UnitPrice = 800.00m }
                            }
                        }
                    };

            context.Warehouses.Add(warehouse);
            context.Warehouses.Add(warehouse);
            context.Articles.AddRange(articles);
            context.Orders.AddRange(orders);
            context.SaveChanges();
        }
    }

    private static void DisplayAllCustomers()
    {
        Console.WriteLine("\r\n=== Customers ===");
        using (var context = new ApplicationDbContext())
        {
            var customers = context.Customers.Include(x => x.Orders).ToList();
            foreach (var customer in customers)
            {
                Console.WriteLine($"  ID: {customer.Id}, Name: {customer.Name}, Address: {customer.Address.RoadName}, PostalCode: {customer.Address.PostalCode}");
                customer.Orders.ForEach(x => Console.WriteLine($"      - Order n° {x.Id} : ordered on {x.OrderDate.ToShortDateString()}, status: {x.OrderStatus})"));
            }
        }
    }

    private static void DisplayAllOrders()
    {
        Console.WriteLine("\r\n=== Orders ===");
        using (var context = new ApplicationDbContext())
        {
            // Use of data duplication is prefered as the data is only here to be readed
            // I left it as SplitQuery as an example
            var orders = context.Orders
                .Include(o => o.Warehouse).AsSplitQuery()
                .Include(o => o.Customer).AsSplitQuery()
                .Include(o => o.OrderDetails)
                .ThenInclude(od => od.Article).AsSplitQuery().ToList();

            foreach (var order in orders)
            {
                Console.WriteLine($"  ID: {order.Id}, Warehouse: {order.Warehouse.Name}, Customer: {order.Customer.Name}, Address: {order.ShippingAddress.RoadName}, {order.ShippingAddress.PostalCode} {order.ShippingAddress.City}, TotalAmount: {order.TotalAmount}, Status: {order.OrderStatus}");
                order.OrderDetails.ForEach(x =>  Console.WriteLine($"      - {x.Article.Name} (quantity: {x.Quantity}, unitPrice: {x.UnitPrice})"));
            }
        }
    }

    private static void DisplayAllWarehouses()
    {
        Console.WriteLine("\r\n=== Warehouses ===");
        using (var context = new ApplicationDbContext())
        {
            var warehouses = context.Warehouses.ToList();
            foreach (var warehouse in warehouses)
            {
                Console.WriteLine($"  ID: {warehouse.Id}, Name: {warehouse.Name}, Address: {warehouse.Address.RoadName}, City: {warehouse.Address.PostalCode} {warehouse.Address.City}");
            }
        }
    }

    private static void DisplayAllArticles()
    {
        Console.WriteLine("\r\n=== Articles ===");
        using (var context = new ApplicationDbContext())
        {
            var articles = context.Articles.ToList();
            foreach (var article in articles)
            {
                Console.WriteLine($"  ID: {article.Id}, Name: {article.Name}, Price: {article.Price}, NbStock: {article.StockQuantity}");
            }
        }
    }
}