using Ardalis.Specification;
using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Interfaces.Infrastructure;
using Exo7_EF.Core.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Exo7_EF.Tests.Services
{
    [TestClass]
    public class WarehouseServiceTest
    {
        [TestMethod]
        public void GetWarehouse_Returns_ListWarehouse()
        {
            var service = SetupServiceWithMockRepo();

            var retour = service.GetAllWarehouses().Result;

            Assert.IsInstanceOfType<IEnumerable<Warehouse>>(retour);
        }

        [TestMethod]
        public void GetWarehouse_Returns_WarehousesInMock()
        {
            var service = SetupServiceWithMockRepo();

            var warehouses = service.GetAllWarehouses().Result;

            Assert.AreEqual(2, warehouses.Count());
            Assert.AreEqual("Entrepot de Paris", warehouses.ToList()[0].Name);
        }

        [TestMethod]
        public void Add_Adds_One_Warehouse()
        {
            var warehouseList = new List<Warehouse>();
            var repoMock = new Mock<IRepositoryBase<Warehouse>>();
            repoMock.Setup(x => x.AddAsync(It.IsAny<Warehouse>(), default))
                .Callback<Warehouse, CancellationToken>((x, token) => warehouseList.Add(x));
            var service = new WarehouseService(repoMock.Object);

            var result = service.Add(new Warehouse()).Result;

            Assert.AreEqual(1, warehouseList.Count);
        }

        [TestMethod]
        public void Add_Adds_Warehouse_WithSame_Id()
        {
            var warehouseList = new List<Warehouse>();
            var repoMock = new Mock<IRepositoryBase<Warehouse>>();
            repoMock.Setup(x => x.AddAsync(It.IsAny<Warehouse>(), default))
                .Callback<Warehouse, CancellationToken>((x, token) => warehouseList.Add(x));
            var service = new WarehouseService(repoMock.Object);

            var result = service.Add(new Warehouse() { Id = 1 }).Result;

            Assert.AreEqual(1, warehouseList[0].Id);
        }

        [TestMethod]
        public void Add_Returns_Warehouse()
        {
            var warehouseList = new List<Warehouse>();
            var warehouseToAdd = new Warehouse();
            var repoMock = new Mock<IRepositoryBase<Warehouse>>();
            repoMock.Setup(x => x.AddAsync(It.IsAny<Warehouse>(), default))
                .Callback<Warehouse, CancellationToken>((x, token) => warehouseList.Add(x));
            var service = new WarehouseService(repoMock.Object);

            var warehouse = service.Add(warehouseToAdd).Result;

            Assert.AreEqual(warehouseToAdd, warehouseList[0]);
        }

        [TestMethod]
        public void GetWarehouseById_Returns_Warehouse_With_Same_Id_And_Its_Orders()
        {
            var service = SetupServiceWithMockRepo();


            var warehouse = service.GetWarehouseById(2).Result;

            Assert.AreEqual(2, warehouse.Id);
            Assert.AreEqual(2, warehouse.Orders.Count);
        }


        private WarehouseService SetupServiceWithMockRepo()
        {
            var repoMock = new Mock<IRepositoryBase<Warehouse>>();
            var warehouseList = new List<Warehouse>()
            {
                new() {
                    Id = 1,
                    Name = "Entrepot de Paris",
                    Address = new Address("10 rue du csharp",75000, "Paris"),
                    Orders = [new() { Id = 1}, new() { Id =2}]
                },


                new() {
                    Id = 2,
                    Name = "Entrepot de Rennes",
                    Address = new Address("20 rue du Test",35000, "Rennes"),
                    Orders = [new() { Id = 3}, new() { Id =4}]
                }
            };
            repoMock.Setup(x => x.ListAsync(default)).ReturnsAsync(warehouseList);
            repoMock.Setup(x => x.FirstOrDefaultAsync(It.IsAny<Specification<Warehouse>>(), default))
                .ReturnsAsync((Specification<Warehouse> spec, CancellationToken token) => {
                    return spec.Evaluate(warehouseList).FirstOrDefault();
                });
            return new WarehouseService(repoMock.Object);
        }
    }
}