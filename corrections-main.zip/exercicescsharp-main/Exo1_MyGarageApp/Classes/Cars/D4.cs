﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGarageApp.Cars
{
    public class D4 : Vehicule
    {
        public D4() : base()
        {
            nomMarque = Marque.TROEN;
        }
    }
}
