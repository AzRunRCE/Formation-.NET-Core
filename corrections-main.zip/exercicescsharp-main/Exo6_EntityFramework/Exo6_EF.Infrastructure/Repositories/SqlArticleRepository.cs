﻿using Exo6_EF.Core.Interfaces.Infrastructure;
using Exo6_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo6_EF.Infrastructure.Repositories
{
    public class SqlArticleRepository : IArticleRepository
    {
        private readonly ApplicationDbContext context;

        public SqlArticleRepository(ApplicationDbContext context) => this.context = context;

        public void Add(Article newArticle)
        {
            newArticle.Id = 0;
            context.Articles.Add(newArticle);
            context.SaveChanges();
        }

        public void Delete(int articleId)
        {
            context.Articles.Remove(context.Articles.First(article => article.Id == articleId));
            context.SaveChanges();
        }

        public IQueryable<Article> GetAll()
        {
            return context.Articles.AsQueryable();
        }

        public void Update(int articleId, Article article)
        {
            context.Articles.Update(article);
            context.SaveChanges();
        }
    }
}
