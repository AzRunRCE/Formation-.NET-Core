﻿using Exo6_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TinyCsvParser.Mapping;

namespace Exo6_EF.Infrastructure.CsvMapping
{
    internal class CsvCustomerMapping : CsvMapping<Customer>
    {
        public CsvCustomerMapping() : base()
        {
            MapProperty(0, x => x.Id);
            MapProperty(1, x => x.Name);
            MapUsing((entity, values) =>
            {
                entity.Address = new Address(values.Tokens[2], int.Parse(values.Tokens[3]), values.Tokens[4]);
                return true;
            });
        }
    }
}
