﻿using Exo7_EF.Core.Entities;
using Exo7_EF.Infrastructure.Csv.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TinyCsvParser.Mapping;

namespace Exo7_EF.Infrastructure.Csv.CsvMapping
{
    internal class CsvOrderDetailMapping : CsvReversibleMapping<OrderDetail>
    {
        public CsvOrderDetailMapping() : base()
        {
            MapProperty(0, x => x.Id);
            MapProperty(1, x => x.OrderId);
            MapProperty(2, x => x.ArticleId);
            MapProperty(3, x => x.Quantity);
            MapProperty(4, x => x.UnitPrice);
        }

        protected override List<object> GetInstanceValues(OrderDetail data)
        {
            return [
                data.Id,
                data.OrderId,
                data.ArticleId,
                data.Quantity,
                data.UnitPrice,
                ];
        }
    }
}
