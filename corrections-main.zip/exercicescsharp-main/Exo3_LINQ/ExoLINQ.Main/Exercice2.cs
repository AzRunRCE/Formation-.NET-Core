﻿using ExoLINQ.Main.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExoLINQ.Main
{
    internal class Exercice2 : ExerciceBase
    {
        public Exercice2() { number = 2; name = "Requêtes sur les objets"; }

        protected override void Content()
        {
            List<Dog> list = new List<Dog>()
                {
                    new Dog("Berger Australien", "Banzaï", 1, 28),
                    new Dog("Berger Australien", "Letto", 3, 30),
                    new Dog("Berger Australien", "Princesse", 8, 32),
                    new Dog("Berger Allemand", "Floyd", 10, 32),
                    new Dog("Caniche", "Igor", 13, 9),
                    new Dog("Labrador", "Swing", 15, 25),
                    new Dog("Teckel", "Wonki", 2, 5),
                    new Dog("Terre Neuve", "Albator", 1, 50),
                    new Dog("Carlin", "Pataud", 13, 10),
                    new Dog("Boxer", "Frank", 6, 25),
                    new Dog("Lévrier Afghan", "Précieuse", 9, 26),
                    new Dog("Yorkshire", "Kakou", 3, 6)
                };

            //1. Récupérer tous les chiens qui sont de la race "Berger Australien"
            var query1 = list.Where(i => i.Race == "Berger Australien");
            ConformRequestResult(query1, x => x.Name);


            //1.5. Récupérer tous les chiens qui sont de la race "Berger Australien" et les trier par leur nom
            var query2 = list.Where(i => i.Race == "Berger Australien").OrderBy(i => i.Name);
            ConformRequestResult(query2, x => x.Name);

            //2. Récupérer tous les chiens âgés de 5 ans et plus, dont la longueur du nom est supérieure à 5 lettres
            var query3 = list.Where(i => i.Age >= 5 && i.Name.Length > 5);
            ConformRequestResult(query3, x => x.Name);

            //2.5 Récupérer tous les chiens âgés de 5 ans et plus, dont la longueur du nom est supérieure à 5 lettres
            //Trier les chiens par leur poids
            var query4 = query3.OrderBy(i => i.Weight);
            ConformRequestResult(query4, x => x.Name);

            //3. Trier les chiens par leur âge (tri décroissant) puis leur poids (tri croissant)
            var query5 = list.OrderByDescending(i => i.Age).ThenBy(i => i.Age);
            ConformRequestResult(query5, x => x.Name);

            //4. Récupérer les noms de chien dont le nom de race tient en un seul mot
            //Leur poids doit être supérieur à 15 kilos
            //Leur nom doit contenir un "i"
            //Trier les chiens par la longueur de leur prénom
            var query6 = list.Where(i => !i.Race.Contains(' ') && i.Weight > 15 && (i.Name.Contains('i') || i.Name.Contains('I')));
            ConformRequestResult(query6, x => x.Name);
        }
    }
}
