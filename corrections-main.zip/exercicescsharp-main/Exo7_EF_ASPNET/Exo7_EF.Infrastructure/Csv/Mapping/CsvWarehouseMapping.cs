﻿using Exo7_EF.Core.Entities;
using Exo7_EF.Infrastructure.Csv.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TinyCsvParser.Mapping;

namespace Exo7_EF.Infrastructure.Csv.CsvMapping
{
    internal class CsvWarehouseMapping : CsvReversibleMapping<Warehouse>
    {
        internal CsvWarehouseMapping() : base()
        {
            MapProperty(0, x => x.Id);
            MapProperty(1, x => x.Name);
            MapUsing((entity, values) =>
            {
                entity.Address = new Address(values.Tokens[2], int.Parse(values.Tokens[3]), values.Tokens[4]);
                return true;
            });
        }

        protected override List<object> GetInstanceValues(Warehouse data)
        {
            return [
                data.Id,
                data.Name,
                data.Address.RoadName,
                data.Address.PostalCode,
                data.Address.City,
                ];
        }
    }
}
