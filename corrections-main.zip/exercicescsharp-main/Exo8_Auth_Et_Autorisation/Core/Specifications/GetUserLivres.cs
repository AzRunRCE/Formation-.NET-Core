﻿using Ardalis.Specification;
using Core.Dto;
using Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Specifications
{
    internal class GetUserLivres : GetAllLivresBase
    {
        public GetUserLivres(string userId)
        {
            GetQueryWithDto().Where(x => x.UserId == userId);
        }
    }
}
