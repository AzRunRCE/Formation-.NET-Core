﻿using DemoTrip.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoTrip.Infrastructure.Csv
{
    public class FlightCsvParser : ICsvParser<Flight>
    {
        public char GetSeparator()
        {
            return ';';
        }

        public Flight Parse(string[] values)
        {
            // Id,Origin,Destination,OriginName,DestinationName,DepartureTime,ArrivalTime,Price
            return new Flight()
            {
                Id = int.Parse(values[0]),
                Origin = values[1],
                Destination = values[2],
                ArrivalTime = DateTime.Parse(values[5]),
                DepartureTime = DateTime.Parse(values[6]),
                Price = decimal.Parse(values[7])
            };
        }
    }
}
