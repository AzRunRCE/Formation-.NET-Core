﻿using System.ComponentModel.DataAnnotations;

namespace Exercice5.MVC_Web.Models.Validation
{
    public class ValidateAmountAttribute : ValidationAttribute
    {
        public ValidateAmountAttribute()
        {
            const string defaultErrorMessage = "Error with negative Amount";
            ErrorMessage ??= defaultErrorMessage;
        }

        protected override ValidationResult? IsValid(object? value,
                                             ValidationContext validationContext)
        {
            if (value == null || string.IsNullOrWhiteSpace(value.ToString()))
            {
                return ValidationResult.Success;
            }

            if (!double.TryParse(value.ToString(), out double valueDouble) || valueDouble < 0)
            {

                return new ValidationResult(
                            FormatErrorMessage(validationContext.DisplayName));
            }

            return ValidationResult.Success;
        }
    }
}
