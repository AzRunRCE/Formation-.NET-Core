﻿using Exo7_EF.Core.Interfaces.Infrastructure;
using Exo7_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Ardalis.Specification;
#if false
namespace Exo7_EF.Infrastructure.Repositories.Sql
{
    public class CsvCustomerRepository : IRepositoryBase<Customer>
    {
        private readonly CsvApplicationDbContext context;

        public CsvCustomerRepository(CsvApplicationDbContext context) => this.context = context;

        public async Task<Customer> AddAsync(Customer toAdd, CancellationToken cancellationToken = default)
        {
            toAdd.Id = 0;
            context.Customers.Add(toAdd);
            await context.SaveAsync();
            return toAdd;
        }

        public Task<IEnumerable<Customer>> AddRangeAsync(IEnumerable<Customer> entities, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<bool> AnyAsync(ISpecification<Customer> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<bool> AnyAsync(CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public IAsyncEnumerable<Customer> AsAsyncEnumerable(ISpecification<Customer> specification)
        {
            throw new NotImplementedException();
        }

        public Task<int> CountAsync(ISpecification<Customer> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<int> CountAsync(CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public async Task DeleteAsync(int id, CancellationToken cancellationToken = default)
        {
            var entity = context.Customers.First(x => x.Id == id);
            context.Customers.Remove(entity);
            await context.SaveAsync();
        }

        public Task DeleteAsync(Customer entity, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task DeleteRangeAsync(IEnumerable<Customer> entities, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task DeleteRangeAsync(ISpecification<Customer> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<Customer?> FirstOrDefaultAsync(ISpecification<Customer> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<TResult?> FirstOrDefaultAsync<TResult>(ISpecification<Customer, TResult> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public async Task<List<Customer>> GetAllAsync()
        {
            return context.Customers.ToList();
        }

        public async Task<List<Customer>> GetAllAsync(Func<IQueryable<Customer>, IQueryable<Customer>> filter)
        {
            return filter(context.Customers.AsQueryable()).ToList();
        }

        public async Task<Customer> GetByIdAsync(int id)
        {
            return context.Customers.First(x => x.Id == id);
        }

        public Task<Customer?> GetByIdAsync<TId>(TId id, CancellationToken cancellationToken = default) where TId : notnull
        {
            throw new NotImplementedException();
        }

        public Task<Customer?> GetBySpecAsync(ISpecification<Customer> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<TResult?> GetBySpecAsync<TResult>(ISpecification<Customer, TResult> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<List<Customer>> ListAsync(CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<List<Customer>> ListAsync(ISpecification<Customer> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<List<TResult>> ListAsync<TResult>(ISpecification<Customer, TResult> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<Customer?> SingleOrDefaultAsync(ISingleResultSpecification<Customer> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<TResult?> SingleOrDefaultAsync<TResult>(ISingleResultSpecification<Customer, TResult> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public async Task UpdateAsync(Customer toUpdate, CancellationToken cancellationToken = default)
        {
            context.Customers[context.Customers.FindIndex(x => x.Id == toUpdate.Id)] =  toUpdate;
            await context.SaveAsync();
        }

        public Task UpdateRangeAsync(IEnumerable<Customer> entities, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }
    }
}
#endif