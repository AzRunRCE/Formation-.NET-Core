﻿using DemoTrip.Core.Entities;

namespace DemoTrip.Web.Models
{
    public class SearchHotelResponseViewModel
    {
        public List<Hotel> Hotels { get; set; }
    }
}
