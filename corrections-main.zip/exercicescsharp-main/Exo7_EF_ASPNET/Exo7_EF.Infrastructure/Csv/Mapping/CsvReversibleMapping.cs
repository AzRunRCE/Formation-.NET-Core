﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using TinyCsvParser;
using TinyCsvParser.Mapping;
using TinyCsvParser.Model;
using TinyCsvParser.Ranges;
using TinyCsvParser.Reflection;
using TinyCsvParser.TypeConverter;

namespace Exo7_EF.Infrastructure.Csv.Mapping
{
    internal abstract class CsvReversibleMapping<TEntity> : CsvMapping<TEntity> where TEntity : class, new()
    {
        private CultureInfo culture = CultureInfo.InvariantCulture;
        public string ReverseMap(char separator, TEntity data)
        {
            StringBuilder sb = new StringBuilder();
            List<object> values = GetInstanceValues(data);

            values.ForEach(x =>
            {
                if (double.TryParse(x.ToString(), out double xAsDouble))
                    sb.Append(xAsDouble.ToString(culture));
                else if (DateTime.TryParse(x.ToString(), out DateTime xAsDateTime))
                    sb.Append(xAsDateTime.ToString("yyyy-MM-dd"));
                else
                    sb.Append(x.ToString());

                sb.Append(separator);
            });

            sb.Remove(sb.Length - 1, 1);

            return sb.ToString();
        }

        protected abstract List<object> GetInstanceValues(TEntity data);
    }
}
