﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Exo7_EF.Web.Models
{
    public class ArticleViewModel
    {
        [HiddenInput(DisplayValue = true)]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal Price { get; set; }

        [Display(Name = "Quantity")]
        public int StockQuantity { get; set; }

        public string FormattedString => $"{Name} ({StockQuantity} en stock, {Price} €)";
    }
}
