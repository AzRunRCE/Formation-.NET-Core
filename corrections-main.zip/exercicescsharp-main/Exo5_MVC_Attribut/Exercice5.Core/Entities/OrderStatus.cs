﻿namespace Exercice5.Core.Entities
{
    public enum OrderStatus
    {
        Waiting,
        Processing,
        Shipped,
        Delivered,
        Ended
    }
}
