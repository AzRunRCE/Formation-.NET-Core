using AutoMapper;
using Exercice5.Core.Entities;
using Exercice5.Core.Interfaces.Core;
using Exercice5.Core.Interfaces.Infrastructure;
using Exercice5.Core.Services;
using Exercice5.Infrastructure;
using Exercice5.Infrastructure.FakeRepositories;
using Exercice5.MVC_Web;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

builder.Services.AddAutoMapper(typeof(WarehouseMapperProfile));

builder.Services
    .AddSingleton<IWarehouseRepository, FakeWarehouseRepository>()
    .AddSingleton<IOrdersRepository, FakeOrdersRepository>()
    .AddSingleton<IOrderDetailsRepository, FakeOrderDetailsRepository>()
    .AddSingleton<IArticleReferencesRepository, FakeArticleReferencesRepository>()
    .AddScoped<IWarehouseService, WarehouseService>()
    .AddScoped<IOrderService, OrderService>()
    .AddTransient<IMapper, Mapper>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Warehouse}/{action=Index}/{id?}");

app.Run();
