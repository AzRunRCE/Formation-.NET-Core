﻿using Ardalis.Specification;
using Exo7_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Core.Specifications
{
    public class GetCustomerByTotalOrderedAmount : Specification<Customer>
    {
        public GetCustomerByTotalOrderedAmount(int numberOfCustomerToGet, int pageNumber)
        {
            Query.OrderByDescending(customer => customer.Orders.Sum(x => x.TotalAmount))
                .ThenBy(customer => customer.Orders.Count)
                .ThenBy(customer => customer.Id)
                .Skip(pageNumber * numberOfCustomerToGet)
                .Take(numberOfCustomerToGet)
                .Include(customer => customer.Orders);
        }
    }
}
