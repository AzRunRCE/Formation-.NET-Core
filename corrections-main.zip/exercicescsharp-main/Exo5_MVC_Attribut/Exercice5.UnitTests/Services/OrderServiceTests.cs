﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Exercice5.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Exercice5.MVC_Web;
using Exercice5.Core.Interfaces.Infrastructure;
using Moq;
using Exercice5.Core.Entities;
using Exercice5.UnitTests;
using static NuGet.Packaging.PackagingConstants;
using Exercice5.MVC_Web.Models;

namespace Exercice5.Core.Services.Tests
{
    [TestClass()]
    public class OrderServiceTests
    {

        private IMapper _mapper;

        [TestInitialize]
        public void SetUp()
        {

        }

        [TestMethod()]
        public void GetOrders_Returns_All_Orders()
        {
            var service = FullServicesSetup();

            var orders = service.GetOrders();

            Assert.IsNotNull(orders);
            Assert.AreEqual(3, orders.Count);
        }

        [TestMethod()]
        public void GetOrdersFromWarehouse_Return_Orders_And_Orders_Have_Same_WarehouseId()
        {
            // Arrange
            const int id = 1;
            var service = FullServicesSetup();

            // Act 
            var orders = service.GetOrdersFromWarehouse(id);

            // Assert
            Assert.IsNotNull(orders);
            Assert.AreEqual(2, orders.Count);
            orders.ForEach(x => Assert.AreEqual(id, x.WarehouseId));
        }

        [TestMethod()]
        public void GetOrdersFromWarehouse_Return_EmptyList_When_No_Orders_In_This_Warehouse()
        {
            var service = FullServicesSetup();

            var orders = service.GetOrdersFromWarehouse(3);

            Assert.IsNotNull(orders);
            Assert.AreEqual(0, orders.Count);
        }

        [TestMethod()]
        public void GetOrderById_Returns_Order_With_SameId()
        {
            const int id = 1;
            var service = FullServicesSetup();

            var order = service.GetOrderById(id);

            Assert.IsNotNull(order);
            Assert.AreEqual(id, order.Id);
        }

        [TestMethod()]
        public void GetOrderDetails_Returns_OrderDetails_And_They_Have_Same_Id()
        {
            const int id = 1;
            var service = FullServicesSetup();

            var orderDetails = service.GetOrderDetailsAssociatedWithOrderId(id);

            Assert.IsNotNull(orderDetails);
            Assert.AreEqual(2, orderDetails.Count);
            orderDetails.ForEach(x => Assert.AreEqual(id, x.OrderId));
        }

        [TestMethod()]
        public void DeleteOrder_Removes_One_Order()
        {
            var service = FullServicesSetup();

            service.DeleteOrderAndItsDetails(service.GetOrderById(1));

            Assert.AreEqual(2, service.GetOrders().Count);
        }

        [TestMethod()]
        public void DeleteOrder_Removes_Order_With_Specified_Id()
        {
            const int id = 1;
            var service = FullServicesSetup();

            service.DeleteOrderAndItsDetails(service.GetOrderById(id));

            Assert.IsNull(service.GetOrders().FirstOrDefault(x => x.Id == id));
        }

        [TestMethod()]
        [ExpectedException(typeof(InvalidOperationException))]
        public void DeleteOrder_Throw_When_Order_Does_Not_Exist()
        {
            var service = FullServicesSetup();

            service.DeleteOrderAndItsDetails(new Order() { Id = 5, WarehouseId = 1 });
        }


        [TestMethod()]
        public void CreateOrder_Adds_One_Order_With_Same_Id_As_Provided()
        {
            var service = FullServicesSetup();

            service.CreateOrderAndItsDetails(new Order()
            {
                Id = 5,
                WarehouseId = 1,
                CustomerName = "John Doe",
                Email = "johndoe@example.com",
                ShippingAddress = "123 Main Street",
                OrderDate = DateTime.Now,
                TotalAmount = 2000.00,
                Status = OrderStatus.Processing,
                OrderDetails = new List<OrderDetail>()
                {
                    new OrderDetail{ ArticleId = 1, Quantity = 1, UnitPrice= 1200, OrderId = 5 }
                }
            });

            Assert.AreEqual(4, service.GetOrders().Count);
            Assert.IsNotNull(service.GetOrderById(5));
        }


        [TestMethod()]
        public void CreateOrder_Recalculate_TotalAmount_And_UnitPrice_Of_Details()
        {
            var service = FullServicesSetup();

            service.CreateOrderAndItsDetails(new Order()
            {
                Id = 5,
                WarehouseId = 1,
                TotalAmount = 0,
                Status = OrderStatus.Processing,
                OrderDetails = new List<OrderDetail>()
                {
                    new OrderDetail{ ArticleId = 1, Quantity = 2, UnitPrice= 1, OrderId = 5 }
                }
            });

            var newOrder = service.GetOrderById(5);
            newOrder.OrderDetails = service.GetOrderDetailsAssociatedWithOrderId(newOrder.Id);

            Assert.AreEqual(2400, newOrder.TotalAmount);
            Assert.AreEqual(1200, newOrder.OrderDetails[0].UnitPrice);
        }

        [TestMethod()]
        [ExpectedException(typeof(Exception), AllowDerivedTypes = true)]
        public void CreateOrder_Throws_If_Negative_Detail_Quantity()
        {
            var service = FullServicesSetup();

            service.CreateOrderAndItsDetails(new Order()
            {
                Id = 5,
                WarehouseId = 1,
                TotalAmount = 0,
                Status = OrderStatus.Processing,
                OrderDetails = new List<OrderDetail>()
                {
                    new OrderDetail{ ArticleId = 1, Quantity = -1, UnitPrice= 1, OrderId = 5 }
                }
            });
        }

        [TestMethod()]
        public void UpdateOrder_Changes_Values_For_Order_With_Same_Id()
        {
            var service = FullServicesSetup();
            var orderToUpdate = new Order() { Id = 1 };
            orderToUpdate.CustomerName = "Roger";
            orderToUpdate.Email = "Test@test.com";
            orderToUpdate.ShippingAddress = "Address Test";
            orderToUpdate.OrderDate = new DateTime(2024, 01, 01);
            orderToUpdate.TotalAmount = 10;
            orderToUpdate.Status = OrderStatus.Processing;
            orderToUpdate.WarehouseId = 2;
            orderToUpdate.OrderDetails = new List<OrderDetail>()
                {
                    new OrderDetail{ ArticleId = 1, Quantity = 1, UnitPrice= 1200, OrderId = 1 }
                };

            service.UpdateOrderAndItsDetails(1, orderToUpdate);

            var newOrder = service.GetOrderById(1);
            Assert.AreEqual(2, newOrder.WarehouseId);
            Assert.AreEqual("Roger", newOrder.CustomerName);
            Assert.AreEqual("Address Test", newOrder.ShippingAddress);
            Assert.AreEqual(new DateTime(2024, 01, 01), newOrder.OrderDate);
            Assert.AreEqual(1200, newOrder.TotalAmount);
            Assert.AreEqual(OrderStatus.Processing, newOrder.Status);
        }

        [TestMethod()]
        public void UpdateOrder_Recalculate_TotalAmount_And_UnitPrice_Of_Details()
        {
            var service = FullServicesSetup();

            var currentOrder = new Order()
            {
                Id = 1,
                WarehouseId = 1,
                TotalAmount = 10,
                Status = OrderStatus.Processing,
                OrderDetails = new List<OrderDetail>()
                {
                    new OrderDetail{ ArticleId = 1, Quantity = 2, UnitPrice= 1, OrderId = 1 }
                }
            };

            service.UpdateOrderAndItsDetails(1, currentOrder);

            var newOrder = service.GetOrderById(1);
            newOrder.OrderDetails = service.GetOrderDetailsAssociatedWithOrderId(newOrder.Id);

            Assert.AreEqual(2400, newOrder.TotalAmount);
            Assert.AreEqual(1200, newOrder.OrderDetails[0].UnitPrice);
        }

        [TestMethod()]
        [ExpectedException(typeof(Exception), AllowDerivedTypes = true)]
        public void UpdateOrder_Throws_If_Negative_Detail_Quantity()
        {
            var service = FullServicesSetup();

            var currentOrder = new Order()
            {
                Id = 1,
                WarehouseId = 1,
                TotalAmount = 10,
                Status = OrderStatus.Processing,
                OrderDetails = new List<OrderDetail>()
                {
                    new OrderDetail{ ArticleId = 1, Quantity = -1, UnitPrice= 1, OrderId = 1 }
                }
            };

            service.UpdateOrderAndItsDetails(1, currentOrder);
        }

        [TestMethod()]
        [ExpectedException(typeof(Exception), AllowDerivedTypes = true)]
        public void UpdateOrder_Throws_If_Order_Does_Not_Exist()
        {
            var service = FullServicesSetup();

            var currentOrder = new Order()
            {
                Id = 5,
                WarehouseId = 1,
                TotalAmount = 10,
                Status = OrderStatus.Processing,
                OrderDetails = new List<OrderDetail>()
                {
                    new OrderDetail{ ArticleId = 1, Quantity = -1, UnitPrice= 1, OrderId = 1 }
                }
            };

            service.UpdateOrderAndItsDetails(1, currentOrder);
        }

        [TestMethod()]
        public void GetStockList_Returns_All_Stock()
        {
            var service = FullServicesSetup();

            var stock = service.GetArticleStockList();

            Assert.AreEqual(3, stock.Count);
        }

        [TestMethod()]
        public void CreateOrderDetail_Create_Same_Detail()
        {
            var service = FullServicesSetup();

            var baseDetail = new OrderDetail()
            {
                OrderId = 4,
                ArticleId = 3,
                Quantity = 10,
                UnitPrice = 600.5m
            };

            service.CreateOrderDetail(baseDetail);

            var detail = service.GetOrderDetailsAssociatedWithOrderId(4).First();

            Assert.AreEqual(baseDetail, detail);
        }

        [TestMethod()]
        [ExpectedException(typeof(InvalidOperationException))]
        public void CreateOrderDetail_Throws_When_Article_Does_Not_Exists()
        {
            var service = FullServicesSetup();

            service.CreateOrderDetail(new OrderDetail()
            {
                OrderId = 3,
                ArticleId = 5,
                Quantity = 10,
                UnitPrice = 600.5m
            });
        }

        [TestMethod()]
        [ExpectedException(typeof(Exception))]
        public void CreateOrderDetail_Throws_When_Not_Enough_Stock()
        {
            var service = FullServicesSetup();

            service.CreateOrderDetail(new OrderDetail()
            {
                OrderId = 3,
                ArticleId = 3,
                Quantity = 50,
                UnitPrice = 600.5m
            });
        }

        [TestMethod()]
        public void GetNextOrderId_Returns_FreeId()
        {
            var service = FullServicesSetup();

            var id = service.GetNextOrderId();

            Assert.AreEqual(4, id);
        }

        [TestMethod()]
        public void GetNextOrderId_Fills_Gaps()
        {
            var service = FullServicesSetup();

            service.DeleteOrderAndItsDetails(service.GetOrderById(2));
            var id = service.GetNextOrderId();

            Assert.AreEqual(2, id);
        }

        [TestMethod()]
        public void GetNextOrderDetailId_Returns_FreeId()
        {
            var service = FullServicesSetup();

            var id = service.GetNextOrderDetailID();

            Assert.AreEqual(5, id);
        }

        [TestMethod()]
        public void GetNextOrderDetailId_Fills_Gaps()
        {
            var service = FullServicesSetup();

            service.DeleteOrderAndItsDetails(service.GetOrderById(2));
            var id = service.GetNextOrderDetailID();

            Assert.AreEqual(3, id);
        }

        private OrderService FullServicesSetup()
        {
            var ordersDb = new List<Order>(ApplicationDbContextMock.Orders);
            var ordersDetailsDb = new List<OrderDetail>(ApplicationDbContextMock.OrderDetails);
            var articlesDb = new List<Article>(ApplicationDbContextMock.ArticleReferences);

            var ordersMock = new Mock<IOrdersRepository>();
            ordersMock.Setup(x => x.GetOrders()).Returns(ordersDb);

            var orderDetailsMock = new Mock<IOrderDetailsRepository>();
            orderDetailsMock.Setup(x => x.GetOrderDetails()).Returns(ordersDetailsDb);

            var articlesMock = new Mock<IArticleReferencesRepository>();
            articlesMock.Setup(x => x.GetArticleReferences()).Returns(articlesDb);

            return new OrderService(ordersMock.Object, orderDetailsMock.Object, articlesMock.Object);
        }
    }
}