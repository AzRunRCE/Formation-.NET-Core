﻿using MyGarageApp.Cars;
using MyGarageApp.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace MyGarageApp
{
    public class Garage
    {
        private List<Vehicule> voitures = new List<Vehicule>();
        private readonly string garageFileName;
        private readonly JsonSerializerOptions jsonOptions = new JsonSerializerOptions { WriteIndented = true };

        public Garage(string garageFileName = "garageData")
        {
            this.garageFileName = garageFileName;
            if (DoesGarageFileExist())
            {
                LoadGarageFile();
            }
            else
            {
                CreateGarageFile();
            }
        }

        public override string ToString()
        {
            if (voitures == null || voitures.Count == 0)
            {
                return GetEmptyGarageString();
            }
            else
            {
                return GetVoitureListAsString();

            }
        }


        public void AddVoiture(Vehicule voit)
        {
            voitures.Add(voit);
            WriteGarageFile();
        }

        private void CreateGarageFile()
        {
            var fileStream = File.Create(garageFileName);
            fileStream.Close();
        }

        private bool DoesGarageFileExist()
        {
            return File.Exists(garageFileName);
        }

        private void LoadGarageFile()
        {
            string fileContent = File.ReadAllText(garageFileName);

            if (fileContent == null || fileContent == string.Empty)
                voitures = new List<Vehicule>();
            else
                voitures = JsonSerializer.Deserialize<List<Vehicule>>(fileContent, jsonOptions);
        }

        private void WriteGarageFile()
        {
            File.WriteAllText(garageFileName, JsonSerializer.Serialize(voitures, jsonOptions));
        }

        private string GetEmptyGarageString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendLine("Aucune voiture sauvegardée !");
            stringBuilder.AppendLine("****************************");
            stringBuilder.AppendLine("*       Garage .NET        *");
            stringBuilder.AppendLine("****************************");
            return stringBuilder.ToString();
        }

        private string GetVoitureListAsString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var voiture in voitures)
            {
                stringBuilder.Append("+ ");
                stringBuilder.AppendLine(voiture.ToString());
            }
            return stringBuilder.ToString();
        }
    }
}
