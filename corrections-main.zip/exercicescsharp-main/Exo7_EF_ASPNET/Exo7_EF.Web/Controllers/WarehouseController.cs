﻿using AutoMapper;
using Exo7_EF.Core.Interfaces.Core;
using Exo7_EF.Web.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Exo7_EF.Web.Controllers
{
    public class WarehouseController : Controller
    {
        private readonly IWarehouseService service;
        private readonly IMapper mapper;

        public WarehouseController(IWarehouseService service, IMapper mapper)
        {
            this.service = service; 
            this.mapper = mapper;
        }

        // GET: WarehouseController
        public async Task<IActionResult> Index()
        {
            return View((await service.GetAllWarehouses()).Select(mapper.Map<WarehouseViewModel>));
        }

        // GET: WarehouseController/Details/5
        public async Task<IActionResult> Details(int id)
        {
            return View(mapper.Map<WarehouseViewModel>((await service.GetAllWarehouses()).First(x => x.Id == id)));
        }
    }
}
