namespace Exercice5.IntegrationTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            // Tester les controllers ?
        }
    }
}