﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autofac;
namespace GarageManagement
{
    public interface IVehiculeRepository
    {
        void AddVehicule(string Vehicule);
    }
    public class SQLVehiculeRepository : IVehiculeRepository
    {
        public void AddVehicule(string Vehicule)
        {
            Console.WriteLine($"Vehicule added: {Vehicule}");
        }
    }
    public interface IVehiculeService
    {
        void RegisterVehicule(string Vehicule);
    }
    public class VehiculeService : IVehiculeService
    {
        private readonly IVehiculeRepository _VehiculeRepository;
        public VehiculeService(IVehiculeRepository VehiculeRepository)
        {
            _VehiculeRepository = VehiculeRepository;
        }
        public void RegisterVehicule(string Vehicule)
        {
            _VehiculeRepository.AddVehicule(Vehicule);
            Console.WriteLine($"Vehicule registered: {Vehicule}");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            var builder = new ContainerBuilder();
            builder.RegisterType<SQLVehiculeRepository>().As<IVehiculeRepository>();
            builder.RegisterType<VehiculeService>().As<IVehiculeService>();
            var container = builder.Build();
            var VehiculeService = container.Resolve<IVehiculeService>();
            VehiculeService.RegisterVehicule("Toyota Corolla");
            Console.ReadLine();
        }
    }
}
