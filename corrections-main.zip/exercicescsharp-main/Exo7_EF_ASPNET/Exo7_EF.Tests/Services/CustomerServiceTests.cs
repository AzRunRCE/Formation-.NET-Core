﻿using Exo7_EF.Core.Interfaces.Infrastructure;
using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ardalis.Specification;

namespace Exo7_EF.Tests.Services
{
    [TestClass]
    public class CustomerServiceTests
    {
        [TestMethod]
        public void Can_Create_Service()
        {
            var mockRepo = new Mock<IRepositoryBase<Customer>>();

            var service = new CustomerService(mockRepo.Object);

            Assert.IsNotNull(service);
        }

        [TestMethod]
        public void Add_Adds_One_Item_To_Repo()
        {
            var customers = new List<Customer>();
            var mockRepo = new Mock<IRepositoryBase<Customer>>();
            mockRepo.Setup(x => x.AddAsync(It.IsAny<Customer>(), default))
                .Callback<Customer, CancellationToken>((x, token) => customers.Add(x))
                .Returns<Customer, CancellationToken>((x, token) => Task.FromResult(x));
           
            var service = new CustomerService(mockRepo.Object);

            var result = service.Add(new Customer()).Result;

            Assert.AreEqual(1, customers.Count);
        }

        [TestMethod]
        public void Add_Adds_Item_With_Same_Id()
        {
            var customers = new List<Customer>();
            var customerToAdd = new Customer() { Id = 1 };
            var mockRepo = new Mock<IRepositoryBase<Customer>>();
            mockRepo.Setup(x => x.AddAsync(It.IsAny<Customer>(), default))
                .Callback<Customer, CancellationToken>((x, token) => customers.Add(x))
                .Returns<Customer, CancellationToken>((x, token) => Task.FromResult(x));
            var service = new CustomerService(mockRepo.Object);

            var result = service.Add(customerToAdd).Result;

            Assert.IsTrue(customers.Any(x => x.Id == 1));
        }

        [TestMethod]
        public void Add_Returns_Same_Item()
        {
            var customerToAdd = new Customer();
            var mockRepo = new Mock<IRepositoryBase<Customer>>();
            var service = new CustomerService(mockRepo.Object);

            var returnedCustomer = service.Add(customerToAdd).Result;

            Assert.AreEqual(customerToAdd, returnedCustomer);
        }

        [TestMethod]
        public void Remove_Removes_One_Item_From_Repo()
        {
            var customers = new List<Customer>() { new() { Id = 1 }, new() { Id = 2 } };
            var mockRepo = new Mock<IRepositoryBase<Customer>>();
            mockRepo.Setup(x => x.DeleteAsync(It.IsAny<Customer>(), default))
                .Callback<Customer, CancellationToken>((x, token) => customers.Remove(x));
            mockRepo.Setup(x => x.GetByIdAsync(It.IsAny<int>(), default))
                .ReturnsAsync((int x, CancellationToken token) => customers.First(y => y.Id == x));
            var service = new CustomerService(mockRepo.Object);

            var result = service.DeleteCustomer(1);

            Assert.AreEqual(1, customers.Count);
        }

        [TestMethod]
        public void Remove_Removes_Item_With_Same_Id()
        {
            var customers = new List<Customer>() { new() { Id = 1 }, new() { Id = 2 } };
            var mockRepo = new Mock<IRepositoryBase<Customer>>();
            mockRepo.Setup(x => x.DeleteAsync(It.IsAny<Customer>(), default))
                .Callback<Customer, CancellationToken>((x, token) => customers.Remove(x));
            mockRepo.Setup(x => x.GetByIdAsync(It.IsAny<int>(), default))
                .ReturnsAsync((int x, CancellationToken token) => customers.First(y => y.Id == x));
            var service = new CustomerService(mockRepo.Object);

            var result = service.DeleteCustomer(2);

            Assert.IsFalse(customers.Any(x => x.Id == 2));
        }

        [TestMethod]
        public void Update_Address_Changes_Address_For_Same_Id()
        {
            var customers = new List<Customer>() { new() { Id = 1, Address = new Address("First", 0, "") }, new() { Id = 2, Address = new Address("Second", 0, "") } };
            var newAddress = new Address("Third", 0, "");
            int idToChange = 2;
            var mockRepo = new Mock<IRepositoryBase<Customer>>();

            mockRepo.Setup(x => x.UpdateAsync(It.IsAny<Customer>(), default))
                .Callback<Customer, CancellationToken>((customer, token) => customers.First(y => y.Id == customer.Id).Address = customer.Address);

            mockRepo.Setup(x => x.GetByIdAsync(It.IsAny<int>(), default))
                .ReturnsAsync((int x, CancellationToken token) => customers.First(y => y.Id == x));

            var service = new CustomerService(mockRepo.Object);

            var result = service.UpdateAddress(idToChange, newAddress);

            mockRepo.Verify(x => x.UpdateAsync(It.IsAny<Customer>(), default), Times.Once);
            Assert.AreEqual(newAddress, customers.First(x => x.Id == idToChange).Address);
        }

        [TestMethod]
        public void Update_Name_Changes_Name_For_Same_Id()
        {
            var customers = new List<Customer>() { new() { Id = 1, Name = "First" }, new() { Id = 2, Name = "Second" } };
            var newName = "Third";
            int idToChange = 1;
            var mockRepo = new Mock<IRepositoryBase<Customer>>();

            mockRepo.Setup(x => x.UpdateAsync(It.IsAny<Customer>(), default))
                .Callback<Customer, CancellationToken>((customer, token) => customers.First(y => y.Id == customer.Id).Address = customer.Address);

            mockRepo.Setup(x => x.GetByIdAsync(It.IsAny<int>(), default))
                .ReturnsAsync((int x, CancellationToken token) => customers.First(y => y.Id == x));

            var service = new CustomerService(mockRepo.Object);

            var result = service.UpdateName(idToChange, newName);

            mockRepo.Verify(x => x.UpdateAsync(It.IsAny<Customer>(), default), Times.Once);
            Assert.AreEqual(newName, customers.First(x => x.Id == idToChange).Name);
        }


        [TestMethod]
        public void GetAllLight_Returns_List()
        {
            var mockRepo = new Mock<IRepositoryBase<Customer>>();
            mockRepo.Setup(x => x.ListAsync(default)).ReturnsAsync(new List<Customer>());
            var service = new CustomerService(mockRepo.Object);

            var retour = service.GetAllLight().Result;

            Assert.IsInstanceOfType<List<Customer>>(retour);
        }

        [TestMethod]
        public void GetAllLight_Returns_ElementsInRepo_Without_Data()
        {
            var mockCustomerRepo = new Mock<IRepositoryBase<Customer>>();
            mockCustomerRepo.Setup(x => x.ListAsync(default)).ReturnsAsync([new Customer() { Id = 4, }]);


            var service = new CustomerService(mockCustomerRepo.Object);

            var retour = service.GetAllLight().Result;

            Assert.IsNull(retour[0].Orders);
        }

        [TestMethod]
        public void GetAllFull_Returns_ElementsInRepo_With_Data()
        {
            var mockCustomerRepo = new Mock<IRepositoryBase<Customer>>();
            var customerList = new List<Customer>() { new() { Id = 4, Orders= [new() { CustomerId = 4 }] } };
            mockCustomerRepo.Setup(x => x.ListAsync(It.IsAny<ISpecification<Customer>>(), default))
                .ReturnsAsync((ISpecification<Customer> spec,CancellationToken token) => spec.Evaluate(customerList).ToList());

            var service = new CustomerService(mockCustomerRepo.Object);

            var retour = service.GetAllWithOrders().Result;

            Assert.IsNotNull(retour[0].Orders);
            Assert.AreEqual(customerList[0].Orders[0].Id, retour[0].Orders[0].Id);
        }

       
        [TestMethod]
        public void GetBestCustomers_Returns_CustomersOrdered_By_TotalAmount_Ordered()
        {
            var mockCustomerRepo = new Mock<IRepositoryBase<Customer>>();
            var customerList = new List<Customer>() { new() { Id = 1, Orders = [new() { TotalAmount = 15 }] }, new() { Id = 2, Orders = [new() { TotalAmount = 10 }, new() { TotalAmount = 10 }] } };

            mockCustomerRepo.Setup(x => x.ListAsync(It.IsAny<ISpecification<Customer>>(), default))
                .ReturnsAsync((ISpecification<Customer> spec, CancellationToken token) =>  spec.Evaluate(customerList).ToList());

            var service = new CustomerService(mockCustomerRepo.Object);

            var retour = service.GetBestCustomers(5, 0).Result;

            Assert.AreEqual(2, retour[0].Id);
            Assert.AreEqual(1, retour[1].Id);
        }

        [TestMethod]
        public void GetCount_Returns_Collection_Size()
        {
            var mockCustomerRepo = new Mock<IRepositoryBase<Customer>>();
            var customerList = new List<Customer>() { new() { Id = 1 }, new() { Id = 2} };
            mockCustomerRepo.Setup(x => x.CountAsync(default)).ReturnsAsync(customerList.Count);
            var service = new CustomerService(mockCustomerRepo.Object);

            var count = service.GetCustomerCount().Result;

            Assert.AreEqual(2, count);
        }
    }
}
