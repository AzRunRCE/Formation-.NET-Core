﻿using DemoTrip.Core.Dtos;

namespace DemoTrip.Core.Interfaces
{
    public interface IBookTripUseCase
    {
        Task<BookTripResponse> Execute(BookTripRequest request);
    }
}
