﻿using Exo6_EF.Core.Interfaces.Core;
using Exo6_EF.Core.Interfaces.Infrastructure;
using Exo6_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ardalis.GuardClauses;

namespace Exo6_EF.Core.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository customerRepository;

        public CustomerService(ICustomerRepository customerRepository) => this.customerRepository = customerRepository;

        public Customer Add(Customer customer)
        {
            Validate(customer);
            customerRepository.Add(customer);
            return customer;
        }

        public void DeleteCustomer(int id)
        {
            customerRepository.Delete(id);
        }

        public Customer UpdateAddress(int id, Address adress)
        {
            var foundCustomer = customerRepository.GetAll().First(x => x.Id == id);
            foundCustomer.Address = adress;
            customerRepository.Update(id, foundCustomer);
            return foundCustomer;
        }

        public Customer UpdateName(int id, string name)
        {
            var foundCustomer = customerRepository.GetAll().First(y => y.Id == id);
            foundCustomer.Name = name;
            customerRepository.Update(id, foundCustomer);
            return foundCustomer;
        }

        private void Validate(Customer customer)
        {

        }

    }
}
