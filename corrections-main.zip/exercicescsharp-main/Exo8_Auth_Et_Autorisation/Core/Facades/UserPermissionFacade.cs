﻿using Ardalis.GuardClauses;
using Ardalis.Specification;
using Core.Entities;
using Core.Exceptions;
using Core.Interfaces.Facades;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Facades
{
    public class UserPermissionFacade : IUserPermissionFacade
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly IRepositoryBase<IdentityUser> userRepository;

        public UserPermissionFacade(UserManager<IdentityUser> userManager, IRepositoryBase<IdentityUser> userRepository)
        {
            this.userManager = userManager;
            this.userRepository = userRepository;
        }

        public async Task<bool> IsAdmin(string userId)
        {
            var foundUser = await userManager.FindByIdAsync(userId);
            return await userManager.IsInRoleAsync(foundUser, Roles.ADMIN_NAME);
        }

        public async Task<bool> IsAdminOrBibliothecaire(string userId)
        {
            var foundUser = await userManager.FindByIdAsync(userId);
            return (await userManager.GetRolesAsync(foundUser)).Any(x => x == Roles.ADMIN_NAME || x == Roles.BIBLIOTHECAIRE_NAME);
        }

        public async Task<bool> IsValidUser(IdentityUser user)
        {
            try
            {
                var userInDb = await userRepository.GetByIdAsync(user.Id);
                Guard.Against.Null(userInDb);

                if (userInDb.NormalizedUserName != user.NormalizedUserName) throw new InvalidUserException();
                if (userInDb.SecurityStamp != user.SecurityStamp) throw new InvalidUserException();
                
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
