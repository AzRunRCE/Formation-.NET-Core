﻿using Exo7_EF.Core.Entities;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Exo7_EF.Web.Models
{
    public class BestCustomerViewModel
    {
        [HiddenInput(DisplayValue = false)]
        public int Id { get; set; }

        public string Name { get; set; }

        [Display(Name = "Address")]
        public string FullAddress { get; set; }

        [Display(Name = "Number of Orders")]
        public int OrdersCount { get; set; }

        [Display(Name = "Total Amount")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public double TotalAmount { get; set; }

        [Display(Name = "Average Amount")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public double AverageAmount { get; set; }
    }
}
