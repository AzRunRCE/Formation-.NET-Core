﻿using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Interfaces.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#if false
namespace Exo7_EF.Infrastructure.Repositories.Csv
{
    public class CsvOrderRepository : IOrderRepository
    {
        private readonly CsvApplicationDbContext context;

        public CsvOrderRepository(CsvApplicationDbContext context) => this.context = context;


        public Task Add(Order newOrder)
        {
            if (context.Orders.Any(x => x.Id == newOrder.Id))
                throw new Exception($"This Id already exist. Use x different ID than {newOrder.Id}");

            context.Orders.Add(newOrder);

            return context.SaveAsync();
        }

        public Task Delete(int id)
        {
            var orderToRemove = context.Orders.First(x => x.Id == id);
            orderToRemove.OrderDetails.ForEach(detail =>
            {
                context.OrderDetails.Remove(detail);
            });
            context.Orders.Remove(orderToRemove);
            return context.SaveAsync();
        }

        public Task<List<Order>> GetAll()
        {
            var orderList = context.Orders.ToList();
            orderList.ForEach(x =>
            {
                x.OrderDetails = context.OrderDetails.Where(detail => detail.OrderId == x.Id).ToList();
                x.OrderDetails.ForEach(detail => detail.Article = context.Articles.First(a => a.Id == detail.ArticleId));
            });
            return Task.FromResult(context.Orders.ToList());
        }

        public Task<List<Order>> GetAll(Func<IQueryable<Order>, IQueryable<Order>> filter)
        {
            return Task.FromResult(filter(context.Orders.AsQueryable()).ToList());
        }

        public Task<Order> GetById(int id)
        {
            var order = context.Orders.First(x => x.Id == id);
            order.OrderDetails = context.OrderDetails.Where(detail => detail.OrderId == order.Id).ToList();
            return Task.FromResult(order);
        }

        public Task Update(int id, Order toUpdate)
        {
            context.Orders[context.Orders.FindIndex(x => x.Id == id)] = toUpdate;
            return context.SaveAsync();
        }
    }
}
#endif