﻿using Exercice5.Core.Entities;

namespace Exercice5.Core.Interfaces.Core
{
    public interface IWarehouseService
    {
        void Add(Warehouse newWarehouse);
        string GenerateCode(int warehouseId);
        List<Warehouse> GetWarehouses();
        void Remove(Warehouse newWarehouse);
        void Update(Warehouse warehouseUpdated, string warehouseCode);
    }
}