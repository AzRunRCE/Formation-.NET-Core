﻿using Exo7_EF.Core.Entities;
using Exo7_EF.Infrastructure.Csv.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TinyCsvParser.Mapping;

namespace Exo7_EF.Infrastructure.Csv.CsvMapping
{
    internal class CsvOrderMapping : CsvReversibleMapping<Order>
    {
        public CsvOrderMapping() : base()
        {
            MapProperty(0, x => x.Id);
            MapProperty(1, x => x.WarehouseId);
            MapProperty(2, x => x.CustomerId);
            MapProperty(3, x => x.Email);
            MapUsing((entity, values) =>
            {
                entity.ShippingAddress = new Address(values.Tokens[4], int.Parse(values.Tokens[5]), values.Tokens[6]);
                return true;
            });
            MapProperty(7, x => x.OrderDate);
            MapProperty(8, x => x.TotalAmount);
            MapProperty(9, x => x.OrderStatus);
        }

        protected override List<object> GetInstanceValues(Order data)
        {
            return [
                data.Id,
                data.WarehouseId,
                data.CustomerId,
                data.Email,
                data.ShippingAddress.RoadName,
                data.ShippingAddress.PostalCode,
                data.ShippingAddress.City,
                data.OrderDate,
                data.TotalAmount,
                data.OrderStatus,
                ];
        }
    }
}
