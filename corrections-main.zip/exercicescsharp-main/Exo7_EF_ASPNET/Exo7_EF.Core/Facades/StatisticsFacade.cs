﻿using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Interfaces.Core;
using Exo7_EF.Core.Interfaces.Facades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Core.Facades
{
    public partial class StatisticsFacade : IStatisticsFacade
    {
        private readonly IOrderService orderService;
        private readonly IArticleService articleService;

        public StatisticsFacade(IOrderService orderService, IArticleService articleService)
        {
            this.orderService = orderService;
            this.articleService = articleService;
        }

        public async Task<Statistics> GetAllStatistics(int stockLimit)
        {
            return new()
            {
                ArticlesUnderStock = await articleService.GetArticlesBelowStock(stockLimit),
                AverageAmountPerOrder = await orderService.GetAverageOrderValue(),
                AverageArticleCountPerOrder = (int)await orderService.GetAverageArticlePerOrder(),
                BestSellingArticle = (await articleService.GetTotalSalesPerArticle())
                    .Aggregate((first, second) => first.Value > second.Value ? first : second)
            };

        }
    }
}
