﻿namespace GarageManagementWithDotNetCore
{
    public class NotificationService : INotificationService
    {
        private readonly ILoggingService _loggingService;

        public NotificationService(ILoggingService loggingService)
        {
            _loggingService = loggingService;
        }

        public void Notify(string notification)
        {
            _loggingService.Log(notification);
        }
    }
}
