﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ExoLINQ.Main.Entities;

namespace ExoLINQ.Main
{
    internal class Exercice3 : ExerciceBase
    {
        public Exercice3() { number = 3; name = "Requêtes créant de nouveaux objets"; }
        protected override void Content()
        {
            List<Personne> personnes = new List<Personne>
            {
                new Personne("Hallyday", "Johnny", false),
                new Personne("Vartan", "Sylvie", false),
                new Personne("Drucker", "Michel", false),
                new Personne("Antoine", "Antoine", true),
                new Personne("Philippe", "Edouard", false),
                new Personne("Demorand", "Patricia", true),
                new Personne("Ulysse", "Margareth", true),
                new Personne("Zenith", "Méryl", true),
                new Personne("Bobo", "Jojo", false)
            };

            //1. Créer un itérable d'ingénieurs, trier par nom, et ensuite par prénom
            var queryIngenieurs = personnes.Where(p => p.Est_ingenieur).OrderBy(p => p.Nom).ThenBy(p => p.Prenom);
            ConformRequestResult(queryIngenieurs, x => $"{x.Nom} {x.Prenom}");


            //2. Récupérer la liste des personnes qui ne sont pas ingénieures.
            var queryTechniciens = personnes.Where(p => !p.Est_ingenieur);
            ConformRequestResult(queryTechniciens, x => $"{x.Nom} {x.Prenom}");


            //3. Créer une liste d'objets anonymes (Ingénieurs + techniciens)
            var queryAnonymous = personnes.Select(p => new { IsInge = p.Est_ingenieur, Trigram = p.Nom[0].ToString() + p.Prenom[0].ToString(), p.Age });
            ConformRequestResult(queryAnonymous, x => $"{x.Trigram} ({x.Age}) : {x.IsInge}");

        }

    }

 }

