﻿using Exercice5.Core.Entities;

namespace Exercice5.Core.Interfaces.Core
{
    public interface IOrderService
    {
        Order GetOrderById(int id);
        List<Order> GetOrders();
        List<Order> GetOrdersFromWarehouse(int warehouseId);
        
        void CreateOrderAndItsDetails(Order newOrder);
        void UpdateOrderAndItsDetails(int id, Order newOrder);
        void DeleteOrderAndItsDetails(Order order);
        
        void CreateOrderDetail(OrderDetail orderDetail);
        List<OrderDetail> GetOrderDetailsAssociatedWithOrderId(int orderId);
        List<Article> GetArticleStockList();

        int GetNextOrderId();
        int GetNextOrderDetailID();
    }
}