﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoTrip.Core.Exceptions
{
    public class CannotBookTripException : Exception
    {
        public CannotBookTripException()
        {
        }

        public CannotBookTripException(string? message) : base(message)
        {
        }
    }
}
