﻿using Exercice5.MVC_Web.Models;
using Exercice5.Core.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Reflection;
using Exercice5.Core.Interfaces.Core;
using AutoMapper;
using Ardalis.GuardClauses;

namespace Exercice5.MVC_Web.Controllers
{
    public class OrderController : Controller
    {
        private readonly IOrderService orderService;
        private readonly IMapper mapper;

        public OrderController(IOrderService orderService, IMapper mapper)
        {
            this.orderService = orderService;
            this.mapper = mapper;
        }

        // GET: OrderController
        public ActionResult Index(int warehouseId)
        {
            ViewData["warehouseId"] = warehouseId;
            var foundOrders = orderService.GetOrdersFromWarehouse(warehouseId).Select(x => mapper.Map<OrderViewModel>(x));
            return View(foundOrders);
        }

        // GET: OrderController/Details/5
        public ActionResult Details(int id)
        {
            var foundOrder = mapper.Map<OrderViewModel>(orderService.GetOrderById(id));
            foundOrder.OrderDetails = new OrderDetailViewModelList(orderService.GetOrderDetailsAssociatedWithOrderId(foundOrder.Id)
                .Select(x =>
                {
                    var orderDetail = mapper.Map<OrderDetailViewModel>(x);
                    orderDetail.CanEditQuantity = false;
                    return orderDetail;
                }));
            return View(foundOrder);
        }

        // GET: OrderController/Create
        public ActionResult Create(int warehouseId)
        {
            var newOrder = new OrderViewModel()
            {
                AvailableArticlesInStock = GetArticlesInStock(),
                WarehouseId = warehouseId,
                Id = orderService.GetNextOrderId()
            };

            return View(newOrder);
        }

        // POST: OrderController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(int warehouseId, OrderViewModel order)
        {
            try
            {
                Guard.Against.Expression(x => !x, ModelState.IsValid, "Model is invalid"); 

                order.WarehouseId = warehouseId;
                orderService.CreateOrderAndItsDetails(mapper.Map<Core.Entities.Order>(order));
                return RedirectToAction(nameof(Index), new { warehouseId });
            }
            catch
            {
                order.AvailableArticlesInStock = GetArticlesInStock();
                order.WarehouseId = warehouseId;
                return View(order);
            }
        }

        // GET: OrderController/Edit/5
        public ActionResult Edit(int id)
        {
            var foundOrder = mapper.Map<OrderViewModel>(orderService.GetOrderById(id));
            var articleStock = orderService.GetArticleStockList();

            foundOrder.OrderDetails = new OrderDetailViewModelList(orderService.GetOrderDetailsAssociatedWithOrderId(foundOrder.Id)
                .Select(x =>
                {
                    var orderDetail = mapper.Map<OrderDetailViewModel>(x);
                    orderDetail.CanEditQuantity = foundOrder.CanEditQuantity;
                    var foundArticle = articleStock.FirstOrDefault(y => y.Id == x.ArticleId);
                    orderDetail.MaxQuantity = foundArticle != null ? foundArticle.StockQuantity : orderDetail.Quantity;
                    return orderDetail;
                }));
            foundOrder.AvailableArticlesInStock = GetArticlesInStock();
            return View(foundOrder);
        }

        // POST: OrderController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, OrderViewModel newOrder)
        {
            var foundOrder = orderService.GetOrderById(id);
            try
            {
                newOrder.WarehouseId = foundOrder.WarehouseId;
                orderService.UpdateOrderAndItsDetails(foundOrder.Id, mapper.Map<Core.Entities.Order>(newOrder));
                return RedirectToAction(nameof(Index), new { warehouseId = foundOrder.WarehouseId });
            }
            catch
            {
                return View(mapper.Map<OrderViewModel>(foundOrder));
            }
        }

        // GET: OrderController/Delete/5
        public ActionResult Delete(int id)
        {
            var foundOrder = mapper.Map<OrderViewModel>(orderService.GetOrderById(id));
            return View(foundOrder);
        }

        // POST: OrderController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Style", "IDE0060:Supprimer le paramètre inutilisé", Justification = "Provient de la signature des actions POST ASP.NEt")]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            var foundOrder = orderService.GetOrderById(id);
            try
            {
                orderService.DeleteOrderAndItsDetails(foundOrder);
                return RedirectToAction(nameof(Index), new { warehouseId = foundOrder.WarehouseId });
            }
            catch
            {
                return View(foundOrder);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddArticleToDetail(int articleId, int quantity, int orderId)
        {
            ArticleViewModel item = mapper.Map<ArticleViewModel>(orderService.GetArticleStockList().First(x => x.Id == articleId));
            OrderDetailViewModel orderDetail = new()
            {
                DetailId = orderService.GetNextOrderDetailID(),
                OrderId = orderId,

                ArticleId = item.Id,
                ArticleName = item.Name,
                Quantity = quantity,
                UnitPrice = item.Price.ToString(),
                CanEditQuantity = true,
                MaxQuantity = item.StockQuantity,
            };
            return PartialView("~/Views/Shared/EditorTemplates/OrderDetailViewModel.cshtml", orderDetail);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult IsStockEnough(int index, int quantity)
        {
            var itemInStock = orderService.GetArticleStockList().First(x => x.Id == index);
            return Ok(itemInStock.StockQuantity > quantity);
        }

        private SelectList GetArticlesInStock()
        {
            return new SelectList(orderService.GetArticleStockList().Select(x => mapper.Map<ArticleViewModel>(x)), "Id", "FormattedString");
        }

    }
}
