﻿using Exo6_EF.Core.Interfaces.Infrastructure;
using Exo6_EF.Core.Entities;
using Exo6_EF.Core.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo6_EF.Tests.Services
{
    [TestClass]
    public class CustomerServiceTests
    {
        [TestMethod]
        public void Can_Create_Service()
        {
            var mockRepo = new Mock<ICustomerRepository>();

            var service = new CustomerService(mockRepo.Object);

            Assert.IsNotNull(service);
        }

        [TestMethod]
        public void Add_Adds_One_Item_To_Repo()
        {
            var customers = new List<Customer>();
            var mockRepo = new Mock<ICustomerRepository>();
            mockRepo.Setup(x => x.Add(It.IsAny<Customer>())).Callback<Customer>(customers.Add);
            var service = new CustomerService(mockRepo.Object);

            service.Add(new Customer());

            Assert.AreEqual(1, customers.Count);
        }

        [TestMethod]
        public void Add_Adds_Item_With_Same_Id()
        {
            var customers = new List<Customer>();
            var customerToAdd = new Customer() { Id = 1 };
            var mockRepo = new Mock<ICustomerRepository>();
            mockRepo.Setup(x => x.Add(It.IsAny<Customer>())).Callback<Customer>(customers.Add);
            var service = new CustomerService(mockRepo.Object);

            service.Add(customerToAdd);

            Assert.IsTrue(customers.Any(x => x.Id == 1));
        }

        [TestMethod]
        public void Add_Returns_Same_Item()
        {
            var customerToAdd = new Customer();
            var mockRepo = new Mock<ICustomerRepository>();
            var service = new CustomerService(mockRepo.Object);

            var returnedCustomer = service.Add(customerToAdd);

            Assert.AreEqual(customerToAdd, returnedCustomer);
        }

        [TestMethod]
        public void Remove_Removes_One_Item_From_Repo()
        {
            var customers = new List<Customer>() { new() { Id = 1 }, new() { Id = 2 } };
            var mockRepo = new Mock<ICustomerRepository>();
            mockRepo.Setup(x => x.Delete(It.IsAny<int>())).Callback<int>(x => customers.Remove(customers.First(y => y.Id == x)));
            var service = new CustomerService(mockRepo.Object);

            service.DeleteCustomer(1);

            Assert.AreEqual(1, customers.Count);
        }

        [TestMethod]
        public void Remove_Removes_Item_With_Same_Id()
        {
            var customers = new List<Customer>() { new() { Id = 1 }, new() { Id = 2 } };
            var mockRepo = new Mock<ICustomerRepository>();
            mockRepo.Setup(x => x.Delete(It.IsAny<int>())).Callback<int>(x => customers.Remove(customers.First(y => y.Id == x)));
            var service = new CustomerService(mockRepo.Object);

            service.DeleteCustomer(2);

            Assert.IsFalse(customers.Any(x => x.Id == 2));
        }

        [TestMethod]
        public void Update_Address_Changes_Address_For_Same_Id()
        {
            var customers = new List<Customer>() { new() { Id = 1, Address = new Address("First", 0, "") }, new() { Id = 2, Address = new Address("Second", 0, "") } };
            var newAddress = new Address("Third", 0, "") ;
            int idToChange = 2;
            var mockRepo = new Mock<ICustomerRepository>();
            mockRepo.Setup(x => x.Update(It.IsAny<int>(), It.IsAny<Customer>()))
                .Callback<int, Customer>((id, customer) => customers.First(y => y.Id == id).Address = customer.Address);
            mockRepo.Setup(x => x.GetAll()).Returns(customers.AsQueryable());
            var service = new CustomerService(mockRepo.Object);

            service.UpdateAddress(idToChange, newAddress);

            mockRepo.Verify(x => x.Update(It.IsAny<int>(), It.IsAny<Customer>()), Times.Once);
            Assert.AreEqual(newAddress, customers.First(x => x.Id == idToChange).Address);
        }

        [TestMethod]
        public void Update_Name_Changes_Name_For_Same_Id()
        {
            var customers = new List<Customer>() { new() { Id = 1, Name = "First" }, new() { Id = 2, Name = "Second" } };
            var newName = "Third";
            int idToChange = 1;
            var mockRepo = new Mock<ICustomerRepository>();
            mockRepo.Setup(x => x.Update(It.IsAny<int>(), It.IsAny<Customer>()))
                .Callback<int, Customer>((id, customer) => customers.First(y => y.Id == id).Name = customer.Name);
            mockRepo.Setup(x => x.GetAll()).Returns(customers.AsQueryable());
            var service = new CustomerService(mockRepo.Object);

            service.UpdateName(idToChange, newName);

            mockRepo.Verify(x => x.Update(It.IsAny<int>(), It.IsAny<Customer>()), Times.Once);
            Assert.AreEqual(newName, customers.First(x => x.Id == idToChange).Name);
        }
    }
}
