﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGarageApp.Cars
{
    public class A300B : Vehicule
    {
        public A300B() : base()
        {
            nomMarque = Marque.PIGEOT;
        }
    }
}
