﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AjoutEmpruntStatus : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Status",
                table: "Livres",
                newName: "EmpruntStatus");

            migrationBuilder.AddColumn<int>(
                name: "AcceptationStatus",
                table: "Livres",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AcceptationStatus",
                table: "Livres");

            migrationBuilder.RenameColumn(
                name: "EmpruntStatus",
                table: "Livres",
                newName: "Status");
        }
    }
}
