﻿using Exercice5.Core.Entities;
using Exercice5.Core.Interfaces.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice5.Infrastructure.FakeRepositories
{
    public class FakeArticleReferencesRepository : IArticleReferencesRepository
    {

        public List<Article> GetArticleReferences()
        {
            return FakeApplicationDbContext.ArticleReferences;
        }
    }
}
