﻿using DemoTrip.Core.Dtos;
using DemoTrip.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoTrip.Infrastructure.Notifications
{
    public class FakeSmsReservationNotification : IReservationNotification
    {
        public Task NotifyTripBooked(BookTripResponse bookedTripResponse)
        {
            Console.WriteLine($"SMS : You have successfully reserved your trip to {bookedTripResponse.Destination}.");
            return Task.CompletedTask;
        }
    }
}
