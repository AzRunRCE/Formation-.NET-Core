﻿namespace Exercice5.MVC_Web.Models
{
    public class OrderDetailViewModelList : List<OrderDetailViewModel>
    {
        public OrderDetailViewModelList(IEnumerable<OrderDetailViewModel> collection) : base(collection) { }
        public OrderDetailViewModelList() : base() { }
    }
}
