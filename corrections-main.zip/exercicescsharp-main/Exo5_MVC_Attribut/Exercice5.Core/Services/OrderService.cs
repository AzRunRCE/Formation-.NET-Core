﻿using System.Collections;
using System.ComponentModel.DataAnnotations;
using Ardalis.GuardClauses;
using Exercice5.Core.Entities;
using Exercice5.Core.Interfaces.Core;
using Exercice5.Core.Interfaces.Infrastructure;

namespace Exercice5.Core.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrdersRepository ordersRepository;
        private readonly IOrderDetailsRepository orderDetailsRepository;
        private readonly IArticleReferencesRepository articleReferencesRepository;
        public OrderService(IOrdersRepository ordersRepository, IOrderDetailsRepository orderDetailsRepository, IArticleReferencesRepository articleReferencesRepository)
        {
            this.ordersRepository = ordersRepository;
            this.orderDetailsRepository = orderDetailsRepository;
            this.articleReferencesRepository = articleReferencesRepository;
        }

        public List<Order> GetOrdersFromWarehouse(int warehouseId)
        {
            return ordersRepository.GetOrders().Where(x => x.WarehouseId == warehouseId).ToList();
        }
        public List<Order> GetOrders()
        {
            return ordersRepository.GetOrders().ToList();
        }
        public Order GetOrderById(int id)
        {
            if (id < 0)
                throw new ArgumentException("Id must be Non-Negative because of the way they are assigned.");

            Order? order = ordersRepository.GetOrders().FirstOrDefault(x => x.Id == id);

            if (order == null)
                throw new KeyNotFoundException($"Order with id '{id}' was not found");
            else
                return order;
        }

        public void DeleteOrderAndItsDetails(Order order)
        {
            ordersRepository.GetOrders().Remove(ordersRepository.GetOrders().First(x => x.Id == order.Id));
            orderDetailsRepository.GetOrderDetails().RemoveAll(x => x.OrderId == order.Id);
        }

        public void CreateOrderAndItsDetails(Order newOrder)
        {
            ValidateOrder(newOrder);

            newOrder.TotalAmount = (double)CalculateOrderTotalAmount(newOrder.OrderDetails);

            ordersRepository.GetOrders().Add(newOrder);

            newOrder.OrderDetails.ForEach(x => CreateOrderDetail(x));
        }

        public void UpdateOrderAndItsDetails(int orderId, Order newOrder)
        {
            ValidateOrder(newOrder);

            var orders = ordersRepository.GetOrders();
            var orderIndex = orders.IndexOf(orders.First(x => x.Id == orderId));

            var oldOrder = orders.First(x => x.Id == orderId);
            oldOrder.OrderDetails = GetOrderDetailsAssociatedWithOrderId(orderId);

            newOrder.TotalAmount = (double)CalculateOrderTotalAmount(newOrder.OrderDetails);

            if (IsOrderProcessingButDetailsOrTotalAmountTriesToChange(oldOrder, newOrder))
            {
                newOrder.TotalAmount = orders[orderIndex].TotalAmount;
                newOrder.OrderDetails = orders[orderIndex].OrderDetails;
            }

            if (IsOrderSentButAddressIsChanged(oldOrder, newOrder))
            {
                newOrder.ShippingAddress = orders[orderIndex].ShippingAddress;
            }

            ordersRepository.GetOrders()[orderIndex] = newOrder;

            UpdateOrderDetails(newOrder);
        }

        public List<OrderDetail> GetOrderDetailsAssociatedWithOrderId(int orderId)
        {
            if (orderId < 0)
                throw new ArgumentException("Id must be Non-Negative because of the way they are assigned.");

            List<OrderDetail> details = orderDetailsRepository.GetOrderDetails().Where(x => x.OrderId == orderId).ToList();

            if (details.Count == 0)
                throw new KeyNotFoundException($"No details exists with id {orderId}. There is a possibility that your order is corrupted or has an issue.");
            else
            {
                details.ForEach(x => x.Article = articleReferencesRepository.GetArticleReferences().First(reference => reference.Id == x.ArticleId));
                return details;
            }
        }

        public void CreateOrderDetail(OrderDetail orderDetail)
        {
            Guard.Against.NegativeOrZero(orderDetail.Quantity);

            var articleReference = articleReferencesRepository.GetArticleReferences().First(x => x.Id == orderDetail.ArticleId);

            orderDetail.UnitPrice = articleReference.Price;

            if (articleReference.StockQuantity >= orderDetail.Quantity)
            {
                articleReference.StockQuantity -= orderDetail.Quantity;
                orderDetailsRepository.GetOrderDetails().Add(orderDetail);
            }
            else
            {
                throw new Exception("There is not enough stock");
            }
        }

        public List<Article> GetArticleStockList()
        {
            return articleReferencesRepository.GetArticleReferences().ToList();
        }

        public int GetNextOrderId()
        {
            return FindOneFreeIdInList(ordersRepository.GetOrders(), x => x.Id);
        }

        public int GetNextOrderDetailID()
        {
            return FindOneFreeIdInList(orderDetailsRepository.GetOrderDetails(), x => x.Id);
        }


        private decimal CalculateOrderTotalAmount(List<OrderDetail> orderDetails)
        {
            var articlesRepository = articleReferencesRepository.GetArticleReferences();
            decimal calculatedOrderTotalAmount = 0;

            Article correspondingArticle;

            foreach (var detail in orderDetails)
            {
                correspondingArticle = articlesRepository.First(article => article.Id == detail.ArticleId);

                detail.UnitPrice = correspondingArticle.Price;
                calculatedOrderTotalAmount += correspondingArticle.Price * detail.Quantity;
            }

            return calculatedOrderTotalAmount;
        }

        private void ValidateOrder(Order order)
        {
            Guard.Against.Negative(order.TotalAmount, message: "Amount is inferior to 0!");
            Guard.Against.Expression(x => x < OrderStatus.Waiting, order.Status, "Order Status is undefined!");
            Guard.Against.NullOrEmpty(order.OrderDetails, message: "Order details are empty!");
        }

        private void UpdateOrderDetails(Order newOrder)
        {
            var detailRepository = orderDetailsRepository.GetOrderDetails();
            var unupdatedDetailListForThisOrder = detailRepository.Where(x => x.OrderId == newOrder.Id).ToList();

            newOrder.OrderDetails.ForEach((x) =>
            {
                Guard.Against.NegativeOrZero(x.Quantity);

                var foundDetail = detailRepository.FirstOrDefault(y => y.Id == x.Id);
                if (foundDetail != null)
                {
                    unupdatedDetailListForThisOrder.Remove(foundDetail);
                    orderDetailsRepository.GetOrderDetails()[detailRepository.IndexOf(foundDetail)] = x;
                }
                else
                    CreateOrderDetail(x);
            });

            unupdatedDetailListForThisOrder.ForEach(elementToRemoveFromDB =>
            {
                orderDetailsRepository.GetOrderDetails().Remove(elementToRemoveFromDB);
            });
        }

        private int FindOneFreeIdInList<T>(List<T> values, Func<T, int> idSelector)
        {
            var orders = values.OrderBy(idSelector);
            int freeId = 1;
            foreach (var item in orders)
            {
                if (freeId != idSelector(item))
                    return freeId;

                freeId++;
            }

            return freeId;
        }

        private bool IsOrderProcessingButDetailsOrTotalAmountTriesToChange(Order oldOrder, Order newOrder)
        {
            return oldOrder.Status >= OrderStatus.Processing &&
                (
                newOrder.TotalAmount != oldOrder.TotalAmount ||
                !Enumerable.SequenceEqual(oldOrder.OrderDetails, newOrder.OrderDetails)
                );
        }

        private bool IsOrderSentButAddressIsChanged(Order oldOrder, Order newOrder)
        {
            return oldOrder.Status >= OrderStatus.Shipped && oldOrder.ShippingAddress != newOrder.ShippingAddress;
        }
    }
}
