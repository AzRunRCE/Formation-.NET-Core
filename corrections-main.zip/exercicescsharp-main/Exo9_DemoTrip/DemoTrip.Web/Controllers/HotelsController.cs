﻿using Ardalis.Specification;
using DemoTrip.Core.Interfaces;
using DemoTrip.Core.UseCases;
using DemoTrip.Web.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DemoTrip.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HotelsController(ISearchHotelUseCase useCase) : ControllerBase
    {

        // POST api/<HotelsController>
        [HttpPost("Search")]
        public async Task<IActionResult> Post([FromBody] SearchHotelRequestViewModel value)
        {
            if (ModelState.IsValid)
            {

                var response = await useCase.Execute(new Core.Dtos.SearchHotelRequest(
                    value.Location!,
                    value.DateFrom!.Value,
                    value.DateTo!.Value
                ));

                var responseVm = new SearchHotelResponseViewModel() { Hotels = response.Hotels };

                if (response.Success)
                    return Ok(responseVm);
                else
                    return NotFound(responseVm);
            }
            else return BadRequest();
        }
    }
}
