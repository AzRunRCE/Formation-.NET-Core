﻿using Exo6_EF.Core.Entities;
using Exo6_EF.Core.Interfaces.Core;
using Exo6_EF.Core.Interfaces.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ardalis.GuardClauses;

namespace Exo6_EF.Core.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository orderRepository;

        public OrderService(IOrderRepository orderRepository)
        {
            this.orderRepository = orderRepository;
        }

        public Order Add(Order order)
        {
            Validate(order);
            orderRepository.Add(order);
            return order;
        }

        public void Delete(int orderId)
        {
            orderRepository.Delete(orderId);
        }

        public IQueryable<Order> GetAllByCustomerId(int customerId)
        {
            return orderRepository.GetAll().Where(x => x.CustomerId == customerId);
        }

        public double GetAverageOrderValue()
        {
            double totalOrdersAmount = 0;
            int numberOfOrders = 0;
            orderRepository.GetAll().ToList().ForEach(x => { totalOrdersAmount += x.TotalAmount; numberOfOrders++; });
            return totalOrdersAmount / numberOfOrders;
        }

        public double GetAverageArticlePerOrder()
        {
            int totalArticleAmount = 0;
            int numberOfOrders = 0;
            orderRepository.GetAll().ToList().ForEach(x => { totalArticleAmount += x.OrderDetails.Count; numberOfOrders++; });
            return ((double)totalArticleAmount) / numberOfOrders;
        }

        private void Validate(Order order)
        {
            Guard.Against.NullOrEmpty(order.OrderDetails);
            Guard.Against.Negative(order.TotalAmount);
            Guard.Against.Null(order.ShippingAddress);
        }
    }
}
