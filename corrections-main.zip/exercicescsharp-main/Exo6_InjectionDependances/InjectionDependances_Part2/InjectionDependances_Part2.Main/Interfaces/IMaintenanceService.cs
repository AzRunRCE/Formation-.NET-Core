﻿namespace GarageManagementWithDotNetCore
{
    public interface IMaintenanceService
    {
    }
}
