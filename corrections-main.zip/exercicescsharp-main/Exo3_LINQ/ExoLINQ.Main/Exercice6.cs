﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ExoLINQ.Main.Entities;

namespace ExoLINQ.Main
{
    internal class Exercice6 : ExerciceBase
    {
        public Exercice6() { number = 6; name = "Requêtes et groupBy"; }
        protected override void Content()
        {
            List<Personne> personnes = new List<Personne>()
            {
                new Personne("Garett", "Ramzy", 45, "M"),
                new Personne("Caire", "Joe", 35, "M"),
                new Personne("Clay", "Alicia", 18, "F"),
                new Personne("Bavette", "Simone", 68, "F"),
                new Personne("Henry", "Thierry", 44, "M"),
                new Personne("Jacquesonne", "Janett", 25, "F"),
                new Personne("Buveur", "Joe", 25, "M"),
                new Personne("Louet", "Karim", 31, "M"),
                new Personne("Louette", "Karima", 31, "F"),
                new Personne("Caire", "Paul", 19, "M"),
                new Personne("Mille", "Camille", 20, "F"),
                new Personne("Cent", "Camille", 40, "F"),
                new Personne("Million", "Camille", 60, "M"),
                new Personne("Gold", "Roger", 17, "M"),
                new Personne("Lion", "Sandra", 8, "F"),
                new Personne("René", "Jean", 6, "M")
            };

            //1. Faire un group by sur le genre (sexe) des personnes présentes dans la liste d'objets Personne()
            var querySexe = personnes.GroupBy(p => p.Sexe, (sexe, personnes) => new { sexe, personnes });
            querySexe.ToList().ForEach(x =>
            {
                Console.WriteLine(x.sexe);
                x.personnes.ToList().ForEach(p => Console.WriteLine($"=> {p.Nom} {p.Prenom}"));
            });

            //Affiche les valeurs possibles pour Sexe
            //            foreach (var item in querySexe) 
            //            {
            //            }

            Console.WriteLine("----------------------------------");

            //2. Faire un group by sur l'âge des personnes. Faire un tri croissant par âge.
            var queryAge = personnes.GroupBy(p => p.Age, (age, personnes) => new { age, personnes }).OrderBy(x => x.age);
            queryAge.ToList().ForEach(x =>
            {
                Console.WriteLine("Age : " + x.age);
                x.personnes.ToList().ForEach(p => Console.WriteLine($"=> {p.Nom} {p.Prenom}"));
            });

            //Affiche les valeurs possibles pour Sexe
            //foreach (var item in queryAge)
            //{
            //    Console.WriteLine(item);
            //}

            Console.WriteLine("----------------------------------");

            //3. Faire un group by sur le prénom des personnes, et afficher les noms de famille par prénom.
            //Trier les prénoms par ordre décroissant.
            //Récupérer les personnes majeures (18 ans et plus)
            var queryPrenom = personnes.GroupBy(p => p.Prenom, (prenom, personnes) => new { prenom, personnes }).OrderByDescending(x => x.prenom);
            queryPrenom.ToList().ForEach(x =>
            {
                Console.WriteLine("Age : " + x.prenom);
                x.personnes.ToList().ForEach(p => Console.WriteLine($"=> {p.Nom}"));
            });

            //            foreach (var item in queryPrenom)
            //            {
            //            }

            Console.WriteLine("----------------------------------");

            //4. Grouper les éléments d'une liste de nombres. D'un côté les chiffres/nombres pairs, de l'autre ceux impairs.
            List<int> nombres = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 20, 11, 13, 12, 14, 18, 17, 16, 14, 14 };

            var queryPair = nombres.GroupBy(x => (x % 2 == 0 ? "Pair" : "Impair"), (key, values) => new {key, values});
            queryPair.ToList().ForEach(x =>
            {
                Console.WriteLine("Clé : " + x.key);
                x.values.ToList().ForEach(i => Console.WriteLine($"=> {i}"));
            });
            //    foreach (var item in queryPair)
            //    {
            //    }

            Console.WriteLine("----------------------------------");

            //5 Grouper les individus par la première lettre de leur nom et faire un tri croissant sur l'attribut Nom de la classe Personne
            var queryInitiale = personnes.GroupBy(p => p.Nom[0], (key, personnes) => new {key, personnes}).OrderBy(x => x.key);
            queryInitiale.ToList().ForEach(x =>
            {
                Console.WriteLine("Clé : " + x.key);
                x.personnes.ToList().ForEach(i => Console.WriteLine($"=> {i.Nom}"));
            });

            //            foreach (var item in queryInitiale)
            //            {
            //            }
        }
    }
}
