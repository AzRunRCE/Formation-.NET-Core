﻿namespace Exo7_EF.Web.Dto
{
    public class ArticleDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string PriceWithCurrency { get; set; }
        public int StockQuantity { get; set; }
    }
}
