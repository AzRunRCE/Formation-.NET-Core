﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BatailleCorse;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatailleCorse.Tests
{
    [TestClass()]
    public class JoueurTests
    {
        [TestMethod()]
        public void Joueur_Constructeur_Remplit_Nom()
        {
            Joueur testJoueur = new Joueur("James");
            Assert.AreEqual("James", testJoueur.Name);
        }

        [TestMethod()]
        public void HasCards_Renvoie_True_Si_Cartes_Ajoutes()
        {
            Joueur testJoueur = new Joueur("James");
            testJoueur.Cartes.AjouterALaFin(new Cartes.Carte(Cartes.Valeur.SEPT, Cartes.Couleur.PIQUE));
            Assert.IsTrue(testJoueur.HasCards());
        }

        [TestMethod()]
        public void HasCards_Renvoie_False_Si_Pas_De_Cartes_Ajoutes()
        {
            Joueur testJoueur = new Joueur("James");
            Assert.IsFalse(testJoueur.HasCards());
        }

        [TestMethod()]
        public void HasCards_Renvoie_False_Si_Plus_De_Cartes()
        {
            Joueur testJoueur = new Joueur("James");
            testJoueur.Cartes.AjouterALaFin(new Cartes.Carte(Cartes.Valeur.SEPT, Cartes.Couleur.PIQUE));
            testJoueur.Cartes.AjouterALaFin(new Cartes.Carte(Cartes.Valeur.HUIT, Cartes.Couleur.PIQUE));
            testJoueur.Cartes.AjouterALaFin(new Cartes.Carte(Cartes.Valeur.NEUF, Cartes.Couleur.PIQUE));
            testJoueur.Cartes.RetirerPremier();
            testJoueur.Cartes.RetirerPremier();
            testJoueur.Cartes.RetirerPremier();
            Assert.IsFalse(testJoueur.HasCards());
        }

        [TestMethod()]
        public void ToString_Renvoie_Name()
        {
            Joueur testJoueur = new Joueur("James");
            Assert.AreEqual("James", testJoueur.ToString());
        }
    }
}