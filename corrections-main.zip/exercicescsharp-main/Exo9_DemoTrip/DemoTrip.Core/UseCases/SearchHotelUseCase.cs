﻿using Ardalis.Specification;
using DemoTrip.Core.Dtos;
using DemoTrip.Core.Entities;
using DemoTrip.Core.Interfaces;
using DemoTrip.Core.Specifications;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoTrip.Core.UseCases
{
    public class SearchHotelUseCase(IReadRepositoryBase<Hotel> hotelRepository) : ISearchHotelUseCase
    {
        public async Task<SearchHotelResponse> Execute(SearchHotelRequest request)
        {
            var hotelList = await hotelRepository.ListAsync(new GetHotelsFromRequest(request));
            hotelList.OrderByDescending(x => x.PricePerNight);
            return new SearchHotelResponse(hotelList.Count != 0, hotelList);
        }
    }
}
