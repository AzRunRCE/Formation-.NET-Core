﻿using DemoTrip.Core.Entities;

namespace DemoTrip.Core.Dtos
{
    public record SearchFlightRequest(string Origin, string Destination, DateTime DateFrom);
    public record SearchFlightResponse(bool Success, List<Flight> Flights);
}