﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ExoLINQ.Main.Entities;

namespace ExoLINQ.Main
{

    internal class Exercice4 : ExerciceBase
    {
        public Exercice4() { number = 4; name = "Requêtes et variables"; }
        protected override void Content()
        {
            List<Personne> personnes = new List<Personne>
            {
                new Personne("Beauvoir", "Simon", 16, "M"),
                new Personne("Beauvoir", "Simone", 25, "F"),
                new Personne("De Caunes", "Richard", 41, "M"),
                new Personne("Sullivan", "Sullivan", 31, "M"),
                new Personne("Rémy", "Camille", 22, "F"),
                new Personne("Manchon", "Camille", 19, "M"),
                new Personne("Thiebaud", "Marie", 61, "F"),
                new Personne("Crouchon", "Mélanie", 55, "F"),
                new Personne("Baline", "Mélodie", 74, "F"),
                new Personne("Karine", "Pascal", 31, "M"),
                new Personne("Katherine", "Pascale", 36, "F"),
                new Personne("Zoula", "Charles", 20, "M"),
                new Personne("Romain", "Collin", 34, "M"),
                new Personne("Fouchard", "Aïcha", 48, "F"),
                new Personne("Blandine", "Maëva", 18, "F")
            };

            //Créer une variable majeur qui est égale à True si l'âge de la personne est supérieure ou égale à 18
            //sinon False
            var query = personnes.Select(p => new { nom_complet = $"{p.Nom} {p.Prenom}" });
            ConformRequestResult(query, x => x.nom_complet);


            //Créer une variable "initiale" qui contient seulement les initiales du nom et du prénom : p.Nom[0]+"."+p.Prenom[0]
            //Sélectionner seulement les personnes majeures (18 ans et plus)
            //Sélectionner également les personnes âgées de moins de 50 ans
            //Créer une variable taille_nom_complet = longueur du prénom + longueur du nom
            //Créer un objet anonyme avec les attributs : Nom, prénom, initiale, taille_nom_complet, age

            var bigQuery = personnes.Where(p => p.Age >= 18 && p.Age < 50).Select(p => new { initiales = $"{p.Nom[0]}.{p.Prenom[0]}", taille_nom_complet = p.Nom.Length + p.Prenom.Length, p.Nom, p.Prenom, p.Age });
            ConformRequestResult(bigQuery, x => $"\r\n {x.Nom} {x.Prenom} {x.initiales} {x.taille_nom_complet} {x.Age}");
            //Affichage du résultat de la requête
            //                foreach (var item in bigQuery)
            //                {
            //                    Console.WriteLine(item.Nom + " " + item.Prenom + " " + item.Initiale + " " + item.Taille_nom_complet + " " + item.Age);
            //                }

        }

        }

    }
