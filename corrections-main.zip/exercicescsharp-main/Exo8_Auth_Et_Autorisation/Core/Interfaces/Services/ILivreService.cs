﻿using Core.Dto;
using Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Interfaces.Services
{
    public interface ILivreService
    {
        Task<List<GetLivreResponse>> GetAllLivres();
        Task<List<GetLivreResponse>> GetDisponibles();
        Task<List<GetLivreResponse>> GetApproved();
        Task<List<GetLivreResponse>> GetFromUser(string userId);
        Task<List<GetLivreResponse>> GetSubmittedLivres();
        Task<GetLivreResponse> GetOne(int livreId);
        Task<GetLivreResponse> GetOneWithItsUser(int livreId);
        Task<CreatedLivreResponse> Create(CreateLivreRequete requete);
        Task<UpdatedLivreResponse> UpdateContent(UpdateContentLivreRequete requete);
        Task<UpdatedLivreResponse> UpdateAcceptationStatus(UpdateAcceptationLivreRequete requete);
        Task<UpdatedLivreResponse> UpdateEmpruntStatus(UpdateEmpruntStatusRequete updateEmpruntStatusRequete);
        Task Delete(DeleteLivreRequete requete);
    }
}
