﻿namespace GarageManagementWithDotNetCore
{
    public interface IVehiculeRepository
    {
        void AddVehicule(string Vehicule);
    }
}
