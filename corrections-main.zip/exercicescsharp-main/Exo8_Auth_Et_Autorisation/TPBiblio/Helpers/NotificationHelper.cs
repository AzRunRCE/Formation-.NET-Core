﻿namespace Web.Helpers
{
    public class NotificationHelper
    {
        public const string Text = "NotificationText";
        public const string TextColor = "NotificationTxtColor";
        public const string BackgroundColor = "NotificationBgColor";
        public const string CloseColor = "NotificationCloseColor";
    }
}
