﻿using Exo6_EF.Core.Entities;
using Exo6_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo6_EF.Core.Interfaces.Infrastructure
{
    public interface ICustomerRepository : IRepository<Customer>
    {
    }
}
