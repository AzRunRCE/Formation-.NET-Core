﻿using Ardalis.Specification;
using Core.Facades;
using Core.Interfaces.Facades;
using Core.Interfaces.Services;
using Core.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Data
{
    public static class ServiceCollectionExtension
    {
        public static IServiceCollection GetServiceCollection(this IServiceCollection services)
        {
            return services
                .AddScoped<ILivreService, LivresService>()
                .AddScoped<IUserPermissionFacade, UserPermissionFacade>()

                .AddScoped<UserManager<IdentityUser>>()

                .AddScoped(typeof(IRepositoryBase<>), typeof(SqlRepository<>));

        }
    }
}
