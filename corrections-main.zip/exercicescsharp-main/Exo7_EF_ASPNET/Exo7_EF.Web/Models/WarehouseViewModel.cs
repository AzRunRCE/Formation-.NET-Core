﻿using Microsoft.AspNetCore.Mvc;

namespace Exo7_EF.Web.Models
{
    public class WarehouseViewModel
    {
        [HiddenInput(DisplayValue = false)]
        public int Id { get; set; }
        public string Name { get; set; }
        public string RoadName { get; set; }
        public string PostalCode { get; set; }
        public string City { get; set; }
    }
}
