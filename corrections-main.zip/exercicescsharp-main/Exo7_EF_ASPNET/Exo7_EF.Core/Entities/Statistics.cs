﻿namespace Exo7_EF.Core.Entities
{
    public class Statistics
    {
        public List<Article> ArticlesUnderStock { get; internal set; }
        public double AverageAmountPerOrder { get; internal set; }
        public int AverageArticleCountPerOrder { get; internal set; }
        public KeyValuePair<Article, int> BestSellingArticle { get; internal set; }
    }
}
