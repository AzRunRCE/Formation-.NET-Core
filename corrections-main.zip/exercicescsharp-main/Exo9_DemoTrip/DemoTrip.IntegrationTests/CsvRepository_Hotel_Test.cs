using DemoTrip.Core.Entities;
using DemoTrip.Infrastructure;
using DemoTrip.Infrastructure.Csv;

namespace DemoTrip.IntegrationTests
{
    [TestClass]
    public class CsvRepository_Hotel_Test
    {
        [TestMethod]
        public void List_Should_Return_Hotels()
        {
            var repo = new CsvRepository<Hotel>("hotels.csv", new HotelCsvParser());

            var Hotels = repo.ListAsync().Result;

            Assert.IsTrue(Hotels.Count > 0);
        }
    }
}