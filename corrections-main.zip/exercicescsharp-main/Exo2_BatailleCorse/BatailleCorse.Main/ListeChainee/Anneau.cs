﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatailleCorse.ListeChainee
{
    public class Anneau<T> where T : class
    {
        public int NbElements { get; private set; }

        private Maillon<T> currentFirstElement = null;

        private Maillon<T> currentLastElement = null;

        public void AjouterALaFin(T elementToAdd)
        {
            Maillon<T> newMaillon = new Maillon<T>(elementToAdd);

            if(currentFirstElement == null)
            {
                currentFirstElement = newMaillon;
            }

            if (currentLastElement != null)
            {
                currentLastElement.Suivant = newMaillon;
            }
            NbElements++;
            currentLastElement = newMaillon;
        }

        public void Retirer(T elementToRemove)
        {
            Maillon<T> currentMaillon = currentFirstElement;
            Maillon<T> lastMaillon = null;
            bool hasFoundElement = false;

            while (currentMaillon != null)
            {
                if (elementToRemove == currentMaillon.Valeur)
                {
                    hasFoundElement = true;
                    if (lastMaillon != null)
                        lastMaillon.Suivant = currentMaillon.Suivant;
                    break;
                }

                lastMaillon = currentMaillon;
                currentMaillon = currentMaillon.Suivant;
            }

            if (hasFoundElement)
            {
                NbElements--;
            }
            else
            {
                throw new KeyNotFoundException($"Anneau has not found element {elementToRemove}");
            }
        }

        public T RetirerPremier()
        {
            Maillon<T> firstMaillon = currentFirstElement;
            currentFirstElement = firstMaillon.Suivant;
            NbElements--;
            return firstMaillon.Valeur;
        }
    }
}
