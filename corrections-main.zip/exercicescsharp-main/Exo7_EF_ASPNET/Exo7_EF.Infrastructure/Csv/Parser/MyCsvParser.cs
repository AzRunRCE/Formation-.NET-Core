﻿using Exo7_EF.Infrastructure.Csv.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TinyCsvParser;
using TinyCsvParser.Mapping;

namespace Exo7_EF.Infrastructure.Csv.Parser
{
    internal class MyCsvParser<T> where T : class, new()
    {
        internal const char separator = ',';
        private static readonly CsvParserOptions parserOption = new(false, separator);
        private static readonly CsvReaderOptions readerOptions = new([Environment.NewLine]);
        private readonly CsvReversibleMapping<T> mapping;
        private CsvParser<T> parser;

        public MyCsvParser(CsvReversibleMapping<T> mapping)
        {
            this.mapping = mapping;
            parser = new CsvParser<T>(parserOption, mapping);
        }

        public string GetLine(T data)
        {
            return mapping.ReverseMap(separator, data);
        }

        public T ParseLine(string data)
        {
            return parser.ReadFromString(readerOptions, data).First().Result;
        }
    }
}
