﻿using Ardalis.Specification;
using DemoTrip.Core.Dtos;
using DemoTrip.Core.Entities;
using DemoTrip.Core.Exceptions;
using DemoTrip.Core.Interfaces;
using DemoTrip.Core.Specifications;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoTrip.Core.UseCases
{
    public class BookTripUseCase(ISearchFlightUseCase searchFlight, ISearchHotelUseCase searchHotel, IReservationNotification notification) : IBookTripUseCase
    {
        public async Task<BookTripResponse> Execute(BookTripRequest request)
        {
            try
            {
                var selectedFlight = await FindAFlightForThisRequest(request.Origin, request.Destination, request.DateFrom);

                var selectedHotel = await FindAnHotelForThisRequest(request.Destination, selectedFlight.ArrivalTime, request.DateTo);

                var daysInDestination = (decimal)Math.Ceiling((request.DateTo - selectedFlight.ArrivalTime).TotalDays);
                decimal totalPrice = daysInDestination * selectedHotel.PricePerNight + selectedFlight.Price;

                var bookedTrip = new BookTripResponse(true, totalPrice, selectedHotel.Name!, request.Destination);

                await notification.NotifyTripBooked(bookedTrip);
                return bookedTrip;
            }
            catch (CannotBookTripException)
            {
                return new BookTripResponse(false, 0, "", request.Destination);
            }
        }

        private async Task<Hotel> FindAnHotelForThisRequest(string location, DateTime from, DateTime to)
        {
            var searchHotelsResponse = await searchHotel.Execute(
                new SearchHotelRequest(location, from, to));

            if (!searchHotelsResponse.Success)
                throw new CannotBookTripException("Cannot find an hotel for this request");

            return searchHotelsResponse.Hotels.OrderByDescending(x => x.PricePerNight).First();
        }

        private async Task<Flight> FindAFlightForThisRequest(string origin, string destination, DateTime from)
        {
            var searchFlightsResponse = await searchFlight.Execute(
                new SearchFlightRequest(origin, destination,from));

            if (!searchFlightsResponse.Success)
                throw new CannotBookTripException("Cannot find an incoming flight for this request");

            return searchFlightsResponse.Flights.OrderByDescending(x => x.Price).First();
        }
    }
}
