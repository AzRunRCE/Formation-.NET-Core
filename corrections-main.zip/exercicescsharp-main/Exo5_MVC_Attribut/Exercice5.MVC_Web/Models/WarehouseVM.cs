﻿namespace Exercice5.MVC_Web.Models
{
    public class WarehouseVM
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public string Address { get; set; } = string.Empty;

        public int PostalCode { get; set; }
    }
}
