﻿

using System.ComponentModel.DataAnnotations;

namespace DemoTrip.Web.Models
{
    public class SearchHotelRequestViewModel
    {
        [Required] public string? Location { get; set; }
        [Required] public DateTime? DateFrom { get; set; }
        [Required] public DateTime? DateTo { get; set; }
    }
}
