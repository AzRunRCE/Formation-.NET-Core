﻿using Exo6_EF.Core.Entities;

namespace Exo6_EF.Core.Interfaces.Infrastructure
{
    public interface IRepository<T>
    {
        public IQueryable<T> GetAll();
        void Add(T toAdd);
        void Update(int id, T toUpdate);
        void Delete(int id);
    }
}