﻿using Ardalis.Specification;
using Core.Dto;
using Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Specifications
{
    internal class GetAllLivresBase : Specification<Livre, GetLivreResponse>
    {
        public GetAllLivresBase()
        {
            GetQueryWithDto();
        }
        protected ISpecificationBuilder<Livre, GetLivreResponse> GetQueryWithDto()
        {
            return Query.Select(x => new GetLivreResponse(
                x.LivreId,
                x.Content,
                x.CreatedDate,
                x.AcceptationStatus,
                x.EmpruntStatus,
                x.User == null ? string.Empty : x.User.UserName));
        }
    }
}
