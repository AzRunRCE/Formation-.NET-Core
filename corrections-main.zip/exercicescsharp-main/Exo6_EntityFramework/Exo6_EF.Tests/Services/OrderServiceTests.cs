﻿using Exo6_EF.Core.Entities;
using Exo6_EF.Core.Interfaces.Infrastructure;
using Exo6_EF.Core.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo6_EF.Tests.Services
{
    [TestClass]
    public class OrderServiceTests
    {
        [TestMethod]
        public void CanCreateService()
        {
            var service = new OrderService(new Mock<IOrderRepository>().Object);

            Assert.IsNotNull(service);
        }

        [TestMethod]
        public void Add_Adds_Something_To_OrdersRepo()
        {
            var mockOrderRepo = new Mock<IOrderRepository>();
            List<Order> orderRepo = new();
            mockOrderRepo.Setup(x => x.Add(It.IsAny<Order>())).Callback<Order>(orderRepo.Add);
            var service = new OrderService(mockOrderRepo.Object);

            service.Add(new Order() { OrderDetails = [new OrderDetail()], ShippingAddress = new Address() });

            Assert.AreEqual(1, orderRepo.Count);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception), AllowDerivedTypes = true)]
        public void Add_Without_Details_Returns_Error()
        {
            var mockOrderRepo = new Mock<IOrderRepository>();
            List<Order> orderRepo = new();
            mockOrderRepo.Setup(x => x.GetAll()).Returns(orderRepo.AsQueryable());
            var service = new OrderService(mockOrderRepo.Object);

            service.Add(new Order());
        }

        [TestMethod]
        public void Add_With_Details_Adds_To_DetailRepo()
        {
            var mockOrderRepo = new Mock<IOrderRepository>();
            List<Order> orderRepo = new();
            List<OrderDetail> orderDetailRepo = new();
            mockOrderRepo.Setup(x => x.Add(It.IsAny<Order>())).Callback<Order>(x => x.OrderDetails.ForEach(orderDetailRepo.Add));
            var service = new OrderService(mockOrderRepo.Object);

            service.Add(new Order() { OrderDetails = [new OrderDetail()], ShippingAddress = new Address() });

            Assert.AreEqual(1, orderDetailRepo.Count);
        }

        [TestMethod]
        public void Add_With_Details_Adds_With_Same_Id()
        {
            var mockOrderRepo = new Mock<IOrderRepository>();
            List<Order> orderRepo = new();
            List<OrderDetail> orderDetailRepo = new();
            mockOrderRepo.Setup(x => x.Add(It.IsAny<Order>())).Callback<Order>(x => x.OrderDetails.ForEach(orderDetailRepo.Add));
            var service = new OrderService(mockOrderRepo.Object);

            service.Add(new Order() { OrderDetails = [new OrderDetail() { Id = 1 }], ShippingAddress = new Address() });

            mockOrderRepo.Verify(x => x.Add(It.IsAny<Order>()), Times.Once);
            Assert.IsTrue(orderDetailRepo.Any(x => x.Id == 1));
        }

        [TestMethod]
        public void Add_Returns_Same_Item()
        {
            var mockRepo = new Mock<IOrderRepository>();
            var orderToAdd = new Order() { OrderDetails = [new OrderDetail()], ShippingAddress=new Address() };

            var service = new OrderService(mockRepo.Object);

            var orderAdded = service.Add(orderToAdd);

            Assert.AreEqual(orderToAdd, orderAdded);
        }

        [TestMethod]
        public void Add_Adds_Item_With_Same_Id()
        {
            var mockRepo = new Mock<IOrderRepository>();
            List<Order> articleRepo = [];
            var orderToAdd = new Order() { Id = 1, OrderDetails = [new OrderDetail()], ShippingAddress = new Address() };
            mockRepo.Setup(x => x.Add(It.IsAny<Order>())).Callback<Order>(articleRepo.Add);

            var service = new OrderService(mockRepo.Object);

            service.Add(orderToAdd);

            Assert.IsTrue(articleRepo.Any(x => x.Id == orderToAdd.Id));
        }

        [TestMethod]
        public void DeleteOrder_Removes_One_Order_From_Repo()
        {
            int idToDelete = 1;
            var mockRepo = new Mock<IOrderRepository>();
            List<Order> orderRepo = new()
            {
                new Order(){ Id = 1},
                new Order(){ Id = 2},
                new Order(){ Id = 3},
                new Order(){ Id = 4}
            };
            mockRepo.Setup(x => x.GetAll()).Returns(orderRepo.AsQueryable());
            mockRepo.Setup(x => x.Delete(It.IsAny<int>())).Callback<int>((orderId) => orderRepo.Remove(orderRepo.First(x => x.Id == orderId)));

            var service = new OrderService(mockRepo.Object);

            service.Delete(idToDelete);

            Assert.AreEqual(3, orderRepo.Count);
        }

        [TestMethod]
        public void DeleteOrder_Removes_Order_With_Same_Id()
        {
            int idToDelete = 1;
            var mockRepo = new Mock<IOrderRepository>();
            List<Order> orderRepo = new()
            {
                new Order(){ Id = 1},
                new Order(){ Id = 2},
                new Order(){ Id = 3},
                new Order(){ Id = 4}
            };
            mockRepo.Setup(x => x.GetAll()).Returns(orderRepo.AsQueryable());
            mockRepo.Setup(x => x.Delete(It.IsAny<int>())).Callback<int>((orderId) => orderRepo.Remove(orderRepo.First(x => x.Id == orderId)));

            var service = new OrderService(mockRepo.Object);

            service.Delete(1);

            Assert.IsFalse(orderRepo.Any(x => x.Id == 1));
        }

        [TestMethod]
        public void GetAllByCustomer_Returns_List_Of_Orders()
        {
            var mockRepo = new Mock<IOrderRepository>();
            mockRepo.Setup(x => x.GetAll()).Returns(new List<Order>().AsQueryable());
            var service = new OrderService(mockRepo.Object);

            var orderList = service.GetAllByCustomerId(1);

            Assert.IsInstanceOfType<IEnumerable<Order>>(orderList);
        }

        [TestMethod]
        public void GetAllByCustomer_Returns_Order_With_Same_CustomerId()
        {
            var mockRepo = new Mock<IOrderRepository>();
            List<Order> orderRepo = new()
            {
                new Order(){ Id = 1, CustomerId=1},
                new Order(){ Id = 2, CustomerId=1},
                new Order(){ Id = 3, CustomerId=2},
                new Order(){ Id = 4, CustomerId=3},
            };
            mockRepo.Setup(x => x.GetAll()).Returns(orderRepo.AsQueryable());
            var service = new OrderService(mockRepo.Object);

            var orderList = service.GetAllByCustomerId(1);

            Assert.AreEqual(2, orderList.Count());
            Assert.IsFalse(orderList.Any(x => x.CustomerId != 1));
        }

        [TestMethod]
        public void GetAverageOrderValue_Returns_Double()
        {
            var mockRepo = new Mock<IOrderRepository>();
            mockRepo.Setup(x => x.GetAll()).Returns(new List<Order>().AsQueryable());
            var service = new OrderService(mockRepo.Object);

            var retour = service.GetAverageOrderValue();

            Assert.IsInstanceOfType<double>(retour);
        }

        [TestMethod]
        public void GetAverageOrderValue_Returns_Average_From_All_Orders()
        {
            var mockRepo = new Mock<IOrderRepository>();
            List<Order> articleRepo = new()
            {
                new Order(){TotalAmount=10},
                new Order(){TotalAmount=20},
                new Order(){TotalAmount=35},
                new Order(){TotalAmount=100},
            };
            mockRepo.Setup(x => x.GetAll()).Returns(articleRepo.AsQueryable());
            var service = new OrderService(mockRepo.Object);

            var retour = service.GetAverageOrderValue();

            Assert.AreEqual(41.25, retour);
        }

        [TestMethod]
        public void GetAverageArticlePerOrder_Returns_Double()
        {
            var mockRepo = new Mock<IOrderRepository>();
            mockRepo.Setup(x => x.GetAll()).Returns(new List<Order>().AsQueryable());
            var service = new OrderService(mockRepo.Object);

            var retour = service.GetAverageArticlePerOrder();

            Assert.IsInstanceOfType<double>(retour);
        }

        [TestMethod]
        public void GetAverageArticlePerOrder_Returns_Average_ArticleCount_From_All_Orders()
        {
            var mockRepo = new Mock<IOrderRepository>();
            List<Order> orderRepo = new()
            {
                new Order(){OrderDetails = new List<OrderDetail>(){new OrderDetail(), new OrderDetail(), new OrderDetail() } },
                new Order(){OrderDetails = new List<OrderDetail>(){new OrderDetail() }},
                new Order(){OrderDetails = new List<OrderDetail>(){new OrderDetail() }},
                new Order(){OrderDetails = new List<OrderDetail>(){new OrderDetail() , new OrderDetail() }},
            };
            mockRepo.Setup(x => x.GetAll()).Returns(orderRepo.AsQueryable());
            var service = new OrderService(mockRepo.Object);

            var retour = service.GetAverageArticlePerOrder();

            Assert.AreEqual(1.75, retour);
        }
    }
}
