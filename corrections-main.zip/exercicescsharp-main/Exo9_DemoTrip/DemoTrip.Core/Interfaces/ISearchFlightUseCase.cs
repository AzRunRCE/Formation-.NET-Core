﻿using DemoTrip.Core.Dtos;

namespace DemoTrip.Core.Interfaces
{
    public interface ISearchFlightUseCase
    {
        Task<SearchFlightResponse> Execute(SearchFlightRequest request);
    }
}