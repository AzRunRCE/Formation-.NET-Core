﻿
using System.ComponentModel.DataAnnotations;

namespace Exercice5.MVC_Web.Models.Validation
{
    public class ValidateOrderStatusAttribute : ValidationAttribute
    {
        public ValidateOrderStatusAttribute()
        {
            const string defaultErrorMessage = "Error with Order Status";
            ErrorMessage ??= defaultErrorMessage;
        }

        protected override ValidationResult? IsValid(object? value,
                                             ValidationContext validationContext)
        {
            if (value == null || string.IsNullOrWhiteSpace(value.ToString()))
            {
                return new ValidationResult("Order Status is required.");
            }

            if ((int)value < 0)
                return new ValidationResult("Order Status is required.");


            return ValidationResult.Success;
        }
    }
}