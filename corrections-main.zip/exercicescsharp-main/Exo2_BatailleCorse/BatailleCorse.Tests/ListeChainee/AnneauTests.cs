﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BatailleCorse.ListeChainee;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatailleCorse.ListeChainee.Tests
{
    [TestClass()]
    public class AnneauTests
    {
        [TestMethod()]
        public void AjouterALaFin_Ajoute_Un_NbElement_Et_Le_Premier_Retire_Est_Premier_Ajoute()
        {
            Anneau<string> testAnneau = new Anneau<string>();
            testAnneau.AjouterALaFin("Premier");
            Assert.AreEqual(1, testAnneau.NbElements);
            testAnneau.AjouterALaFin("Second");
            Assert.AreEqual(2, testAnneau.NbElements);
            Assert.AreEqual("Premier", testAnneau.RetirerPremier());
        }

        [TestMethod()]
        public void Retirer_Retire_Un_NbElement_Et_Ne_Retire_Pas_Le_Premier()
        {
            Anneau<string> testAnneau = new Anneau<string>();
            testAnneau.AjouterALaFin("Premier");
            testAnneau.AjouterALaFin("Second");
            testAnneau.Retirer("Second");
            Assert.AreEqual(1, testAnneau.NbElements);
            Assert.AreEqual("Premier", testAnneau.RetirerPremier());
        }

        [TestMethod()]
        [ExpectedException(typeof(KeyNotFoundException))]
        public void Retirer_Un_Element_Non_Existant_Lance_Une_Exception()
        {
            Anneau<string> testAnneau = new Anneau<string>();
            testAnneau.AjouterALaFin("Premier");
            testAnneau.AjouterALaFin("Second");
            testAnneau.Retirer("Troisieme");
        }

        [TestMethod()]
        public void RetirerPremier_Retire_Le_Premier_Element()
        {
            Anneau<string> testAnneau = new Anneau<string>();
            testAnneau.AjouterALaFin("Premier");
            testAnneau.AjouterALaFin("Second");
            Assert.AreEqual("Premier", testAnneau.RetirerPremier());
        }
    }
}