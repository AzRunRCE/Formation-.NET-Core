﻿using AutoMapper;
using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Interfaces.Core;
using Exo7_EF.Web.Dto;
using Exo7_EF.Web.Models;
using Microsoft.AspNetCore.Mvc;

namespace Exo7_EF.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArticlesController : Controller
    {
        private readonly IArticleService articleService;
        private readonly IMapper mapper;

        public ArticlesController(IArticleService articleService, IMapper mapper)
        {
            this.articleService = articleService;
            this.mapper = mapper;
        }

        public async Task<IActionResult> Index()
        {
            var articleList = (await articleService.GetAll()).Select(mapper.Map<ArticleViewModel>).ToList();
            return View(articleList);
        }

        public IActionResult Create()
        {
            return View();
        }

        // POST: OrderController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(ArticleViewModel article)
        {
            try
            {
                articleService.Add(mapper.Map<Article>(article));
                return RedirectToAction(nameof(Index));
            }
            catch (Exception)
            {
                return View(article);
            }
        }

        public async Task<IActionResult> Restock(int id)
        {
            var foundArticle = articleService.GetAll().Result.First(x => x.Id == id);
            return View(mapper.Map<ArticleViewModel>(foundArticle));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Restock(ArticleViewModel article)
        {
            await articleService.UpdateArticleStock(article.Id, article.StockQuantity);
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public async Task<IActionResult> GetListArticle()
        {
            var articleList = await articleService.GetAll();

            return Ok(articleList.Select(mapper.Map<ArticleDto>));
        }
    }
}
