﻿using AutoMapper;
using Exercice5.Core.Entities;
using Exercice5.MVC_Web.Models;
using System.Collections.Generic;

namespace Exercice5.MVC_Web
{
    public class WarehouseMapperProfile : Profile
    {
        public WarehouseMapperProfile()
        {
            CreateMap<Warehouse, WarehouseVM>();
            CreateMap<WarehouseVM, Warehouse>();

            CreateMap<OrderViewModel, Order>()
                .ForMember(source => source.TotalAmount, opt => opt.MapFrom(src => double.Parse(src.TotalAmount)))
                .ForMember(dest => dest.OrderDetails, opt => opt.MapFrom(src =>
                new List<OrderDetail>(src.OrderDetails.Select(x => new OrderDetail()
                {
                    Id = x.DetailId,
                    ArticleId = x.ArticleId,
                    OrderId = x.OrderId,
                    Quantity = x.Quantity,
                    UnitPrice = decimal.Parse(x.UnitPrice)
                }))));
            CreateMap<Order, OrderViewModel>()
                .ForMember(source => source.AvailableArticlesInStock, opt => opt.Ignore())
                .ForMember(source => source.CanEditQuantity, opt => opt.Ignore())
                .ForMember(source => source.TotalAmount, opt => opt.MapFrom(src => src.TotalAmount.ToString()))
                .ForMember(dest => dest.OrderDetails, opt => opt.MapFrom(src => 
                new OrderDetailViewModelList(src.OrderDetails.Select(x => new OrderDetailViewModel()
                {
                    DetailId = x.Id,
                    OrderId = x.OrderId,
                    ArticleId = x.ArticleId,
                    Quantity = x.Quantity,
                    UnitPrice = x.UnitPrice.ToString(),
                    ArticleName = x.Article != null ? x.Article.Name : ""
                }))));

            CreateMap<OrderDetail, OrderDetailViewModel>()
                .ForMember(source => source.CanEditQuantity, opt => opt.Ignore())
                .ForMember(source => source.DetailId, opt => opt.MapFrom(src => src.Id));
            CreateMap<OrderDetailViewModel, OrderDetail>()
                .ForMember(source => source.Id, opt => opt.MapFrom(src => src.DetailId));
            CreateMap<Article, ArticleViewModel>();
            CreateMap<ArticleViewModel, Article>();
        }

        /*
        
        var configuration = new MapperConfiguration(c =>
        {
            c.ReplaceMemberName("Ä", "A");
            c.ReplaceMemberName("í", "i");
            c.ReplaceMemberName("Airlina", "Airline");
        });

        var configuration = new MapperConfiguration(cfg =>
          cfg.CreateMap<Source, Destination>()
	        .ForMember(dest => dest.SomeValuefff, opt => opt.Ignore())
        );

        Si besoin de mapper à une propriété d'un membre : 
        https://docs.automapper.org/en/stable/Projection.html

        Si besoin de processing complexe sur les données lors du mappage
        https://docs.automapper.org/en/stable/Custom-value-resolvers.html

        */
    }
}
