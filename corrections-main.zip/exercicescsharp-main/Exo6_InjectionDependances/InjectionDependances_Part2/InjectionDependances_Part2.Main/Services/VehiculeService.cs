﻿namespace GarageManagementWithDotNetCore
{
    public class VehiculeService : IVehiculeService
    {
        private readonly IVehiculeRepository _VehiculeRepository;
        private readonly INotificationService _notificationService;
        private readonly ILoggingService _loggingService;

        public VehiculeService(IVehiculeRepository VehiculeRepository, INotificationService notificationService, ILoggingService loggingService)
        {
            _VehiculeRepository = VehiculeRepository;
            _notificationService = notificationService;
            _loggingService = loggingService;
        }
        public void RegisterVehicule(string Vehicule)
        {
            _VehiculeRepository.AddVehicule(Vehicule);
            _loggingService.Log($"Vehicule registered: {Vehicule}");
            _notificationService.Notify($"Vehicule registration: {Vehicule}");
        }
    }
}
