﻿using Castle.Core.Resource;
using Exo7_EF.Core.Interfaces.Core;
using Exo7_EF.Core.Interfaces.Infrastructure;
using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exo7_EF.Infrastructure.Csv.Parser;

namespace Exo7_EF.Tests
{
    [TestClass]
    public class MyCsvParserTests
    {
        [TestMethod]
        public void ArticleParser_Readline_Returns_Article_With_SameInfos()
        {
            var parser = new CsvFileParser();
            string line = "1,Ordinateur portable,Ordinateur portable haute performance,1200.00,50";

            var retour = parser.ParseLine<Article>(line);

            Assert.AreEqual(1, retour.Id);
            Assert.AreEqual("Ordinateur portable", retour.Name);
            Assert.AreEqual("Ordinateur portable haute performance", retour.Description);
            Assert.AreEqual(1200, retour.Price);
            Assert.AreEqual(50, retour.StockQuantity);
        }

        [TestMethod]
        public void OrderParser_Readline_Returns_With_SameInfos()
        {
            var parser = new CsvFileParser();
            string line = "1,2,1,guy.dubois@example.com,23 rue de Rivoli,75000,Paris,2023-01-01,420.67,Processing";

            var retour = parser.ParseLine<Order>(line);

            Assert.AreEqual(1, retour.Id);
            Assert.AreEqual(2, retour.WarehouseId);
            Assert.AreEqual(1, retour.CustomerId);
            Assert.AreEqual("guy.dubois@example.com", retour.Email);
            Assert.AreEqual("23 rue de Rivoli", retour.ShippingAddress.RoadName);
            Assert.AreEqual(75000, retour.ShippingAddress.PostalCode);
            Assert.AreEqual("Paris", retour.ShippingAddress.City);
            Assert.AreEqual(new DateTime(2023, 01, 01), retour.OrderDate);
            Assert.AreEqual(420.67, retour.TotalAmount);
            Assert.AreEqual("Processing", retour.OrderStatus);
        }

        [TestMethod]
        public void OrderDetailsParser_Readline_Returns_With_SameInfos()
        {
            var parser = new CsvFileParser();
            string line = "1,1,1,2,1200.00";

            var retour = parser.ParseLine<OrderDetail>(line);

            Assert.AreEqual(1, retour.Id);
            Assert.AreEqual(1, retour.OrderId);
            Assert.AreEqual(1, retour.ArticleId);
            Assert.AreEqual(2, retour.Quantity);
            Assert.AreEqual(1200, retour.UnitPrice);
        }

        [TestMethod]
        public void WarehouseParser_Readline_Returns_With_SameInfos()
        {
            var parser = new CsvFileParser();
            string line = "1,Entrepot de Paris, 10 Rue du CSharp,75000,Paris";

            var retour = parser.ParseLine<Warehouse>(line);

            Assert.AreEqual(1, retour.Id);
            Assert.AreEqual("Entrepot de Paris", retour.Name);
            Assert.AreEqual("10 Rue du CSharp", retour.Address.RoadName);
            Assert.AreEqual(75000, retour.Address.PostalCode);
            Assert.AreEqual("Paris", retour.Address.City);
        }

        [TestMethod]
        public void CustomerParser_Readline_Returns_With_SameInfos()
        {
            var parser = new CsvFileParser();
            string line = "1,Jean Dupont,123 Rue de la Paix,75001,Paris";

            var retour = parser.ParseLine<Customer>(line);

            Assert.AreEqual(1, retour.Id);
            Assert.AreEqual("Jean Dupont", retour.Name);
            Assert.AreEqual("123 Rue de la Paix", retour.Address.RoadName);
            Assert.AreEqual(75001, retour.Address.PostalCode);
        }

        [TestMethod]
        public void ParseAll_Adds_To_Variables()
        {
            var parser = new CsvFileParser();

            string[] fileContent =
            {
                "# Articles",
                "Id,Name,Description,Price,StockQuantity",
                "1,Ordinateur portable,Ordinateur portable haute performance,1200.00,50",
                "",
                "# Orders",
                "Id,WarehouseId,CustomerId,Email,ShippingAddress,City,OrderDate,TotalAmount,OrderStatus",
                "1,2,1,guy.dubois@example.com,23 rue de Rivoli,75000,Paris,2023-01-01,420.67,Processing",
                "",
                "# OrderDetails",
                "Id,OrderId,ArticleId,Quantity,UnitPrice",
                "1,1,1,2,1200.00",
            };

            parser.ParseAllFromFile(fileContent);

            Assert.AreEqual(1, parser.Orders.Count);
            Assert.AreEqual(1, parser.Articles.Count);
            Assert.AreEqual(1, parser.OrderDetails.Count);
        }

        [TestMethod]
        public void ParseAll_Adds_With_Same_ID()
        {
            var parser = new CsvFileParser();

            string[] fileContent =
            {
                "# Articles",
                "Id,Name,Description,Price,StockQuantity",
                "1,Ordinateur portable,Ordinateur portable haute performance,1200.00,50",
                "",
                "# Orders",
                "Id,WarehouseId,CustomerId,Email,ShippingAddress,City,OrderDate,TotalAmount,OrderStatus",
                "1,2,1,guy.dubois@example.com,23 rue de Rivoli,75000,Paris,2023-01-01,420.67,Processing",
                "",
                "# OrderDetails",
                "Id,OrderId,ArticleId,Quantity,UnitPrice",
                "1,1,1,2,1200.00",
            };

            parser.ParseAllFromFile(fileContent);

            Assert.IsTrue(parser.Orders.Any(x => x.Id == 1));
            Assert.IsTrue(parser.Articles.Any(x => x.Id == 1));
            Assert.IsTrue(parser.OrderDetails.Any(x => x.Id == 1));
        }


        [TestMethod]
        public void Parser_Getline_Article_Returns_Line_With_Same_Infos()
        {
            var parser = new CsvFileParser();
            Article article = new()
            {
                Id = 1,
                Name = "Test",
                Description = "Test Description",
                Price = 1.2m,
                StockQuantity = 5
            };
            string expectedline = "1,Test,Test Description,1.2,5";

            var retour = parser.GetLine(article);

            Assert.AreEqual(expectedline, retour);
        }

        [TestMethod]
        public void Parser_Getline_Customer_Returns_Line_With_Same_Infos()
        {
            var parser = new CsvFileParser();
            Customer toParse = new()
            {
                Id = 1,
                Name = "Jean Dupont",
                Address = new Address("123 Rue de la Paix", 75001, "Paris")
            };
            string expectedline = "1,Jean Dupont,123 Rue de la Paix,75001,Paris";

            var retour = parser.GetLine(toParse);

            Assert.AreEqual(expectedline, retour);
        }

        [TestMethod]
        public void Parser_Getline_OrderDetail_Returns_Line_With_Same_Infos()
        {
            var parser = new CsvFileParser();
            OrderDetail toParse = new()
            {
                Id = 1,
                OrderId = 2,
                ArticleId = 3,
                Quantity = 4,
                UnitPrice = 1200.00m
            };
            string expectedline = "1,2,3,4,1200";

            var retour = parser.GetLine(toParse);

            Assert.AreEqual(expectedline, retour);
        }

        [TestMethod]
        public void Parser_Getline_Order_Returns_Line_With_Same_Infos()
        {
            var parser = new CsvFileParser();
            Order toParse = new()
            {
                Id = 1,
                WarehouseId = 2,
                CustomerId = 3,
                Email = "guy.dubois@example.com",
                ShippingAddress = new Address("23 rue de Rivoli", 75000, "Paris"),
                OrderDate = new DateTime(2023, 01, 01),
                TotalAmount = 420.67,
                OrderStatus = "Processing"
            };
            string expectedline = "1,2,3,guy.dubois@example.com,23 rue de Rivoli,75000,Paris,2023-01-01,420.67,Processing";

            var retour = parser.GetLine(toParse);

            Assert.AreEqual(expectedline, retour);
        }

        [TestMethod]
        public void Parser_Getline_Warehouse_Returns_Line_With_Same_Infos()
        {
            var parser = new CsvFileParser();
            Warehouse toParse = new()
            {
                Id = 1,
                Name = "Entrepot de Paris",
                Address = new Address("10 Rue du CSharp", 75000, "Paris")
            };
            string expectedline = "1,Entrepot de Paris,10 Rue du CSharp,75000,Paris";

            var retour = parser.GetLine(toParse);

            Assert.AreEqual(expectedline, retour);
        }
    }
}
