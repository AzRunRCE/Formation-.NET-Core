﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace MyGarageApp.Options
{
    [JsonDerivedType(typeof(BarreDeToit), typeDiscriminator: "barreToit")]
    [JsonDerivedType(typeof(Climatisation), typeDiscriminator: "clim")]
    [JsonDerivedType(typeof(GPS), typeDiscriminator: "gps")]
    [JsonDerivedType(typeof(SiegeChauffant), typeDiscriminator: "siegeChauffant")]
    [JsonDerivedType(typeof(VitreElectrique), typeDiscriminator: "vitreElec")]
    public interface IOption
    {
        public double GetPrix();

        public string GetNameAndPrice()
        {
            return $"{GetType().Name} ({GetPrix()} €)";
        }
    }
}
