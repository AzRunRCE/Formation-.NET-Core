﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Exo6_EF.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class ChangementAdressesWarehouses : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "PostalCode",
                table: "Warehouses",
                newName: "Address_PostalCode");

            migrationBuilder.RenameColumn(
                name: "Address",
                table: "Warehouses",
                newName: "Address_RoadName");

            migrationBuilder.AddColumn<string>(
                name: "Address_City",
                table: "Warehouses",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Address_City",
                table: "Warehouses");

            migrationBuilder.RenameColumn(
                name: "Address_PostalCode",
                table: "Warehouses",
                newName: "PostalCode");

            migrationBuilder.RenameColumn(
                name: "Address_RoadName",
                table: "Warehouses",
                newName: "Address");
        }
    }
}
