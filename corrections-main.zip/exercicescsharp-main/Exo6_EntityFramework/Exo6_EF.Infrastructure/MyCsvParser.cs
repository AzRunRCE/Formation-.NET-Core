﻿using Exo6_EF.Core.Interfaces.Core;
using Exo6_EF.Core.Interfaces.Infrastructure;
using Exo6_EF.Core.Entities;
using Exo6_EF.Infrastructure.CsvMapping;
using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using TinyCsvParser;

namespace Ex06_EF.Infrastructure
{
    public class MyCsvParser
    {
        private readonly CsvParserOptions parserOptions;
        private readonly CsvReaderOptions readerOptions;

        private readonly CsvParser<Warehouse> warehouseParser;
        private readonly CsvParser<Customer> customerParser;
        private readonly CsvParser<Article> articleParser;
        private readonly CsvParser<Order> orderParser;
        private readonly CsvParser<OrderDetail> orderDetailParser;

        public List<Warehouse> Warehouses { get; private set; }
        public List<Customer> Customers { get; private set; }
        public List<Article> Articles { get; private set; }
        public List<Order> Orders { get; private set; }
        public List<OrderDetail> OrderDetails { get; private set; }

        public MyCsvParser()
        {
            parserOptions = new CsvParserOptions(false, ',');
            readerOptions = new CsvReaderOptions([Environment.NewLine]);

            warehouseParser = new CsvParser<Warehouse>(parserOptions, new CsvWarehouseMapping());
            customerParser = new CsvParser<Customer>(parserOptions, new CsvCustomerMapping());
            articleParser = new CsvParser<Article>(parserOptions, new CsvArticleMapping());
            orderParser = new CsvParser<Order>(parserOptions, new CsvOrderMapping());
            orderDetailParser = new CsvParser<OrderDetail>(parserOptions, new CsvOrderDetailMapping());

            Warehouses = new List<Warehouse>();
            Customers = new List<Customer>();
            Articles = new List<Article>();
            Orders = new List<Order>();
            OrderDetails = new List<OrderDetail>();
        }

        public void ParseAllFromFile(string[] fileContent)
        {
            string lastTypeDelimiter = "";

            for (int i = 0; i < fileContent.Length; i++)
            {
                if (string.IsNullOrWhiteSpace(fileContent[i]))
                    continue;

                if (fileContent[i][0] == '#')
                {
                    lastTypeDelimiter = fileContent[i];
                    i++;
                }
                else
                {
                    switch (lastTypeDelimiter)
                    {
                        default:
                        case "# Warehouses":
                            Warehouses.Add(ReadWarehouseLine(fileContent[i]));
                            break;
                        case "# Customers":
                            Customers.Add(ReadCustomerLine(fileContent[i]));
                            break;
                        case "# Articles":
                            Articles.Add(ReadArticleLine(fileContent[i]));
                            break;
                        case "# Orders":
                            Orders.Add(ReadOrderLine(fileContent[i]));
                            break;
                        case "# OrderDetails":
                            OrderDetails.Add(ReadOrderDetailLine(fileContent[i]));
                            break;
                    }
                }
            }
        }


        public Warehouse ReadWarehouseLine(string line)
        {
            return warehouseParser.ReadFromString(readerOptions, line).First().Result;
        }

        public Customer ReadCustomerLine(string line)
        {
            return customerParser.ReadFromString(readerOptions, line).First().Result;
        }

        public Article ReadArticleLine(string line)
        {
            return articleParser.ReadFromString(readerOptions, line).First().Result;
        }

        public OrderDetail ReadOrderDetailLine(string line)
        {
            return orderDetailParser.ReadFromString(readerOptions, line).First().Result;
        }

        public Order ReadOrderLine(string line)
        {
            return orderParser.ReadFromString(readerOptions, line).First().Result;
        }
    }
}
