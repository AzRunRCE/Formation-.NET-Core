﻿using AutoMapper;
using Exo7_EF.Core.Interfaces.Facades;
using Exo7_EF.Web.Models;
using Microsoft.AspNetCore.Mvc;

namespace Exo7_EF.Web.Controllers
{
    public class StatisticsController : Controller
    {
        private readonly IStatisticsFacade statisticsFacade;
        private readonly IMapper mapper;

        private const int STOCK_LIMIT = 5;

        public StatisticsController(IStatisticsFacade statisticsFacade, IMapper mapper)
        {
            this.statisticsFacade = statisticsFacade;
            this.mapper = mapper;
        }
        public async Task<IActionResult> Index()
        {
            var stats = await statisticsFacade.GetAllStatistics(STOCK_LIMIT);
            var statViewModel = mapper.Map<StatisticsViewModel>(stats);
            return View(statViewModel);
        }
    }
}
