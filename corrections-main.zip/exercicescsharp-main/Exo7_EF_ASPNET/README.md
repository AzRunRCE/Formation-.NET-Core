# Exercice 7 Entity Framework ASP.NET

## Projet Core

## Projet Infrastructure

## Projet Tests

## Projet Console

## Projet Importer
