﻿using Exo7_EF.Core.Interfaces.Core;
using Exo7_EF.Core.Interfaces.Infrastructure;
using Exo7_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ardalis.GuardClauses;
using Ardalis.Specification;
using Exo7_EF.Core.Specifications;

namespace Exo7_EF.Core.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly IRepositoryBase<Customer> customerRepository;

        public CustomerService(IRepositoryBase<Customer> customerRepository)
        {
            this.customerRepository = customerRepository;
        }

        public async Task<Customer> Add(Customer customer)
        {
            Validate(customer);
            await customerRepository.AddAsync(customer);
            return customer;
        }

        public async Task DeleteCustomer(int id)
        {
            var foundCustomer = Guard.Against.Null(await customerRepository.GetByIdAsync(id));
            await customerRepository.DeleteAsync(foundCustomer);
        }

        public async Task<List<Customer>> GetAllLight()
        {
            return await customerRepository.ListAsync();
        }

        public async Task<List<Customer>> GetAllWithOrders()
        {
            var customerList = await customerRepository.ListAsync(new GetAllCustomersWithOrders());

            return customerList;
        }

        public async Task<List<Customer>> GetBestCustomers(int numberOfCustomerToGet, int pageNumber)
        {
            var customerList = await customerRepository.ListAsync(
                new GetCustomerByTotalOrderedAmount(numberOfCustomerToGet, pageNumber)
                );

            return customerList;
        }

        public Task<int> GetCustomerCount()
        {
            return customerRepository.CountAsync();
            throw new NotImplementedException();
        }

        public async Task<Customer> UpdateAddress(int id, Address adress)
        {
            var foundCustomer = Guard.Against.Null(await customerRepository.GetByIdAsync(id));
            foundCustomer.Address = adress;
            await customerRepository.UpdateAsync(foundCustomer);
            return foundCustomer;
        }

        public async Task<Customer> UpdateName(int id, string name)
        {
            var foundCustomer = Guard.Against.Null(await customerRepository.GetByIdAsync(id));
            foundCustomer.Name = name;
            await customerRepository.UpdateAsync(foundCustomer);
            return foundCustomer;
        }

        private void Validate(Customer customer)
        {

        }

    }
}
