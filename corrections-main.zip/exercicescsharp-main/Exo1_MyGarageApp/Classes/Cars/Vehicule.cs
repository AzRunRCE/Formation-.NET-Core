﻿using Microsoft.VisualBasic.FileIO;
using MyGarageApp.Engines;
using MyGarageApp.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace MyGarageApp.Cars
{
    [Serializable]
    public class Vehicule
    {
        [JsonInclude]
        protected double prix;
        [JsonInclude]
        protected Marque nomMarque;
        [JsonInclude]
        private string nom;
        [JsonInclude]
        private List<IOption> options = new List<IOption>();
        [JsonInclude]
        private Moteur moteur;

        public Vehicule()
        {
            nom = this.GetType().Name;
        }

        public override string ToString()
        {
            return $"Voiture {GetMarque()} : {nom} {moteur} ({GetPrixHorsOptions()} €) {GetOptionsListAsHumanReadableString()} d'une valeur totale de {GetPrix().ToString("F2")} €";
        }

        public void AddOption(IOption opt)
        {
            options.Add(opt);
        }

        public void SetMoteur(Moteur moteur)
        {
            this.moteur = moteur;
        }

        public Marque GetMarque()
        {
            return nomMarque;
        }

        public List<IOption> GetOptions()
        {
            return options;
        }

        public double GetPrix()
        {
            double prixTotal = prix + moteur.GetPrix();
            options.ForEach((option) => prixTotal += option.GetPrix());
            return prixTotal;
        }

        private double GetPrixHorsOptions()
        {
            return prix + moteur.GetPrix();
        }

        private string GetOptionsListAsHumanReadableString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append('[');
            options.ForEach((option) =>
            {
                stringBuilder.Append(option.GetNameAndPrice());
                stringBuilder.Append(", ");
            });

            if (options.Count > 0)
                stringBuilder.Remove(stringBuilder.Length - 2, 2);
            
            stringBuilder.Append(']');
            return stringBuilder.ToString();
        }
    }
}
