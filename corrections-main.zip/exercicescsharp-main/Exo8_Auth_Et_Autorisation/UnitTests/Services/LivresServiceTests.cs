using Ardalis.Specification;
using Core.Dto;
using Core.Entities;
using Core.Exceptions;
using Core.Interfaces.Facades;
using Core.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using UnitTests.Extensions;

namespace UnitTests.Services
{
    [TestClass]
    public class LivresServiceTests
    {
        private readonly IRepositoryBase<Livre> emptyLivreRepo = new Mock<IRepositoryBase<Livre>>().Object;
        private readonly IUserPermissionFacade emptyUserPermissionFacade = new Mock<IUserPermissionFacade>().Object;

        [TestMethod]
        public void Can_Create_Service()
        {
            var service = new LivresService(emptyLivreRepo, emptyUserPermissionFacade);

            Assert.IsNotNull(service);
        }

        [TestMethod]
        public void GetAllLivres_Returns_All_Livres_In_Repo()
        {
            List<Livre> livreList = [GetValidLivre(id: 1), GetValidLivre(id: 2)];
            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupListWithSpecAsync<Livre, GetLivreResponse>(livreList);
            var service = new LivresService(mockLivreRepo.Object, emptyUserPermissionFacade);

            var result = service.GetAllLivres().Result;

            Assert.AreEqual(2, result.Count);
            Assert.AreEqual(1, result[0].LivreId);
            Assert.AreEqual(2, result[1].LivreId);
        }

        [TestMethod]
        public void GetLivresDisponibles_Returns_Only_Disponible_And_Approved_Livres()
        {
            List<Livre> livreList = [
                GetValidLivre(empruntStatus: EmpruntStatus.Disponible, acceptationStatus: AcceptationStatus.Approved),
                GetValidLivre(empruntStatus: EmpruntStatus.Emprunte, acceptationStatus: AcceptationStatus.Approved)];
            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupListWithSpecAsync<Livre, GetLivreResponse>(livreList);

            var service = new LivresService(mockLivreRepo.Object, emptyUserPermissionFacade);

            var disponibles = service.GetDisponibles().Result;

            Assert.AreEqual(1, disponibles.Count);
        }

        [TestMethod]
        public void GetLivresApproved_Returns_Only_Approved_Livres()
        {
            List<Livre> livreList = [
                GetValidLivre(acceptationStatus: AcceptationStatus.Approved),
                GetValidLivre(acceptationStatus: AcceptationStatus.Rejected),
                GetValidLivre(acceptationStatus: AcceptationStatus.Submitted)];

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupListWithSpecAsync<Livre, GetLivreResponse>(livreList);

            var service = new LivresService(mockLivreRepo.Object, emptyUserPermissionFacade);

            var disponibles = service.GetApproved().Result;

            Assert.AreEqual(1, disponibles.Count);
        }

        [TestMethod]
        public void GetLivresApproved_Returns_Dto_With_UserName()
        {
            var userList = new List<IdentityUser>()
            {
                new (){ Id = "premier", UserName = "Premier User"}
            };
            List<Livre> livreList = [
                GetValidLivre(acceptationStatus: AcceptationStatus.Approved, user:userList.First())];

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupListWithSpecAsync<Livre, GetLivreResponse>(livreList);

            var service = new LivresService(mockLivreRepo.Object, emptyUserPermissionFacade);

            var disponibles = service.GetApproved().Result;

            Assert.AreEqual("Premier User", disponibles[0].UserName);
        }

        [TestMethod]
        public void GetUserLivres_Returns_Only_Livres_With_Same_UserId()
        {
            var livreList = new List<Livre>() { GetValidLivre(id: 1, userId: "premier"), GetValidLivre(id: 2, userId: "second") };

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupListWithSpecAsync<Livre, GetLivreResponse>(livreList);

            var service = new LivresService(mockLivreRepo.Object, emptyUserPermissionFacade);

            var userLivres = service.GetFromUser("second").Result;

            Assert.AreEqual(1, userLivres.Count);
            Assert.AreEqual(2, userLivres[0].LivreId);
        }

        [TestMethod]
        public void GetSubmittedLivres_Returns_Only_Livres_With_Submitted_Status()
        {
            var livreList = new List<Livre>() {
                GetValidLivre(acceptationStatus: AcceptationStatus.Submitted),
                GetValidLivre(acceptationStatus: AcceptationStatus.Approved)
            };

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupListWithSpecAsync<Livre, GetLivreResponse>(livreList);

            var service = new LivresService(mockLivreRepo.Object, emptyUserPermissionFacade);

            var userLivres = service.GetSubmittedLivres().Result;

            Assert.AreEqual(1, userLivres.Count);
            Assert.AreEqual(AcceptationStatus.Submitted, userLivres[0].AcceptationStatus);
        }

        [TestMethod]
        public void GetLivre_Returns_Livre_With_Same_Id()
        {
            var livreList = new List<Livre>() { GetValidLivre(id: 1), GetValidLivre(id: 2) };
            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupGetByIdAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, emptyUserPermissionFacade);

            var livre = service.GetOne(2).Result;

            Assert.AreEqual(2, livre.LivreId);
        }

        [TestMethod]
        public void GetLivreWithItsUser_Returns_Livre_With_Username()
        {
            var livreList = new List<Livre>() { GetValidLivre(id: 1), GetValidLivre(id: 2, user: new IdentityUser() { UserName = "NameTest" }) };
            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupFirstAsync<Livre, GetLivreResponse>(livreList);

            var service = new LivresService(mockLivreRepo.Object, emptyUserPermissionFacade);

            var livre = service.GetOneWithItsUser(2).Result;

            Assert.AreEqual(2, livre.LivreId);
            Assert.AreEqual("NameTest", livre.UserName);
        }

        [TestMethod]
        public void Delete_Removes_One_Item_InRepo()
        {
            var userList = new List<IdentityUser>()
            {
                new (){ Id = "premier"}
            };
            var livreList = new List<Livre>() {
                GetValidLivre(id : 1 , userId : userList.First().Id),
                GetValidLivre(id : 2 , userId : userList.First().Id)};
            Livre toDelete = livreList.First();

            var mockUserRepo = new Mock<IUserPermissionFacade>()
                .SetupIsAnthenticUser(userList);

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupGetByIdAsync(livreList)
                .SetupDeleteAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, mockUserRepo.Object);

            service.Delete(new DeleteLivreRequete(toDelete.LivreId, userList.First())).Wait();

            Assert.AreEqual(1, livreList.Count);
        }

        [TestMethod]
        public void Delete_Removes_Item_With_Same_Id()
        {
            var userList = new List<IdentityUser>()
            {
                new (){ Id = "premier"}
            };
            var livreList = new List<Livre>() {
                GetValidLivre(id : 1 , userId : userList.First().Id),
                GetValidLivre(id : 2 , userId : userList.First().Id)};
            Livre toDelete = livreList.First();

            var mockUserRepo = new Mock<IUserPermissionFacade>()
                .SetupIsAnthenticUser(userList);

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupGetByIdAsync(livreList)
                .SetupDeleteAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, mockUserRepo.Object);

            service.Delete(new DeleteLivreRequete(toDelete.LivreId, userList.First())).Wait();

            Assert.IsFalse(livreList.Any(x => x.LivreId == toDelete.LivreId));
        }

        [TestMethod]
        public void Delete_Refuse_Si_Livre_Appartient_Pas_Au_User()
        {
            var userQuiALivres = new IdentityUser();
            var userSansLivres = new IdentityUser();

            List<IdentityUser> userList = [userQuiALivres, userSansLivres];

            var livreList = new List<Livre>()
            {
                GetValidLivre(id : 1 , user : userQuiALivres),
                GetValidLivre(id : 2 , user : userQuiALivres)
            };

            Livre toDelete = livreList.First();

            var mockUserRepo = new Mock<IUserPermissionFacade>()
                .SetupIsAnthenticUser(userList);

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupGetByIdAsync(livreList)
                .SetupDeleteAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, mockUserRepo.Object);

            Assert.ThrowsExceptionAsync<OperationRefusedException>(() =>
                service.Delete(new DeleteLivreRequete(toDelete.LivreId, userSansLivres))).Wait();
        }

        [TestMethod]
        public void Delete_Refuse_Si_Utilisateur_Invalide()
        {
            var userQuiALivres = new IdentityUser() { Id = "premier", SecurityStamp = "TEST" };

            List<IdentityUser> userList = [userQuiALivres];

            var livreList = new List<Livre>()
            {
                GetValidLivre(id : 1 , user : userQuiALivres),
                GetValidLivre(id : 2 , user : userQuiALivres)
            };

            Livre toDelete = livreList.First();

            var mockUserRepo = new Mock<IUserPermissionFacade>()
                .SetupIsAnthenticUser(userList);

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupGetByIdAsync(livreList)
                .SetupDeleteAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, mockUserRepo.Object);

            Assert.ThrowsExceptionAsync<OperationRefusedException>(() =>
                service.Delete(new DeleteLivreRequete(toDelete.LivreId,
                    new IdentityUser() { Id = "premier", SecurityStamp = "NOTTHEONE" }))).Wait();
        }

        [TestMethod]
        public void UpdateContent_Modifie_Livre_Avec_Meme_Id()
        {
            var userList = new List<IdentityUser>()
            {
                new (){ Id = "premier"}
            };
            var livreList = new List<Livre>() {
                GetValidLivre(id : 1 , userId : userList.First().Id),
                GetValidLivre(id : 2 , userId : userList.First().Id)};

            Livre toUpdate = GetValidLivre(id: 1, userId: userList.First().Id);

            var mockUserRepo = new Mock<IUserPermissionFacade>()
                .SetupIsAnthenticUser(userList);

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupGetByIdAsync(livreList)
                .SetupUpdateAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, mockUserRepo.Object);

            service.UpdateContent(new UpdateContentLivreRequete(toUpdate.LivreId, "Modifi�", userList.First())).Wait();

            Assert.AreEqual("Modifi�", livreList.First().Content);
        }

        [TestMethod]
        public void UpdateContent_Refuse_Si_Livre_Appartient_Pas_Au_User()
        {
            var userQuiALivres = new IdentityUser();
            var userSansLivres = new IdentityUser();

            List<IdentityUser> userList = [userQuiALivres, userSansLivres];

            var livreList = new List<Livre>()
            {
                GetValidLivre(id : 1 , user : userQuiALivres),
                GetValidLivre(id : 2 , user : userQuiALivres)
            };

            Livre toUpdate = livreList.First();

            var mockUserRepo = new Mock<IUserPermissionFacade>()
                .SetupIsAnthenticUser(userList);

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupGetByIdAsync(livreList)
                .SetupDeleteAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, mockUserRepo.Object);

            Assert.ThrowsExceptionAsync<OperationRefusedException>(() =>
                service.UpdateContent(new UpdateContentLivreRequete(toUpdate.LivreId, "Modifi�", userSansLivres))).Wait();
        }

        [TestMethod]
        public void UpdateContent_Refuse_Si_Utilisateur_Invalide()
        {
            var userQuiALivres = new IdentityUser() { Id = "premier", SecurityStamp = "TEST" };

            List<IdentityUser> userList = [userQuiALivres];

            var livreList = new List<Livre>()
            {
                GetValidLivre(id : 1 , user : userQuiALivres)
            };

            Livre toUpdate = livreList.First();

            var mockUserRepo = new Mock<IUserPermissionFacade>()
                .SetupIsAnthenticUser(userList);

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupGetByIdAsync(livreList)
                .SetupDeleteAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, mockUserRepo.Object);

            toUpdate.Content = "Modifi�";

            Assert.ThrowsExceptionAsync<OperationRefusedException>(() =>
                service.UpdateContent(new UpdateContentLivreRequete(toUpdate.LivreId, "Modifi�",
                    new IdentityUser() { Id = "premier", SecurityStamp = "NOTTHEONE" }))).Wait();
        }


        [TestMethod]
        public void UpdateAcceptationStatus_Modifie_Status_Livre_Avec_Meme_Id()
        {

            var userList = new List<IdentityUser>()
            {
                new (){ Id = "premier"}
            };
            var livreList = new List<Livre>() {
                GetValidLivre(id : 1 , userId : userList.First().Id),
                GetValidLivre(id : 2 , userId : userList.First().Id)};

            Livre toUpdate = GetValidLivre(id: 1, userId: userList.First().Id);

            var mockUserRepo = new Mock<IUserPermissionFacade>()
                .SetupIsAnthenticUser(userList);

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupGetByIdAsync(livreList)
                .SetupUpdateAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, mockUserRepo.Object);

            service.UpdateAcceptationStatus(new UpdateAcceptationLivreRequete(toUpdate.LivreId, userList.First(), AcceptationStatus.Approved)).Wait();

            Assert.AreEqual(AcceptationStatus.Approved, livreList.First().AcceptationStatus);
        }

        [TestMethod]
        public void UpdateAcceptationStatus_Refuse_Si_Utilisateur_Pas_Bibliothecaire()
        {
            var userQuiALivres = new IdentityUser() { Id = "premier", SecurityStamp = "TEST" };

            List<IdentityUser> userList = [userQuiALivres];

            var livreList = new List<Livre>()
            {
                GetValidLivre(id : 1 , user : userQuiALivres)
            };

            Livre toUpdate = livreList.First();

            var mockUserRepo = new Mock<IUserPermissionFacade>()
                .SetupIsAnthenticUser(userList);

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupGetByIdAsync(livreList)
                .SetupDeleteAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, mockUserRepo.Object);

            Assert.ThrowsExceptionAsync<OperationRefusedException>(() =>
                service.UpdateAcceptationStatus(new UpdateAcceptationLivreRequete(toUpdate.LivreId,
                    new IdentityUser() { Id = "premier", SecurityStamp = "NOTTHEONE" }, AcceptationStatus.Approved))).Wait();
        }


        [TestMethod]
        public void UpdateEmpruntStatus_Modifie_Status_Livre_Avec_Meme_Id()
        {

            var userList = new List<IdentityUser>()
            {
                new (){ Id = "premier"}
            };
            var livreList = new List<Livre>() {
                GetValidLivre(id : 1 , userId : userList.First().Id, empruntStatus: EmpruntStatus.Disponible),
                GetValidLivre(id : 2 , userId : userList.First().Id, empruntStatus: EmpruntStatus.Disponible)};

            Livre toUpdate = GetValidLivre(id: 1, userId: userList.First().Id);

            var mockUserRepo = new Mock<IUserPermissionFacade>()
                .SetupIsAnthenticUser(userList);

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupGetByIdAsync(livreList)
                .SetupUpdateAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, mockUserRepo.Object);

            service.UpdateEmpruntStatus(new UpdateEmpruntStatusRequete(toUpdate.LivreId, userList.First(), EmpruntStatus.Emprunte)).Wait();

            Assert.AreEqual(EmpruntStatus.Emprunte, livreList.First().EmpruntStatus);
        }

        [TestMethod]
        public void UpdateEmpruntStatus_Refuse_Si_Utilisateur_Pas_Bibliothecaire()
        {
            var userQuiALivres = new IdentityUser() { Id = "premier", SecurityStamp = "TEST" };

            List<IdentityUser> userList = [userQuiALivres];

            var livreList = new List<Livre>()
            {
                GetValidLivre(id : 1 , user : userQuiALivres)
            };

            Livre toUpdate = livreList.First();

            var mockUserRepo = new Mock<IUserPermissionFacade>()
                .SetupIsAnthenticUser(userList);

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupGetByIdAsync(livreList)
                .SetupDeleteAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, mockUserRepo.Object);

            Assert.ThrowsExceptionAsync<OperationRefusedException>(() =>
                service.UpdateEmpruntStatus(new UpdateEmpruntStatusRequete(toUpdate.LivreId,
                    new IdentityUser() { Id = "premier", SecurityStamp = "NOTTHEONE" }, EmpruntStatus.Emprunte))).Wait();
        }

        [TestMethod]
        public void Create_Ajoute_Element_Avec_Meme_Id_Dans_Repo()
        {
            IdentityUser user = new() { Id = "premier" };
            var livreList = new List<Livre>()
            {
                GetValidLivre(id:1),
            };

            var mockUserRepo = new Mock<IUserPermissionFacade>()
                .SetupIsAnthenticUser([user]);

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupAddAsync(livreList)
                .SetupDeleteAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, mockUserRepo.Object);

            service.Create(new CreateLivreRequete("toAdd", user)).Wait();

            Assert.IsTrue(livreList.Any(x => x.Content == "toAdd"));
        }

        [TestMethod]
        public void Admin_Peut_Editer_Livre_Qui_Ne_Lui_Appartient_Pas()
        {
            var userQuiALivres = new IdentityUser() { Id = "premier" };
            var admin = new IdentityUser() { Id = "second_admin" };

            List<IdentityUser> userList = [userQuiALivres, admin];

            var livreList = new List<Livre>()
            {
                GetValidLivre(id : 1 , user : userQuiALivres, content:"BaseContent"),
            };

            Livre toUpdate = GetValidLivre(id: 1, user: userQuiALivres, content: "BaseContent");

            var mockUserRepo = new Mock<IUserPermissionFacade>()
                .SetupIsAnthenticUser(userList)
                .SetupIsAdmin([admin]);

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupGetByIdAsync(livreList)
                .SetupUpdateAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, mockUserRepo.Object);

            service.UpdateContent(new UpdateContentLivreRequete(toUpdate.LivreId, "UpdatedContent", admin)).Wait();

            Assert.AreEqual("UpdatedContent", livreList.First().Content);
        }

        [TestMethod]
        public void Admin_Peut_Supprimer_Livre()
        {
            var userQuiALivres = new IdentityUser() { Id = "premier" };
            var admin = new IdentityUser() { Id = "second_admin" };

            List<IdentityUser> userList = [userQuiALivres, admin];

            int toDelete = 1;
            var livreList = new List<Livre>()
            {
                GetValidLivre(id : toDelete , user : userQuiALivres, content:"BaseContent"),
            };


            var mockUserRepo = new Mock<IUserPermissionFacade>()
                .SetupIsAnthenticUser(userList)
                .SetupIsAdmin([admin]);

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupGetByIdAsync(livreList)
                .SetupDeleteAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, mockUserRepo.Object);

            service.Delete(new DeleteLivreRequete(toDelete, admin)).Wait();

            Assert.IsFalse(livreList.Any(x => x.LivreId == toDelete));
            Assert.AreEqual(0, livreList.Count);
        }

        [TestMethod]
        public void User_Non_Admin_Peut_Pas_Supprimer_Livre()
        {
            var userQuiALivres = new IdentityUser() { Id = "premier" };
            var admin = new IdentityUser() { Id = "second_admin" };
            var userQuiSupprime = new IdentityUser() { Id = "troisieme" };

            List<IdentityUser> userList = [userQuiALivres, admin, userQuiSupprime];
            int toDelete = 1;
            var livreList = new List<Livre>()
            {
                GetValidLivre(id : toDelete , user : userQuiALivres, content:"BaseContent"),
            };


            var mockUserRepo = new Mock<IUserPermissionFacade>()
                .SetupIsAnthenticUser(userList)
                .SetupIsAdmin([admin]);

            var mockLivreRepo = new Mock<IRepositoryBase<Livre>>()
                .SetupGetByIdAsync(livreList)
                .SetupDeleteAsync(livreList);

            var service = new LivresService(mockLivreRepo.Object, mockUserRepo.Object);

            Assert.ThrowsExceptionAsync<OperationRefusedException>(() => service.Delete(new DeleteLivreRequete(toDelete, userQuiSupprime))).Wait();
        }

        private Livre GetValidLivre(
            int id = 0,
            string content = "",
            IdentityUser? user = null,
            string userId = "",
            EmpruntStatus empruntStatus = 0,
            AcceptationStatus acceptationStatus = 0)
        {
            return new Livre()
            {
                LivreId = id,
                Content = content == string.Empty ? "Test" : content,
                User = user ?? new(),
                UserId = user == null && userId == "" ? "TestUserId" : userId,
                EmpruntStatus = empruntStatus,
                AcceptationStatus = acceptationStatus
            };
        }
    }
}