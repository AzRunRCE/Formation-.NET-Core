﻿using DemoTrip.Core.Dtos;

namespace DemoTrip.Core.Interfaces
{
    public interface ISearchHotelUseCase
    {
        Task<SearchHotelResponse> Execute(SearchHotelRequest request);
    }
}