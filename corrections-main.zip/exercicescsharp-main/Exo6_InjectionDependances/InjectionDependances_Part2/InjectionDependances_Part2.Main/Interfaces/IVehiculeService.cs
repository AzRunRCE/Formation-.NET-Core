﻿namespace GarageManagementWithDotNetCore
{
    public interface IVehiculeService
    {
        void RegisterVehicule(string Vehicule);
    }
}
