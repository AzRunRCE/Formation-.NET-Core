﻿using Exo6_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo6_EF.Core.Interfaces.Core
{
    public interface IWarehouseService
    {
        // Method to fetch all warehouses
        IQueryable<Warehouse> GetAllWarehouses();
        Warehouse Add(Warehouse toAdd);
    }
}
