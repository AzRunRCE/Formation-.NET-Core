﻿using Core.Entities;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel;

namespace Web.Models
{
    public class LivreViewModel
    {
        public int LivreId { get; set; }
        public string Content { get; set; }

        [ReadOnly(true)]
        public DateTime CreatedDate { get; set; }
        public AcceptationStatus AcceptationStatus { get; set; }
        public EmpruntStatus EmpruntStatus { get; set; }
        public string? UserName { get; set; }
    }
}
