﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ExoLINQ.Main.Entities;

namespace ExoLINQ.Main
{
    internal class Exercice5 : ExerciceBase
    {
        public Exercice5() { number = 5; name = "Requêtes et listes à 2 dimensions"; }
        protected override void Content()
        {
            List<List<Personne>> personnes = new List<List<Personne>>
            {
                new List<Personne>() {new Personne("Drucker", "Michel"),
                                      new Personne("Bedia", "Ramzy"),
                                      new Personne("Judor", "Eric")},

                new List<Personne>() {new Personne("Diaz", "Cameron"),
                                      new Personne("Depardieu", "Gerard"),
                                      new Personne("Stallone", "Sylvester"),
                                      new Personne("Macron", "Emmanuel")},

                new List<Personne>() {new Personne("Benzema", "Karim"),
                                      new Personne("Antoine", "Eric"),
                                      new Personne("Ruiz", "Olivia"),
                                      new Personne("Clavier", "Christian"),
                                      new Personne("Einstein", "Albert")}
            };


            //1. Récupérer tous les noms dont la longueur est supérieure à 5
            var query = personnes.SelectMany(ps => ps.Where(p => p.Nom.Length > 5));
            ConformRequestResult(query, x => $"{x.Nom} {x.Prenom}");

            //2. Récupérer tous les noms contenant un "e"
            //Récupérer tous les prénoms contenant un "a"
            //Trier par nom (tri décroissant)
            //Créer un objet anonyme avec un attribut identite = prénom+" "+nom
            var query2 = personnes.SelectMany(ps => ps.Where(p => p.Nom.Contains('e') && p.Prenom.Contains('a')))
                .OrderByDescending(p => p.Nom).Select(p => new {identite = $"{p.Prenom} {p.Nom}"});
            ConformRequestResult(query2, x => x.identite);


            //3. Récupérer toutes les listes qui contiennent plus de 4 personnes
            //Récupérer les personnes dont le nom commence par "A" ou "B" ou "C"
            //Trier les personnes par prénom (tri croissant)
            //Créer un objet anonyme avec l'attribut "initiale" = 1ère lettre du prénom+"."+1ère lettre du nom
            char[] NameFilter = { 'A', 'B', 'C' };
            var query3 = personnes.Where(ps => ps.Count > 4).SelectMany(ps => ps.Where(p => NameFilter.Any(c => c == p.Nom[0])))
                .OrderBy(p => p.Prenom).Select(p => new {initiale = $"{p.Prenom[0]}.{p.Nom[0]}" });
            ConformRequestResult(query3, x => x.initiale);


            //4. Récupérer toutes les listes qui contiennent moins de 5 personnes
            //Afficher toutes les personnes comme ceci : Nom+" "+Prenom
            var query4 = personnes.Where(ps => ps.Count < 5).SelectMany(ps => ps);
            ConformRequestResult(query4, x => x.Nom + " " + x.Prenom);

            //Affichage du résultat de la requête
            //           foreach (var item in query3)
            //           {
            //               Console.WriteLine(item.Nom + " " + item.Prenom);
            //           }
        }
    }
}
