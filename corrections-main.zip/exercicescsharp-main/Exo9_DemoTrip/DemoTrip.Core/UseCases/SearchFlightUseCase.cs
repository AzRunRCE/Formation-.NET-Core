﻿using Ardalis.Specification;
using DemoTrip.Core.Dtos;
using DemoTrip.Core.Entities;
using DemoTrip.Core.Interfaces;
using DemoTrip.Core.Specifications;

namespace DemoTrip.Core.UseCases
{
    public class SearchFlightUseCase(IReadRepositoryBase<Flight> flightRepository) : ISearchFlightUseCase
    {
        public async Task<SearchFlightResponse> Execute(SearchFlightRequest request)
        {
            var flightsList = (await flightRepository.ListAsync(new GetFlightsFromRequest(request)))
                .OrderByDescending(x => x.Price).ToList();
            return new SearchFlightResponse(flightsList.Count != 0, flightsList);
        }
    }
}
