﻿using Ardalis.GuardClauses;
using Exo6_EF.Core.Entities;
using Exo6_EF.Core.Interfaces.Core;
using Exo6_EF.Core.Interfaces.Infrastructure;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo6_EF.Core.Services
{
    public class ArticleService : IArticleService
    {
        private readonly IArticleRepository articleRepository;
        private readonly IOrderRepository orderRepository;

        public ArticleService(IArticleRepository articleRepository, IOrderRepository orderRepository)
        {
            this.articleRepository = articleRepository;
            this.orderRepository = orderRepository;
        }

        public Article Add(Article article)
        {
            ValidateArticle(article);
            articleRepository.Add(article);
            return article;
        }

        public IQueryable<Article> GetArticlesBelowStock(int stock)
        {
            return articleRepository.GetAll().Where(x => x.StockQuantity <= stock);
        }

        public Dictionary<Article, int> GetTotalSalesPerArticle()
        {
            var allOrderDetails = orderRepository.GetAll().SelectMany(x => x.OrderDetails);
            var salesPerArticle = articleRepository.GetAll().ToDictionary(
                x => x, 
                x => allOrderDetails
                    .Where(od => od.ArticleId == x.Id)
                    .Sum(od => od.Quantity));
            return salesPerArticle;
        }

        public Article UpdateArticleStock(int itemId, int quantity)
        {
            var article = articleRepository.GetAll().First(x => x.Id == itemId);
            article.StockQuantity = quantity;
            articleRepository.Update(itemId, article);
            return article;
        }

        private void ValidateArticle(Article article)
        {
            Guard.Against.NegativeOrZero(article.Price);
        }
    }
}
