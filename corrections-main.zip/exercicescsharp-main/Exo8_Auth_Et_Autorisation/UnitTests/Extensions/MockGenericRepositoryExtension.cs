﻿using Ardalis.Specification;
using Core.Entities;
using Microsoft.AspNetCore.Identity;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTests.Extensions
{
    internal static class MockGenericRepositoryExtension
    {

        public static Mock<IRepositoryBase<T>> SetupDeleteAsync<T>(this Mock<IRepositoryBase<T>> mock, List<T> list) where T : class
        {
            mock.Setup(x => x.DeleteAsync(It.IsAny<T>(), default))
                .Callback<T, CancellationToken>((livre, token) => list.Remove(livre));
            return mock;
        }

        public static Mock<IRepositoryBase<T>> SetupListAllAsync<T>(this Mock<IRepositoryBase<T>> mock, List<T> list) where T : class
        {
            mock.Setup(x => x.ListAsync(default)).ReturnsAsync(list);
            return mock;
        }

        public static Mock<IRepositoryBase<T>> SetupListWithSpecAsync<T>(this Mock<IRepositoryBase<T>> mock, List<T> list) where T : class
        {
            mock.Setup(x => x.ListAsync(It.IsAny<Specification<T>>(), default))
                .ReturnsAsync((Specification<T> spec, CancellationToken token) =>
                spec.Evaluate(list)
                .ToList());
            return mock;
        }

        public static Mock<IRepositoryBase<T>> SetupFirstAsync<T,U>(this Mock<IRepositoryBase<T>> mock, List<T> list) where T : class
        {
            mock.Setup(x => x.FirstOrDefaultAsync(It.IsAny<Specification<T,U>>(), default))
                .ReturnsAsync((Specification<T,U> spec, CancellationToken token) =>
                spec.Evaluate(list).FirstOrDefault());
            return mock;
        }

        public static Mock<IRepositoryBase<T>> SetupListWithSpecAsync<T,U>(this Mock<IRepositoryBase<T>> mock, List<T> list) where T : class
        {
            mock.Setup(x => x.ListAsync(It.IsAny<Specification<T,U>>(), default))
                .ReturnsAsync((Specification<T,U> spec, CancellationToken token) =>
                spec.Evaluate(list)
                .ToList());
            return mock;
        }

        public static Mock<IRepositoryBase<T>> SetupAddAsync<T>(this Mock<IRepositoryBase<T>> mock, List<T> list) where T : class
        {
            mock.Setup(x => x.AddAsync(It.IsAny<T>(), default))
                .Callback((T toAdd, CancellationToken token) =>
                list.Add(toAdd)).ReturnsAsync((T element, CancellationToken token) => element);
            return mock;
        }

        internal static void SetupUpdateAsync<T, U>(Mock<IRepositoryBase<T>> mock, List<T> list, Func<T, U> selector) where T : class
        {
            mock.Setup(x => x.UpdateAsync(It.IsAny<T>(), default))
                .Callback((T toEdit, CancellationToken token) =>
                list[list.FindIndex(x => Equals(selector(x), selector(toEdit)))] = toEdit);
        }

        internal static void SetupGetByIdAsync<T, U>(Mock<IRepositoryBase<T>> mock, List<T> list, Func<T, U> selector) where T : class where U : notnull
        {
            mock.Setup(x => x.GetByIdAsync(It.IsAny<U>(), default))
                .Returns<U, CancellationToken>((id, token) => Task.FromResult(list.FirstOrDefault(x => Equals(selector(x), id))));
        }
    }
}
