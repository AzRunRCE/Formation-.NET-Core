using Ardalis.Specification;
using DemoTrip.Core.Entities;
using DemoTrip.Core.Interfaces;
using DemoTrip.Core.UseCases;
using DemoTrip.Infrastructure;
using DemoTrip.Infrastructure.Csv;

namespace DemoTrip.Web
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();
            builder.Services
                .AddScoped<ISearchFlightUseCase, SearchFlightUseCase>()
                .AddScoped<ISearchHotelUseCase, SearchHotelUseCase>()
                .AddTransient<IReadRepositoryBase<Flight>>(provider => new CsvRepository<Flight>("C:\\Users\\remi.lesert\\source\\repos\\ExercicesCsharp\\Exo9_DemoTrip\\DemoTrip.Infrastructure\\flights_with_names.csv", new FlightCsvParser()))
                .AddTransient<IReadRepositoryBase<Hotel>>(provider => new CsvRepository<Hotel>("C:\\Users\\remi.lesert\\source\\repos\\ExercicesCsharp\\Exo9_DemoTrip\\DemoTrip.Infrastructure\\hotels.csv", new HotelCsvParser()));

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
