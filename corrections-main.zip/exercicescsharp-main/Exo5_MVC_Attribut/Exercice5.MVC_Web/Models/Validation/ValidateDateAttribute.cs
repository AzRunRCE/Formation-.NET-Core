﻿
using System.ComponentModel.DataAnnotations;

namespace Exercice5.MVC_Web.Models.Validation
{
    public class ValidateDateAttribute : ValidationAttribute
    {
        public ValidateDateAttribute()
        {
            const string defaultErrorMessage = "Error with Date";
            ErrorMessage ??= defaultErrorMessage;
        }

        protected override ValidationResult? IsValid(object? value,
                                             ValidationContext validationContext)
        {
            if (value == null || string.IsNullOrWhiteSpace(value.ToString()))
            {
                return new ValidationResult("Date is required.");
            }

            if (!DateTime.TryParse(value.ToString(), out DateTime valueDate))
            {

                return new ValidationResult(
                            FormatErrorMessage(validationContext.DisplayName));
            }

            return ValidationResult.Success;
        }
    }
}