﻿using Ardalis.Specification;
using Core.Entities;
using Core.Interfaces.Facades;
using Microsoft.AspNetCore.Identity;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTests.Extensions
{
    internal static class MockUserPermissionFacadeExtension
    {
        public static Mock<IUserPermissionFacade> SetupIsAnthenticUser(this Mock<IUserPermissionFacade> mock, List<IdentityUser> list)
        {
            mock.Setup(x => x.IsValidUser(It.IsAny<IdentityUser>()))
                .ReturnsAsync((IdentityUser user) => { return list.Contains(user); });
            return mock;
        }

        public static Mock<IUserPermissionFacade> SetupIsAdmin(this Mock<IUserPermissionFacade> mock, List<IdentityUser> adminList)
        {
            mock.Setup(x => x.IsAdmin(It.IsAny<string>()))
                .ReturnsAsync((string userId) => { return adminList.Any(x => x.Id == userId); });
            return mock;
        }
    }
}
