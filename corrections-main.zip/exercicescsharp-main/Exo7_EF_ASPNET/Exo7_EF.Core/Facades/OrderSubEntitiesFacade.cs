﻿using Ardalis.GuardClauses;
using Ardalis.Specification;
using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Interfaces.Facades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Core.Facades
{
    public class OrderSubEntitiesFacade : IOrderSubEntitiesFacade
    {
        private readonly IRepositoryBase<Customer> customerRepository;
        private readonly IRepositoryBase<Warehouse> warehouseRepository;
        private readonly IRepositoryBase<Article> articleRepository;

        public OrderSubEntitiesFacade(IRepositoryBase<Customer> customerRepository, IRepositoryBase<Warehouse> warehouseRepository, IRepositoryBase<Article> articleRepository)
        {
            this.customerRepository = customerRepository;
            this.warehouseRepository = warehouseRepository;
            this.articleRepository = articleRepository;
        }

        public async Task RecoverWarehouseCustomerAndArticleFromRepositories(Order order)
        {
            order.Warehouse ??= Guard.Against.Null(await warehouseRepository.GetByIdAsync(order.WarehouseId));
            order.Customer ??= Guard.Against.Null(await customerRepository.GetByIdAsync(order.CustomerId));

            var articleList = await articleRepository.ListAsync();

            order.OrderDetails.ForEach(detail =>
            {
                detail.Article ??= articleList.First(x => x.Id == detail.ArticleId);
            });
        }
    }
}
