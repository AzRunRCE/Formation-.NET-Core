﻿namespace Exo6_EF.Core.Entities
{
    public class Order
    {
        public int Id { get; set; }

        public int CustomerId { get; set; }
        public Customer Customer { get; set; }

        public string Email { get; set; }

        public Address ShippingAddress { get; set; }

        public DateTime OrderDate { get; set; }

        public double TotalAmount { get; set; }

        public string OrderStatus { get; set; }

        public List<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();

        public int WarehouseId { get; set; }
        public Warehouse Warehouse { get;  set; }
        //public Customer Customer { get; set; }
    }
}
