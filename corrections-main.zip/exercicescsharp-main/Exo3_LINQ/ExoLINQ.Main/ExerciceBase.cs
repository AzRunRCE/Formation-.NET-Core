﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExoLINQ.Main
{
    internal abstract class ExerciceBase
    {
        protected int number = -1;
        protected string name = "undefined";
        private int questionNumber = 1;

        protected abstract void Content();

        public void Run()
        {
            if (number < 0)
            {
                Console.WriteLine($"Exercice not configured : {GetType().Name}");
                return;
            }
            Console.WriteLine($"Exercice {number} : {name}");
            Console.WriteLine();

            Content();
            Console.WriteLine("===========================");
            Console.WriteLine();
        }

        protected void ConformRequestResult<T, U>(IEnumerable<T> list, Func<T, U> ToStringAction) where U : IConvertible
        {
            Console.WriteLine($"Question {questionNumber}.");
            Console.Write("   - ");
            list.Take(list.Count() - 1).ToList().ForEach(x => Console.Write($"{ToStringAction(x)}, "));
            Console.WriteLine($"{ToStringAction(list.Last())}");
            Console.WriteLine();
            questionNumber++;
        }
    }
}
