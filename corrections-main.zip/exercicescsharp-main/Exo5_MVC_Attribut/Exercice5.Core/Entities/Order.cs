﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice5.Core.Entities
{
    public class Order
    {
        public int Id { get; set; }


        public string CustomerName { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string ShippingAddress { get; set; } = string.Empty;

        public DateTime OrderDate { get; set; }

        public double TotalAmount { get; set; }

        public OrderStatus Status { get; set; }

        public List<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
        public int WarehouseId { get; set; }
    }
}
