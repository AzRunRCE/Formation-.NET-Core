﻿using Ardalis.Specification;
using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Interfaces.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
#if false
namespace Exo7_EF.Infrastructure.Repositories.Csv
{
    public class CsvWarehouseRepository : IRepositoryBase<Warehouse>
    {
        public Task Add(Warehouse newWarehouse)
        {
            if (context.Warehouses.Any(x => x.Id == newWarehouse.Id))
                throw new Exception($"This Id already exist. Use x different ID than {newWarehouse.Id}");

            context.Warehouses.Add(newWarehouse);

            return context.SaveAsync();
        }

        public Task<Warehouse> AddAsync(Warehouse entity, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<Warehouse>> AddRangeAsync(IEnumerable<Warehouse> entities, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<bool> AnyAsync(ISpecification<Warehouse> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<bool> AnyAsync(CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public IAsyncEnumerable<Warehouse> AsAsyncEnumerable(ISpecification<Warehouse> specification)
        {
            throw new NotImplementedException();
        }

        public Task<int> CountAsync(ISpecification<Warehouse> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<int> CountAsync(CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task Delete(int id)
        {
            context.Warehouses.Remove(context.Warehouses.First(x => x.Id == id));
            return context.SaveAsync();
        }

        public Task DeleteAsync(Warehouse entity, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task DeleteRangeAsync(IEnumerable<Warehouse> entities, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task DeleteRangeAsync(ISpecification<Warehouse> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<Warehouse?> FirstOrDefaultAsync(ISpecification<Warehouse> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<TResult?> FirstOrDefaultAsync<TResult>(ISpecification<Warehouse, TResult> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<List<Warehouse>> GetAll()
        {
            return Task.FromResult(context.Warehouses.ToList());
        }

        public Task<List<Warehouse>> GetAll(Func<IQueryable<Warehouse>, IQueryable<Warehouse>> filter)
        {
            return Task.FromResult(filter(context.Warehouses.AsQueryable()).ToList());
        }

        public Task<Warehouse> GetById(int id)
        {
            var found = context.Warehouses.First(x => x.Id == id);
            return Task.FromResult(found);
        }

        public Task<Warehouse?> GetByIdAsync<TId>(TId id, CancellationToken cancellationToken = default) where TId : notnull
        {
            throw new NotImplementedException();
        }

        public Task<Warehouse?> GetBySpecAsync(ISpecification<Warehouse> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<TResult?> GetBySpecAsync<TResult>(ISpecification<Warehouse, TResult> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<List<Warehouse>> ListAsync(CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<List<Warehouse>> ListAsync(ISpecification<Warehouse> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<List<TResult>> ListAsync<TResult>(ISpecification<Warehouse, TResult> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<Warehouse?> SingleOrDefaultAsync(ISingleResultSpecification<Warehouse> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<TResult?> SingleOrDefaultAsync<TResult>(ISingleResultSpecification<Warehouse, TResult> specification, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task Update(int id, Warehouse toUpdate)
        {
            context.Warehouses[context.Warehouses.FindIndex(x => x.Id == id)] = toUpdate;
            return context.SaveAsync();
        }

        public Task UpdateAsync(Warehouse entity, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task UpdateRangeAsync(IEnumerable<Warehouse> entities, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }
    }
}
#endif