﻿using Ardalis.Specification;
using Core.Dto;
using Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Specifications
{
    internal class GetLivresDisponibles : GetAllLivresBase
    {
        internal GetLivresDisponibles()
        {
            GetQueryWithDto()
                .Where(x => x.AcceptationStatus == AcceptationStatus.Approved && x.EmpruntStatus == EmpruntStatus.Disponible);
        }
    }
}
