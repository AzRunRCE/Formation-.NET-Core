﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Infrastructure.Csv
{
    public class CsvSet<T> : List<T> where T : class 
    {
        public CsvSet(IEnumerable<T> collection) : base(collection) { }
        public CsvSet() : base() { }
        public CsvSet(int capacity) : base(capacity) { }

        public CsvSet<T> AsSplitQuery()
        {
            return this;
        }
    }
}
