﻿using Ardalis.GuardClauses;
using Ardalis.Specification;
using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Interfaces.Core;
using Exo7_EF.Core.Interfaces.Infrastructure;
using Exo7_EF.Core.Specifications;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Core.Services
{
    public class ArticleService : IArticleService
    {
        private readonly IRepositoryBase<Article> articleRepository;
        private readonly IRepositoryBase<Order> orderRepository;

        public ArticleService(IRepositoryBase<Article> articleRepository, IRepositoryBase<Order> orderRepository)
        {
            this.articleRepository = articleRepository;
            this.orderRepository = orderRepository;
        }

        public async Task<Article> Add(Article article)
        {
            ValidateArticle(article);
            await articleRepository.AddAsync(article);
            return article;
        }

        public async Task<List<Article>> GetAll()
        {
            return await articleRepository.ListAsync();
        }

        public async Task<List<Article>> GetArticlesBelowStock(int stock)
        {
            return await articleRepository.ListAsync(new GetArticlesBelowStock(stock));
        }

        public async Task<Dictionary<Article, int>> GetTotalSalesPerArticle()
        {
            var allOrderDetails = (await orderRepository.ListAsync(new GetAllOrderDetails()));
            var salesPerArticle = (await articleRepository.ListAsync()).ToDictionary(
                x => x,
                x => allOrderDetails
                    .Where(od => od.ArticleId == x.Id)
                    .Sum(od => od.Quantity));
            return salesPerArticle;
        }

        public async Task<Article> UpdateArticleStock(int itemId, int quantity)
        {
            var article = Guard.Against.Null(await articleRepository.GetByIdAsync(itemId));
            article.StockQuantity = quantity;
            await articleRepository.UpdateAsync(article);
            return article;
        }

        private async void ValidateArticle(Article article)
        {
            Guard.Against.NegativeOrZero(article.Price);
        }
    }
}
