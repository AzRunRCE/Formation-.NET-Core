﻿using System;

namespace BatailleCorse
{
    class Program
    {
        static void Main(string[] args)
        {
            StartManyGames(1);
            //StartManyGames(500);
            //StartManyGames(5000);
        }

        static void StartManyGames(int count)
        {
            for (int i = 0; i < count; i++)
            {
                Logger.Log($"====== Partie {i} =====");
                Partie premierePartie = new Partie();
                premierePartie.AjouterJoueur(new Joueur("Julie"));
                premierePartie.AjouterJoueur(new Joueur("Maxime"));
                premierePartie.AjouterJoueur(new Joueur("Mélanie"));

                premierePartie.DistribuerLesCartesAuxJoueurs();
                premierePartie.Jouer();
            }
        }
    }
}
