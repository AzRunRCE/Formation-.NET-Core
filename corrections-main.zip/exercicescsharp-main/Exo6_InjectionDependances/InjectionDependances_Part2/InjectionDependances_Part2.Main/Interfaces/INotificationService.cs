﻿namespace GarageManagementWithDotNetCore
{
    public interface INotificationService
    {
        public void Notify(string notification);
    }
}
