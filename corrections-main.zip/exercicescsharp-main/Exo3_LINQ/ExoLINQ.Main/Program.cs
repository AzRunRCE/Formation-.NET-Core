﻿using System.Collections.Generic;

namespace ExoLINQ.Main
{
    internal class Program
    {
        static void Main(string[] args)
        {
            new Exercice1().Run();
            new Exercice2().Run();
            new Exercice3().Run();
            new Exercice4().Run();
            new Exercice5().Run();
            new Exercice6().Run();
            new Exercice7().Run();
            new Exercice8().Run();
        }
    }
}
