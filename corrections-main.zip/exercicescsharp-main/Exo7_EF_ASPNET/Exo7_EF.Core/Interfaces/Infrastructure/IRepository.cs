﻿using Exo7_EF.Core.Entities;

namespace Exo7_EF.Core.Interfaces.Infrastructure
{
    public interface IRepository<T>
    {
        Task<List<T>> GetAll();
        Task<List<T>> GetAll(Func<IQueryable<T>, IQueryable<T>> filter);

        Task<T> GetById(int id);
        Task Add(T toAdd);
        Task Update(int id, T toUpdate);
        Task Delete(int id);
    }
}