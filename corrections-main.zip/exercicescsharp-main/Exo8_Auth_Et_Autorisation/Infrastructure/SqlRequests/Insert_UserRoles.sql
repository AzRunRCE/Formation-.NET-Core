﻿INSERT INTO [dbo].[AspNetUserRoles] ([UserId], [RoleId]) VALUES (N'09917878-d799-44db-86fe-1136e15f7c63', N'3');
INSERT INTO [dbo].[AspNetUserRoles] ([UserId], [RoleId]) VALUES (N'14f006af-0a51-4aa7-bb3f-3c8fa1fc6e8d', N'2');
INSERT INTO [dbo].[AspNetUserRoles] ([UserId], [RoleId]) VALUES (N'81fe7625-a952-452b-9043-9b201a5e8b44', N'1');
INSERT INTO [dbo].[AspNetUserRoles] ([UserId], [RoleId]) VALUES (N'948cfa5e-df31-41ed-a14d-69785c3934bd', N'3');
