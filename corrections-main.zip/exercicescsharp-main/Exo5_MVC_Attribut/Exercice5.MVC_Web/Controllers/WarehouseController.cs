﻿using Exercice5.Core.Entities;
using Microsoft.AspNetCore.Mvc;
using Exercice5.MVC_Web;
using Exercice5.Core.Interfaces.Core;
using AutoMapper;
using Exercice5.MVC_Web.Models;

namespace Exercice_5.MVC_Web.Controllers
{
    public class WarehouseController : Controller
    {

        private readonly IWarehouseService warehouseService;
        private readonly IMapper mapper;

        public WarehouseController(IWarehouseService warehouseService, IMapper mapper)
        {
            this.warehouseService = warehouseService;
            this.mapper = mapper;
        }

        // GET: WarehouseController
        public ActionResult Index()
        {
            return View(warehouseService.GetWarehouses().Select(x => mapper.Map<WarehouseVM>(x)));
        }

        // GET: WarehouseController/Details/5
        public ActionResult Details(int id)
        {
            // Search throught warehouses list the target warehouse by id
            var foundWarehouse = warehouseService.GetWarehouses().FirstOrDefault(w => w.Id == id);

            return View(mapper.Map<WarehouseVM>(foundWarehouse));
        }

        // GET: WarehouseController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: WarehouseController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                //int newId = WarehouseController.Warehouses.Select(w => w.Id).Aggregate((previusMax, current) => { return Math.Max(previusMax, current); }) + 1;
                Warehouse warehouse = new Warehouse();
                ApplyFormCollectionToWarehouse(collection, warehouse);
                warehouseService.Add(warehouse);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: WarehouseController/Edit/5
        public ActionResult Edit(int id)
        {
            // Search throught warehouses list the target warehouse by id
            var foundWarehouse = warehouseService.GetWarehouses().FirstOrDefault(w => w.Id == id);

            return View(mapper.Map<WarehouseVM>(foundWarehouse));
        }

        // POST: WarehouseController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            var foundWarehouse = warehouseService.GetWarehouses().FirstOrDefault(w => w.Id == id);
            try
            {
                if (foundWarehouse is null)
                {
                    throw new ArgumentOutOfRangeException("Id does not correspond to any warehouse");
                }
                ApplyFormCollectionToWarehouse(collection, foundWarehouse);

                if (collection.Keys.Contains("Code"))
                    warehouseService.Update(foundWarehouse, collection["Code"]);
                else
                    throw new Exception("No Code was found in Form Collection. Cannot edit a warehouse without a code.");

                return RedirectToAction(nameof(Index));
            }
            catch (ArgumentOutOfRangeException)
            {
                return RedirectToAction(nameof(Index));
            }
            catch (InvalidOperationException)
            {
                ViewBag.CodeMessage = "ResultKO";
                return View(mapper.Map<WarehouseVM>(foundWarehouse));
            }
            catch
            {
                ViewBag.CodeMessage = "ResultOK";
                return View(mapper.Map<WarehouseVM>(foundWarehouse));
            }
        }

        private void ApplyFormCollectionToWarehouse(IFormCollection collection, Warehouse foundWarehouse)
        {
            foreach (var field in collection)
            {
                if (field.Key == nameof(foundWarehouse.Id))
                {
                    foundWarehouse.Id = int.Parse(field.Value);
                }
                else if (field.Key == nameof(foundWarehouse.Name))
                {
                    foundWarehouse.Name = field.Value;
                }
                else if (field.Key == nameof(foundWarehouse.Address))
                {
                    foundWarehouse.Address = field.Value;
                }
                else if (field.Key == nameof(foundWarehouse.PostalCode))
                {
                    foundWarehouse.PostalCode = int.Parse(field.Value);
                }
            }
        }

        // GET: WarehouseController/Delete/5
        public ActionResult Delete(int id)
        {
            // Search throught warehouses list the target warehouse by id
            var foundWarehouse = warehouseService.GetWarehouses().FirstOrDefault(w => w.Id == id);

            return View(mapper.Map<WarehouseVM>(foundWarehouse));
        }

        // POST: WarehouseController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                // Search throught warehouses list the target warehouse by id
                var foundWarehouse = warehouseService.GetWarehouses().FirstOrDefault(w => w.Id == id);
                if (foundWarehouse != null)
                {
                    warehouseService.Remove(foundWarehouse);
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }


        // GET: WarehouseController/GenerateCode/5
        public ActionResult GenerateCode(int id)
        {
            string code = warehouseService.GenerateCode(id);
            TempData["Code"] = code;
            return RedirectToAction(nameof(Edit), new { id });
        }

    }
}
