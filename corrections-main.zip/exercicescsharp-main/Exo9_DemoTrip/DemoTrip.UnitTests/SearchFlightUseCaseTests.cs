using DemoTrip.Core.UseCases;
using DemoTrip.Core.Dtos;
using Ardalis.Specification;
using Moq;
using DemoTrip.UnitTests.Extensions;
using DemoTrip.Core.Entities;

namespace DemoTrip.UnitTests
{
    [TestClass]
    public class SearchFlightUseCaseTests
    {
        [TestMethod]
        public void When_NotFound_Any_Flight_Should_Respond_False_And_Empty()
        {
            var request = new SearchFlightRequest("NY", "CDG", DateTime.Now);

            var fakeFlightRepository = new Mock<IRepositoryBase<Flight>>()
                .SetupListWithSpecAsync([]);

            var response = new SearchFlightUseCase(fakeFlightRepository.Object).Execute(request).Result;

            Assert.IsFalse(response.Success);
            Assert.AreEqual(0, response.Flights.Count);
        }

        [TestMethod]
        public void When_Found_Any_Flight_Should_Respond_True_And_OneFlight()
        {
            var request = new SearchFlightRequest("NY", "CDG", DateTime.Today.AddHours(8));

            var flights = new List<Flight>
            {
                new(){Id = 1, Origin="LA", Destination="NY"},
                new(){Id = 2, Origin="NY", Destination="CDG", DepartureTime = DateTime.Today.AddHours(12), ArrivalTime=DateTime.Today.AddHours(20)}
            };

            var fakeFlightRepository = new Mock<IRepositoryBase<Flight>>()
                .SetupListWithSpecAsync(flights);

            var response = new SearchFlightUseCase(fakeFlightRepository.Object).Execute(request).Result;

            Assert.IsTrue(response.Success);
            Assert.AreEqual(1, response.Flights.Count);
        }
    }
}