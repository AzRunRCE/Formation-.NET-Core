﻿using DemoTrip.Core.Entities;

namespace DemoTrip.Core.Dtos
{
    public record SearchHotelRequest(string Location, DateTime DateFrom, DateTime DateTo);
    public record SearchHotelResponse(bool Success, List<Hotel> Hotels);
}