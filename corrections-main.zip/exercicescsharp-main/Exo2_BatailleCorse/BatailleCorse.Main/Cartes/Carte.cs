﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatailleCorse.Cartes
{
    public class Carte
    {
        public readonly Valeur valeur;
        public readonly Couleur couleur;
        public bool IsFigure { get => valeur >= Valeur.VALET; }

        public Carte(Valeur valeur, Couleur couleur)
        {
            this.valeur = valeur;
            this.couleur = couleur;
        }

        public int GetTentativesCountFromCard()
        {
            if (valeur < Valeur.VALET)
                return 0;
            else
                return (Valeur.Length - Valeur.DIX) - (valeur - Valeur.DIX);
        }

        public override string ToString()
        {
            return $"{valeur} de {couleur}";
        }
    }
}
