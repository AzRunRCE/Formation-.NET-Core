using DemoTrip.Core.UseCases;
using DemoTrip.Core.Dtos;
using Ardalis.Specification;
using Moq;
using DemoTrip.UnitTests.Extensions;
using DemoTrip.Core.Entities;

namespace DemoTrip.UnitTests
{
    [TestClass]
    public class SearchHotelUseCaseTests
    {
        [TestMethod]
        public void When_NotFound_Any_Hotel_Should_Respond_False_And_Empty()
        {
            var request = new SearchHotelRequest("SFO", DateTime.Now, DateTime.Now.AddDays(2));

            var fakeHotelRepository = new Mock<IRepositoryBase<Hotel>>()
                .SetupListWithSpecAsync([]);

            var response = new SearchHotelUseCase(fakeHotelRepository.Object).Execute(request).Result;

            Assert.IsFalse(response.Success);
            Assert.AreEqual(0, response.Hotels.Count);
        }

        [TestMethod]
        public void When_Found_Any_Hotel_Should_Respond_True_And_OneHotel()
        {
            var request = new SearchHotelRequest("NY", DateTime.Now, DateTime.Now.AddDays(3));

            var Hotels = new List<Hotel>
            {
                new(){Id = 1, Location="LA", CheckInDate= DateTime.Today, CheckOutDate=DateTime.Today.AddDays(5)},
                new(){Id = 2, Location="NY", CheckInDate= DateTime.Today, CheckOutDate=DateTime.Today.AddDays(2)},
                new(){Id = 3, Location="NY", CheckInDate= DateTime.Today, CheckOutDate=DateTime.Today.AddDays(5)}
            };

            var fakeHotelRepository = new Mock<IRepositoryBase<Hotel>>()
                .SetupListWithSpecAsync(Hotels);

            var response = new SearchHotelUseCase(fakeHotelRepository.Object).Execute(request).Result;

            Assert.IsTrue(response.Success);
            Assert.AreEqual(1, response.Hotels.Count);
            Assert.AreEqual(3, response.Hotels[0].Id);
        }
    }
}