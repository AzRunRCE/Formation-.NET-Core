﻿using Exo6_EF.Core.Entities;
using Exo6_EF.Core.Interfaces.Infrastructure;
using Exo6_EF.Core.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo6_EF.Tests.Services
{
    [TestClass]
    public class ArticleServiceTests
    {
        [TestMethod]
        public void CanCreateService()
        {
            var service = new ArticleService(new Mock<IArticleRepository>().Object, new Mock<IOrderRepository>().Object);

            Assert.IsNotNull(service);
        }

        [TestMethod]
        public void Add_Adds_One_Item_In_Repository()
        {
            List<Article> articleRepo = new();
            var articleToAdd = new Article() { Price = 1 };

            var mockRepo = new Mock<IArticleRepository>();
            mockRepo.Setup(x => x.Add(articleToAdd)).Callback((Article newArticle) => { articleRepo.Add(newArticle); });
            var service = new ArticleService(mockRepo.Object, new Mock<IOrderRepository>().Object);

            service.Add(articleToAdd);

            Assert.AreEqual(1, articleRepo.Count);
        }

        [TestMethod]
        public void Add_Returns_Same_Item()
        {
            var service = new ArticleService(GetConfiguredMockRepository().Object, new Mock<IOrderRepository>().Object);

            var articleToAdd = new Article() { Price = 1 };
            var addedArticle = service.Add(articleToAdd);

            Assert.AreEqual(articleToAdd, addedArticle);
        }

        [TestMethod]
        public void Add_Adds_Item_With_Same_Id()
        {
            List<Article> articleRepo = new();
            var articleToAdd = new Article() { Id = 8, Price = 1 };

            var mockRepo = new Mock<IArticleRepository>();
            mockRepo.Setup(x => x.Add(articleToAdd)).Callback((Article newArticle) => { articleRepo.Add(newArticle); });
            var service = new ArticleService(mockRepo.Object, new Mock<IOrderRepository>().Object);

            service.Add(articleToAdd);

            Assert.IsTrue(articleRepo.Any(x => x.Id == articleToAdd.Id));
        }

        [TestMethod]
        public void GetArticleBelowStock_Returns_List_Article()
        {
            var mockRepo = GetConfiguredMockRepository();
            var service = new ArticleService(mockRepo.Object, new Mock<IOrderRepository>().Object);

            var articlesBelowStock = service.GetArticlesBelowStock(5);

            Assert.IsInstanceOfType<IEnumerable<Article>>(articlesBelowStock);
        }

        [TestMethod]
        public void GetArticleBelowStock_Returns_Only_Items_With_Stock_Inferior_To_Parameter()
        {
            var mockRepo = GetConfiguredMockRepository();
            var service = new ArticleService(mockRepo.Object, new Mock<IOrderRepository>().Object);
            int stockToEvaluate = 5;

            var articlesBelowStock = service.GetArticlesBelowStock(stockToEvaluate);

            Assert.AreEqual(2, articlesBelowStock.Count());
            Assert.IsFalse(articlesBelowStock.Any(x => x.StockQuantity >= stockToEvaluate));
        }

        [TestMethod]
        public void UpdateArticle_Returns_Article()
        {
            var mockRepo = GetConfiguredMockRepository();
            var service = new ArticleService(mockRepo.Object, new Mock<IOrderRepository>().Object);

            var article = service.UpdateArticleStock(1, 40);

            Assert.IsInstanceOfType<Article>(article);
        }

        [TestMethod]
        public void UpdateArticle_Returns_Article_With_Same_Id()
        {
            var mockRepo = GetConfiguredMockRepository();
            var service = new ArticleService(mockRepo.Object, new Mock<IOrderRepository>().Object);

            var article = service.UpdateArticleStock(1, 40);

            Assert.AreEqual(1, article.Id);
        }

        [TestMethod]
        public void UpdateArticle_Returns_Article_With_Good_Quantity()
        {
            var mockRepo = GetConfiguredMockRepository();
            var service = new ArticleService(mockRepo.Object, new Mock<IOrderRepository>().Object);

            var article = service.UpdateArticleStock(1, 40);

            Assert.AreEqual(40, article.StockQuantity);
            Assert.AreEqual(40, mockRepo.Object.GetAll().First(x => x.Id == 1).StockQuantity);
        }

        [TestMethod]
        public void GetTotalSalesPerArticles_Returns_Dictionnary()
        {
            var mockRepo = GetConfiguredMockRepository();
            var mockOrderRepo = new Mock<IOrderRepository>();
            mockOrderRepo.Setup(x => x.GetAll()).Returns(new List<Order>().AsQueryable());
            var service = new ArticleService(mockRepo.Object, mockOrderRepo.Object);

            var dictionnary = service.GetTotalSalesPerArticle();

            Assert.IsInstanceOfType<Dictionary<Article, int>>(dictionnary);
        }

        [TestMethod]
        public void GetTotalSalesPerArticles_Returns_Articles_In_OrderList()
        {
            var mockRepo = new Mock<IArticleRepository>();
            List<Article> articleRepo = new()
            {
                new Article(){ Id = 1, Price=1},
                new Article(){ Id = 2, Price=2},
            };
            mockRepo.Setup(x => x.GetAll()).Returns(articleRepo.AsQueryable());

            var mockOrderRepo = new Mock<IOrderRepository>();
            mockOrderRepo.Setup(x => x.GetAll()).Returns(
                new List<Order>()
                {

                new() { OrderDetails =
                [
                    new() {ArticleId = 1, Quantity = 1},
                    new() {ArticleId = 2, Quantity = 5}
                ] },
                new() { OrderDetails =
                [
                    new() {ArticleId = 1, Quantity = 2}
                ] },
                new(){ OrderDetails =
                [
                    new() { ArticleId = 2, Quantity = 3}
                ] }
                }.AsQueryable()
            );

            var service = new ArticleService(mockRepo.Object, mockOrderRepo.Object);

            var dictionnary = service.GetTotalSalesPerArticle();

            Assert.AreEqual(2, dictionnary.Count);
            Assert.AreEqual(3, dictionnary[mockRepo.Object.GetAll().First(x => x.Id == 1)]);
            Assert.AreEqual(8, dictionnary[mockRepo.Object.GetAll().First(x => x.Id == 2)]);
        }

        private Mock<IArticleRepository> GetConfiguredMockRepository()
        {
            var mockRepo = new Mock<IArticleRepository>();
            List<Article> articleRepo = new()
            {
                new Article(){ Id = 1, StockQuantity = 1, Price=1},
                new Article(){ Id = 2, StockQuantity = 4, Price=3},
                new Article(){ Id = 3, StockQuantity = 10, Price=5},
                new Article(){ Id = 4, StockQuantity = 30, Price=7},
            };
            mockRepo.Setup(x => x.GetAll()).Returns(articleRepo.AsQueryable());
            return mockRepo;
        }
    }
}
