﻿using Ardalis.Specification;
using Exo7_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Core.Specifications
{
    internal class GetOrderArticlesCount : Specification<Order, int>
    {
        public GetOrderArticlesCount()
        {
            Query.Select(x => x.OrderDetails.Count);
        }
    }
}
