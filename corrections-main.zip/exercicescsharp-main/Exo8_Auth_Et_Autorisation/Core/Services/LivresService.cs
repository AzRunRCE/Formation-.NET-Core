﻿using Ardalis.GuardClauses;
using Ardalis.Specification;
using Core.Dto;
using Core.Entities;
using Core.Exceptions;
using Core.Facades;
using Core.Interfaces.Facades;
using Core.Interfaces.Services;
using Core.Specifications;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Services
{
    public class LivresService : ILivreService
    {
        private readonly IRepositoryBase<Livre> livreRepository;
        private readonly IUserPermissionFacade userPermission;

        public LivresService(IRepositoryBase<Livre> livreRepository, IUserPermissionFacade userPermission)
        {
            this.livreRepository = livreRepository;
            this.userPermission = userPermission;
        }

        public async Task<CreatedLivreResponse> Create(CreateLivreRequete requete)
        {
            Guard.Against.Null(requete.Content);
            await userPermission.IsValidUser(requete.User);

            Livre livreToAdd = new()
            {
                Content = requete.Content,
                CreatedDate = DateTime.Now,
                AcceptationStatus = AcceptationStatus.Submitted,
                User = requete.User
            };

            livreToAdd = await livreRepository.AddAsync(livreToAdd);

            return new CreatedLivreResponse(livreToAdd.LivreId);
        }

        public async Task Delete(DeleteLivreRequete requete)
        {
            var livreToDelete = await GetValidLivreInRepository(requete.LivreId);

            await CheckIfUserCanEditThisBook(livreToDelete, requete.User);

            await livreRepository.DeleteAsync(livreToDelete);
        }

        public async Task<List<GetLivreResponse>> GetAllLivres()
        {
            return await livreRepository.ListAsync(new GetAllLivresBase());
        }

        public async Task<List<GetLivreResponse>> GetSubmittedLivres()
        {
            return await livreRepository.ListAsync(new GetSubmittedLivres());
        }

        public async Task<GetLivreResponse> GetOne(int livreId)
        {
            var foundLivre = Guard.Against.Null(await livreRepository.GetByIdAsync(livreId));
            return new GetLivreResponse(foundLivre.LivreId, foundLivre.Content, foundLivre.CreatedDate, foundLivre.AcceptationStatus, foundLivre.EmpruntStatus, foundLivre.User?.UserName);
        }

        public async Task<GetLivreResponse> GetOneWithItsUser(int livreId)
        {
            return Guard.Against.Null(await livreRepository.FirstOrDefaultAsync(new GetFullLivreById(livreId)));
        }

        public async Task<List<GetLivreResponse>> GetDisponibles()
        {
            return await livreRepository.ListAsync(new GetLivresDisponibles());
        }

        public async Task<List<GetLivreResponse>> GetApproved()
        {
            return await livreRepository.ListAsync(new GetLivresApproved());
        }

        public async Task<List<GetLivreResponse>> GetFromUser(string userId)
        {
            return await livreRepository.ListAsync(new GetUserLivres(userId));
        }

        public async Task<UpdatedLivreResponse> UpdateContent(UpdateContentLivreRequete requete)
        {
            var livreBdd = await GetValidLivreInRepository(requete.LivreId);

            await CheckIfUserCanEditThisBook(livreBdd, requete.User);

            livreBdd.Content = requete.NewContent;

            await livreRepository.UpdateAsync(livreBdd);
            return new UpdatedLivreResponse(livreBdd.LivreId, livreBdd.Content, livreBdd.AcceptationStatus, livreBdd.EmpruntStatus);
        }

        public async Task<UpdatedLivreResponse> UpdateAcceptationStatus(UpdateAcceptationLivreRequete requete)
        {
            var livreBdd = await GetValidLivreInRepository(requete.LivreId);

            await CheckIfUserCanApproveThisBook(livreBdd, requete.User);

            livreBdd.AcceptationStatus = requete.AcceptationStatus;

            await livreRepository.UpdateAsync(livreBdd);
            return new UpdatedLivreResponse(livreBdd.LivreId, livreBdd.Content, livreBdd.AcceptationStatus, livreBdd.EmpruntStatus);
        }

        public async Task<UpdatedLivreResponse> UpdateEmpruntStatus(UpdateEmpruntStatusRequete requete)
        {
            var livreBdd = await GetValidLivreInRepository(requete.LivreId);

            await CheckIfUserCanApproveThisBook(livreBdd, requete.User);

            livreBdd.EmpruntStatus = requete.EmpruntStatus;

            await livreRepository.UpdateAsync(livreBdd);
            return new UpdatedLivreResponse(livreBdd.LivreId, livreBdd.Content, livreBdd.AcceptationStatus, livreBdd.EmpruntStatus);
        }

        private Livre ValidateLivre(Livre? livre)
        {
            Guard.Against.Null(livre);
            Guard.Against.NullOrEmpty(livre.Content);
            Guard.Against.InvalidInput(livre, "User or UserId", x => !(x.UserId == null && x.User == null));
            return livre;
        }

        private async Task<Livre> GetValidLivreInRepository(int livreId)
        {
            return ValidateLivre(await livreRepository.GetByIdAsync(livreId));
        }

        private async Task CheckIfUserCanApproveThisBook(Livre livre, IdentityUser user)
        {
            await userPermission.IsValidUser(user);

            if (livre.UserId != user.Id)
            {
                if (!await userPermission.IsAdminOrBibliothecaire(user.Id))
                    throw new OperationRefusedException();
            }
        }

        private async Task CheckIfUserCanEditThisBook(Livre livre, IdentityUser user)
        {
            await userPermission.IsValidUser(user);

            if (livre.UserId != user.Id)
            {
                if (!await userPermission.IsAdmin(user.Id))
                    throw new OperationRefusedException();
            }
        }
    }
}
