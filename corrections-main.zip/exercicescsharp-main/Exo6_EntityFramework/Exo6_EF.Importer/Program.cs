﻿using Ex06_EF.Infrastructure;
using Exo6_EF.Core.Interfaces.Core;
using Exo6_EF.Core.Interfaces.Infrastructure;
using Exo6_EF.Core.Entities;
using Exo6_EF.Core.Services;
using Exo6_EF.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace Exo6.Importer
{
    internal class Program
    {
        private const bool DeleteOldData = true;
        static void Main(string[] args)
        {
            var serviceProvider = new ServiceCollection()

                .AddScoped<IArticleService, ArticleService>()
                .AddScoped<IOrderService, OrderService>()
                .AddScoped<IWarehouseService, WarehouseService>()
                .AddScoped<ICustomerService, CustomerService>()

                .AddScoped<IOrderRepository, SqlOrderRepository>()
                .AddScoped<IArticleRepository, SqlArticleRepository>()
                .AddScoped<ICustomerRepository, SqlCustomerRepository>()
                .AddScoped<IWarehouseRepository, SqlWarehouseRepository>()

                .AddDbContext<ApplicationDbContext>()
                .BuildServiceProvider();

            MyCsvParser parser = new();

            var fileToImport = File.ReadAllLines(args.Length == 0 ? "export.csv" : args[0]);
            parser.ParseAllFromFile(fileToImport);

            IOrderService orderService = serviceProvider.GetRequiredService<IOrderService>();
            ICustomerService customerService = serviceProvider.GetRequiredService<ICustomerService>();
            IWarehouseService warehouseService = serviceProvider.GetRequiredService<IWarehouseService>();
            IArticleService articleService = serviceProvider.GetRequiredService<IArticleService>();


            if (DeleteOldData)
            {
                var deleteTask = DeleteAllOldDataAsync(serviceProvider);
                deleteTask.Wait();
            }

            LinkOrderDetailsToOrder(parser.Orders, parser.OrderDetails);
            LinkOrderToCustomer(parser.Customers, parser.Orders);
            LinkArticlesToOderDetails(parser.OrderDetails, parser.Articles);
            LinkWarehouseToOrders(parser.Orders, parser.Warehouses);

            parser.Warehouses.ForEach(x => warehouseService.Add(x));
            parser.Customers.ForEach(x => customerService.Add(x));
            parser.Articles.ForEach(x => articleService.Add(x));
            parser.Orders.ForEach(x => orderService.Add(x));
        }

        private async static Task DeleteAllOldDataAsync(ServiceProvider serviceProvider)
        {

            var wahouseRepo = serviceProvider.GetRequiredService<IWarehouseRepository>();
            await wahouseRepo.GetAll().ForEachAsync(x => wahouseRepo.Delete(x.Id));

            var customerRepo = serviceProvider.GetRequiredService<ICustomerRepository>();
            await customerRepo.GetAll().ForEachAsync(x => customerRepo.Delete(x.Id));

            var orderRepo = serviceProvider.GetRequiredService<IOrderRepository>();
            await orderRepo.GetAll().ForEachAsync(x => orderRepo.Delete(x.Id));

            var articleRepo = serviceProvider.GetRequiredService<IArticleRepository>();
            await articleRepo.GetAll().ForEachAsync(x => articleRepo.Delete(x.Id));

            serviceProvider.GetRequiredService<ApplicationDbContext>().SaveChanges();
        }

        private static void LinkOrderToCustomer(List<Customer> customers, List<Order> orders)
        {
            orders.ForEach(order =>
            {
                order.Customer = customers.First(x => x.Id == order.CustomerId);
                order.CustomerId = 0;
            });
        }

        private static void LinkWarehouseToOrders(List<Order> orders, List<Warehouse> warehouses)
        {
            orders.ForEach(order =>
            {
                order.Warehouse = warehouses.First(x => x.Id == order.WarehouseId);
                order.WarehouseId = 0;
            });
        }

        private static void LinkArticlesToOderDetails(List<OrderDetail> orderDetails, List<Article> articles)
        {
            orderDetails.ForEach(orderDetails =>
            {
                orderDetails.Article = articles.First(article => article.Id == orderDetails.ArticleId);
                orderDetails.ArticleId = 0;
            });
        }

        private static void LinkOrderDetailsToOrder(List<Order> orders, List<OrderDetail> orderDetails)
        {
            orders.ForEach(order =>
            {
                order.OrderDetails = orderDetails.Where(detail => detail.OrderId == order.Id).ToList();
            });
        }
    }
}
