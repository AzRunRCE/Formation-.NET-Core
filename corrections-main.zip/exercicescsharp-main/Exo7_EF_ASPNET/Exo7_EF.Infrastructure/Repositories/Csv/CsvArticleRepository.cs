﻿using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Interfaces.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
#if false
namespace Exo7_EF.Infrastructure.Repositories.Csv
{
    public class CsvArticleRepository : IArticleRepository
    {
        private readonly CsvApplicationDbContext context;

        public CsvArticleRepository(CsvApplicationDbContext context) => this.context = context;


        public Task Add(Article newArticle)
        {
            if (context.Articles.Any(a => a.Id == newArticle.Id))
                throw new Exception($"This Id already exist. Use a different ID than {newArticle.Id}");

            context.Articles.Add(newArticle);

            return context.SaveAsync();
        }

        public Task Delete(int id)
        {
            context.Articles.Remove(context.Articles.First(a => a.Id == id));
            return context.SaveAsync();
        }

        public Task<List<Article>> GetAll()
        {
            return Task.FromResult(context.Articles.ToList());
        }

        public Task<List<Article>> GetAll(Func<IQueryable<Article>, IQueryable<Article>> filter)
        {
            return Task.FromResult(filter(context.Articles.AsQueryable()).ToList());
        }

        public Task<Article> GetById(int id)
        {
            var found = context.Articles.First(a => a.Id == id);
            return Task.FromResult(found);
        }

        public Task Update(int id, Article toUpdate)
        {
            context.Articles[context.Articles.FindIndex(x => x.Id == id)] = toUpdate;
            return context.SaveAsync();
        }
    }
}
#endif