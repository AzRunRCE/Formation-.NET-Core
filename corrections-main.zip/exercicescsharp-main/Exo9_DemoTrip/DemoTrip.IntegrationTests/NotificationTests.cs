﻿using DemoTrip.Core.Dtos;
using DemoTrip.Core.Interfaces;
using DemoTrip.Core.UseCases;
using DemoTrip.Infrastructure.Notifications;
using DemoTrip.Infrastructure.Utilities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoTrip.IntegrationTests
{
    [TestClass]
    public class NotificationTests
    {
        [TestMethod]
        public void CanUse_SmsNotification()
        {
            var notification = new FakeSmsReservationNotification();

            var mockFlight = new Mock<ISearchFlightUseCase>();
            mockFlight.Setup(x => x.Execute(It.IsAny<SearchFlightRequest>()))
                .ReturnsAsync(new SearchFlightResponse(true, [new() { Price = 1 }]));
            var mockHotel = new Mock<ISearchHotelUseCase>();
            mockHotel.Setup(x => x.Execute(It.IsAny<SearchHotelRequest>()))
                .ReturnsAsync(new SearchHotelResponse(true, [new() { PricePerNight = 1 }]));

            using (var consoleOutput = new ConsoleOutput())
            {

                var bookTripResponse = new BookTripUseCase(mockFlight.Object, mockHotel.Object, notification)
                    .Execute(new BookTripRequest("", "", DateTime.Now, DateTime.Now));

                Assert.IsTrue(consoleOutput.GetOuput().Contains("SMS"));
            }
        }

        [TestMethod]
        public void CanUse_EmailNotification()
        {
            var notification = new FakeEmailReservationNotification();

            var mockFlight = new Mock<ISearchFlightUseCase>();
            mockFlight.Setup(x => x.Execute(It.IsAny<SearchFlightRequest>()))
                .ReturnsAsync(new SearchFlightResponse(true, [new() { Price = 1 }]));
            var mockHotel = new Mock<ISearchHotelUseCase>();
            mockHotel.Setup(x => x.Execute(It.IsAny<SearchHotelRequest>()))
                .ReturnsAsync(new SearchHotelResponse(true, [new() { PricePerNight = 1 }]));

            using (var consoleOutput = new ConsoleOutput())
            {

                var bookTripResponse = new BookTripUseCase(mockFlight.Object, mockHotel.Object, notification)
                    .Execute(new BookTripRequest("", "", DateTime.Now, DateTime.Now));

                Assert.IsTrue(consoleOutput.GetOuput().Contains("EMAIL"));
            }
        }
    }
}
