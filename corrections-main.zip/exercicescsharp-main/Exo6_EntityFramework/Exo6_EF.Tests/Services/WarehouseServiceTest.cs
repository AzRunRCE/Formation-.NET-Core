using Exo6_EF.Core.Entities;
using Exo6_EF.Core.Interfaces.Infrastructure;
using Exo6_EF.Core.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Exo6_EF.Tests.Services
{
    [TestClass]
    public class WarehouseServiceTest
    {
        [TestMethod]
        public void CanCreateService()
        {
            var service = new WarehouseService(new Mock<IWarehouseRepository>().Object);

            Assert.IsNotNull(service);
        }

        [TestMethod]
        public void GetWarehouse_Returns_ListWarehouse()
        {
            var service = SetupServiceWithMockRepo();

            var retour = service.GetAllWarehouses();

            Assert.IsInstanceOfType<IQueryable<Warehouse>>(retour);
        }

        [TestMethod]
        public void GetWarehouse_Returns_WarehousesInMock()
        {
            var service = SetupServiceWithMockRepo();

            var warehouses = service.GetAllWarehouses();

            Assert.AreEqual(1, warehouses.Count());
            Assert.AreEqual("Entrepot de Paris", warehouses.ToList()[0].Name);
        }

        [TestMethod]
        public void Add_Adds_One_Warehouse()
        {
            var warehouseList = new List<Warehouse>();
            var repoMock = new Mock<IWarehouseRepository>();
            repoMock.Setup(x => x.Add(It.IsAny<Warehouse>())).Callback<Warehouse>(warehouseList.Add);
            var service = new WarehouseService(repoMock.Object);

            service.Add(new Warehouse());

            Assert.AreEqual(1, warehouseList.Count);
        }

        [TestMethod]
        public void Add_Adds_Warehouse_WithSame_Id()
        {
            var warehouseList = new List<Warehouse>();
            var repoMock = new Mock<IWarehouseRepository>();
            repoMock.Setup(x => x.Add(It.IsAny<Warehouse>())).Callback<Warehouse>(warehouseList.Add);
            var service = new WarehouseService(repoMock.Object);

            service.Add(new Warehouse() { Id = 1 });

            Assert.AreEqual(1, warehouseList[0].Id);
        }

        [TestMethod]
        public void Add_Returns_Warehouse()
        {
            var warehouseList = new List<Warehouse>();
            var warehouseToAdd = new Warehouse();
            var repoMock = new Mock<IWarehouseRepository>();
            repoMock.Setup(x => x.Add(It.IsAny<Warehouse>())).Callback<Warehouse>(warehouseList.Add);
            var service = new WarehouseService(repoMock.Object);

            var warehouse = service.Add(warehouseToAdd);

            Assert.AreEqual(warehouseToAdd, warehouseList[0]);
        }




        private WarehouseService SetupServiceWithMockRepo()
        {
            var repoMock = new Mock<IWarehouseRepository>();
            repoMock.Setup(x => x.GetAll()).Returns(new List<Warehouse>()
            {
                new Warehouse
                {
                    Id = 1,
                    Name = "Entrepot de Paris",
                    Address = new Address("10 rue du csharp",75000, "Paris")
                }
            }.AsQueryable());
            return new WarehouseService(repoMock.Object);
        }
    }
}