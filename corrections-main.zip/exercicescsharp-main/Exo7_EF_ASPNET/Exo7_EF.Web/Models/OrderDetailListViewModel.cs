﻿namespace Exo7_EF.Web.Models
{
    public class OrderDetailListViewModel : List<OrderDetailViewModel>
    {
        public OrderDetailListViewModel(IEnumerable<OrderDetailViewModel> collection) : base(collection) { }
        public OrderDetailListViewModel() : base() { }
    }
}
