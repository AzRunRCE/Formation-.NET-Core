﻿using Exo7_EF.Core.Entities;
using Exo7_EF.Web.Models.Validation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Exo7_EF.Web.Models
{
    public class OrderViewModel
    {
        [HiddenInput(DisplayValue = false)]
        public int Id { get; set; }

        [DisplayName("Customer")]
        [Required(AllowEmptyStrings = false)]
        [StringLength(100)]
        public string CustomerName { get; set; }

        [Required(AllowEmptyStrings = false)]
        [EmailAddress]
        public string Email { get; set; }

        [DisplayName("Road name")]
        [Required(AllowEmptyStrings = false)]
        [StringLength(200)]
        public string Shipping_RoadName { get; set; }

        [DisplayName("Postal Code")]
        [Required(AllowEmptyStrings = false)]
        [StringLength(10)]
        public string Shipping_PostalCode { get; set; }

        [DisplayName("City")]
        [Required(AllowEmptyStrings = false)]
        [StringLength(75)]
        public string Shipping_City { get; set; }

        [DisplayName("Order Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Required]
        public DateTime? OrderDate { get; set; }

        [DisplayName("Total Amount")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public double TotalAmount { get; set; }

        [Required]
        public OrderStatus? Status { get; set; }

        [DisplayName("Order Content")]
        [ValidateOrderDetail]
        public OrderDetailListViewModel OrderDetails { get; set; }

        [DisplayName("Warehouse Name")]
        public string WarehouseName { get; set; }

        public int WarehouseId { get; set; }
        public int CustomerId { get; set; }


        public SelectList AvailableArticlesInStock { get; internal set; }
        public SelectList AvailableCustomers { get; internal set; }
        public bool CanEditQuantity => Status < OrderStatus.Processing;

        [DisplayName("Address")]
        public string DisplayNameForAddress { get; set; } = "Address";

    }
}
