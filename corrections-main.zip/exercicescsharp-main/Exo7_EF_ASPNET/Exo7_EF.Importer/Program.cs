﻿using Exo7_EF.Core.Interfaces.Core;
using Exo7_EF.Core.Interfaces.Infrastructure;
using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using Exo7_EF.Infrastructure.Csv.Parser;
using Ardalis.Specification;
using Exo7_EF.Infrastructure;

namespace Exo6.Importer
{
    internal class Program
    {
        private const bool DeleteOldData = true;
        static void Main(string[] args)
        {
            var serviceProvider = new ServiceCollection().GetServiceCollection().BuildServiceProvider();

            CsvFileParser parser = new();

            var fileToImport = File.ReadAllLines(args.Length == 0 ? "export.csv" : args[0]);
            parser.ParseAllFromFile(fileToImport);

            IOrderService orderService = serviceProvider.GetRequiredService<IOrderService>();
            ICustomerService customerService = serviceProvider.GetRequiredService<ICustomerService>();
            IWarehouseService warehouseService = serviceProvider.GetRequiredService<IWarehouseService>();
            IArticleService articleService = serviceProvider.GetRequiredService<IArticleService>();


            if (DeleteOldData)
            {
                DeleteAllOldData(serviceProvider);
            }

            LinkOrderDetailsToOrder(parser.Orders, parser.OrderDetails);
            LinkOrderToCustomer(parser.Customers, parser.Orders);
            LinkArticlesToOderDetails(parser.OrderDetails, parser.Articles);
            LinkWarehouseToOrders(parser.Orders, parser.Warehouses);

            parser.Warehouses.ForEach(x => warehouseService.Add(x));
            parser.Customers.ForEach(x => customerService.Add(x));
            parser.Articles.ForEach(x => articleService.Add(x));
            parser.Orders.ForEach(x => orderService.Add(x));
        }

        private static void DeleteAllOldData(ServiceProvider serviceProvider)
        {

            var wahouseRepo = serviceProvider.GetRequiredService<IRepositoryBase<Warehouse>>();
            wahouseRepo.ListAsync().Result.ForEach(x => wahouseRepo.DeleteAsync(x));

            var customerRepo = serviceProvider.GetRequiredService<IRepositoryBase<Customer>>();
            customerRepo.ListAsync().Result.ForEach(x => customerRepo.DeleteAsync(x));

            var orderRepo = serviceProvider.GetRequiredService<IRepositoryBase<Order>>();
            orderRepo.ListAsync().Result.ForEach(x => orderRepo.DeleteAsync(x));

            var articleRepo = serviceProvider.GetRequiredService<IRepositoryBase<Article>>();
            articleRepo.ListAsync().Result.ForEach(x => articleRepo.DeleteAsync(x));

            serviceProvider.GetRequiredService<ApplicationDbContext>().SaveChanges();
        }

        private static void LinkOrderToCustomer(List<Customer> customers, List<Order> orders)
        {
            orders.ForEach(order =>
            {
                order.Customer = customers.First(x => x.Id == order.CustomerId);
                order.CustomerId = 0;
            });
        }

        private static void LinkWarehouseToOrders(List<Order> orders, List<Warehouse> warehouses)
        {
            orders.ForEach(order =>
            {
                order.Warehouse = warehouses.First(x => x.Id == order.WarehouseId);
                order.WarehouseId = 0;
            });
        }

        private static void LinkArticlesToOderDetails(List<OrderDetail> orderDetails, List<Article> articles)
        {
            orderDetails.ForEach(orderDetails =>
            {
                orderDetails.Article = articles.First(article => article.Id == orderDetails.ArticleId);
                orderDetails.ArticleId = 0;
            });
        }

        private static void LinkOrderDetailsToOrder(List<Order> orders, List<OrderDetail> orderDetails)
        {
            orders.ForEach(order =>
            {
                order.OrderDetails = orderDetails.Where(detail => detail.OrderId == order.Id).ToList();
            });
        }
    }
}
