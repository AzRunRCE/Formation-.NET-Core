﻿using Ardalis.Specification;
using Exo7_EF.Core.Entities;

namespace Exo7_EF.Core.Specifications
{
    internal class GetFullWarehouseById : Specification<Warehouse>
    {
        public GetFullWarehouseById(int warehouseId)
        {
            Query.Where(x => x.Id == warehouseId).Take(1).Include(x => x.Orders);
        }
    }
}