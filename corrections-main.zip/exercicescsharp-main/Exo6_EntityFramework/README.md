# Exercice 6 Entity Framework Console

## Projet Core
### 1. Présentation
Le projet Core contient la couche Domain Service. Elle est entièrement indépendante de l'infrastructure (la base de données MySQL) et des applications consoles. 

### 2. Entités
Le projet contient les entités suivantes : 
- Address : est un ValueObject (i.e. il n'a pas d'identité propre) qui représente une addresse (d'un client, d'un warehouse ou d'une livraison d'order).
- Article : représente un article dans le stock d'un warehouse.
- Customer : représente un client de l'application, avec son adresse, ses commandes et son nom.
- Order : représente une commande passée dans un warehouse, ainsi que l'addresse à laquelle elle doit être livrée.
- OrderDetail : représente un type d'article au sein d'une commande. Cette entité décrit combien d'un même article se trouve associé à une commande.
- Warehouse : représente un entrepôt à partir duquel on peut émettre des Orders.

### 3. Interfaces
#### Infrastructure
Ce dossier contient une interface générique IRepository avec des fonctions représentant toutes les opérations CRUD (Add, GetAll, Update et Delete).

Quatre interfaces (Article, Customer, Order et Warehouse) héritent de cette interface pour chacune des entités associées.

#### Core 
Quatre interfaces (Article, Customer, Order et Warehouse) permettant de créer les service et d'inverser les dépedendances. 

Elles représentent les interfaces données en consignes de l'exercice.

### 4. Services
L'implémentation des services décrits par les interfaces données en énoncé de l'exercice.

## Projet Infrastructure

### 1. Présentation 
Ce projet contient des classes implémentants les interfaces Repository de Core, pour relier notre application à une base de données MySQL.

Le ApplicationDbContext décrit les relation entre les entités au sein de la base de données.

### 2. Mapping CSV
Ce projet contient également les mappings entités/csv dans le dossier CsvMapping, ainsi que la classe MyCsvParser qui permet de parser le fichier donné en exemple et transformer cele ne instances des entités associées.

## Projet Tests

Ce projet contient les tests unitaires prouvant le bon fonctionnement des services, du parser CSV et du fait que les addresses sont des ValueObject.

## Projet Console

Ce projet permet de lire le contenu de la BDD. Il est basé sur le programme initial fourni dans l'exercice.

## Projet Importer

Ce projet permet de lire un fichier csv passé en paramètre, ou a défaut un fichier nommé "export.csv" accolé au programme. 

Une fois les données parsées, elles sont ajoutées dans la BDD.

Ce projet peut vider la base de données avant d'effectuer son parsing. Pour cela, il faut attribuer la valeur `true` au booléen `DeleteOldData` de la classe program.