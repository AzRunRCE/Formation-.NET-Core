using DemoTrip.Core.Entities;
using DemoTrip.Infrastructure;
using DemoTrip.Infrastructure.Csv;

namespace DemoTrip.IntegrationTests
{
    [TestClass]
    public class CsvRepository_Flight_Test
    {
        [TestMethod]
        public void List_Should_Return_Flights()
        {
            var repo = new CsvRepository<Flight>("flights_with_names.csv", new FlightCsvParser());

            var flights = repo.ListAsync().Result;

            Assert.IsTrue(flights.Count > 0);
        }
    }
}