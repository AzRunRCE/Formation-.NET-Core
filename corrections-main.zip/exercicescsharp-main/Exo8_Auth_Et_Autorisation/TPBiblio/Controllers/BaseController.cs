﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Web.Helpers;

namespace TPBiblio.Controllers
{
    [Authorize]
    public class BaseController : Controller
    {
        protected void SetNotification(string text, NotificationColor color)
        {
            TempData[NotificationHelper.Text] = text;
            switch (color)
            {
                case NotificationColor.Yellow:
                    TempData[NotificationHelper.BackgroundColor] = "bg-warning";
                    TempData[NotificationHelper.TextColor] = "text-black";
                    TempData[NotificationHelper.CloseColor] = "btn-close";
                    break;
                case NotificationColor.Red:
                    TempData[NotificationHelper.BackgroundColor] = "bg-danger";
                    TempData[NotificationHelper.TextColor] = "text-white";
                    TempData[NotificationHelper.CloseColor] = "btn-close btn-close-white";
                    break;
                case NotificationColor.Green:
                    TempData[NotificationHelper.BackgroundColor] = "bg-success";
                    TempData[NotificationHelper.TextColor] = "text-white";
                    TempData[NotificationHelper.CloseColor] = "btn-close btn-close-white";
                    break;
                default:
                case NotificationColor.White:
                    TempData[NotificationHelper.BackgroundColor] = "bg-light";
                    TempData[NotificationHelper.TextColor] = "text-black";
                    TempData[NotificationHelper.CloseColor] = "btn-close";
                    break;
            }
        }

        public enum NotificationColor
        {
            Yellow,
            Red,
            Green,
            White
        }
    }
}
