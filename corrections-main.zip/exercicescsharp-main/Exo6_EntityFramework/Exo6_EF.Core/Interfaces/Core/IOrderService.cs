﻿using Exo6_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo6_EF.Core.Interfaces.Core
{
    public interface IOrderService
    {
        // Method to add new Order
        Order Add(Order order);

        // Method to delete an order
        void Delete(int orderId);

        // Method to fetch all orders made by a specific customer
        IQueryable<Order> GetAllByCustomerId(int customerId);

        // Method to get average order value
        double GetAverageOrderValue();

        // Method to get average number article by order
        double GetAverageArticlePerOrder();
    }
}
