# exo6 - Injection de dépendances

## Partie 1 

Modèle en .Net Framework avec AutoFac

## Partie 2

Modèle en .Net Core avec exercices