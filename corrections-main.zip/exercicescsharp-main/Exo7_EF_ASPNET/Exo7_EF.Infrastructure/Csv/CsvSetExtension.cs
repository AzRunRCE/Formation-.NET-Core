﻿using Microsoft.EntityFrameworkCore.Query.Internal;
using Microsoft.EntityFrameworkCore.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Infrastructure.Csv
{
    public static class CsvSetExtension
    {
        public static CsvSet<TEntity> Include<TEntity, TProperty>(this CsvSet<TEntity> source,
                            Expression<Func<TEntity, TProperty>> navigationPropertyPath) where TEntity : class
        {
            return source;

            //return new IncludableQueryable<TEntity, TProperty>(
            //    source.Provider is EntityQueryProvider
            //        ? source.Provider.CreateQuery<TEntity>(
            //            Expression.Call(
            //                instance: null,
            //                method: IncludeMethodInfo.MakeGenericMethod(typeof(TEntity), typeof(TProperty)),
            //                arguments: new[] { source.Expression, Expression.Quote(navigationPropertyPath) }))
            //        : source);
        }
        public static CsvSet<TEntity> ThenInclude<TEntity, TPreviousProperty, TProperty>(
        this CsvSet<TEntity> source,
        Expression<Func<TPreviousProperty, TProperty>> navigationPropertyPath)
        where TEntity : class
        {
            return source;
        }

        //public static IIncludableQueryable<TEntity, TProperty> ThenInclude<TEntity, TPreviousProperty, TProperty>(
        //this IIncludableQueryable<TEntity, IEnumerable<TPreviousProperty>> source,
        //Expression<Func<TPreviousProperty, TProperty>> navigationPropertyPath)
        //where TEntity : class
        //=> new IncludableQueryable<TEntity, TProperty>(
        //    source.Provider is EntityQueryProvider
        //        ? source.Provider.CreateQuery<TEntity>(
        //            Expression.Call(
        //                instance: null,
        //                method: ThenIncludeAfterEnumerableMethodInfo.MakeGenericMethod(
        //                    typeof(TEntity), typeof(TPreviousProperty), typeof(TProperty)),
        //                arguments: new[] { source.Expression, Expression.Quote(navigationPropertyPath) }))
        //        : source);
    }
}
