﻿using Exercice5.MVC_Web.Models;
using Exercice5.Core.Entities;

namespace Exercice5.MVC_Web
{
    public class Mapping
    {
    }
}
