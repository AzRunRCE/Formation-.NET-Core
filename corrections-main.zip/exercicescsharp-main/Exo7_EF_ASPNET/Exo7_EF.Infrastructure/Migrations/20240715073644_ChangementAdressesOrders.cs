﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Exo7_EF.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class ChangementAdressesOrders : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "Adresses", newName: "CustomerAdresses");

            migrationBuilder.RenameColumn(
                name: "City",
                table: "Orders",
                newName: "ShippingAddress_City");

            migrationBuilder.RenameColumn(
                name: "ShippingAddress",
                table: "Orders",
                newName: "ShippingAddress_RoadName");

            migrationBuilder.AddColumn<int>(
                name: "ShippingAddress_PostalCode",
                table: "Orders",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "CustomerAdresses", newName: "Adresses");

            migrationBuilder.DropColumn(
                name: "ShippingAddress_PostalCode",
                table: "Orders");

            migrationBuilder.RenameColumn(
                name: "ShippingAddress_City",
                table: "Orders",
                newName: "City");

            migrationBuilder.RenameColumn(
                name: "ShippingAddress_RoadName",
                table: "Orders",
                newName: "ShippingAddress");
        }
    }
}
