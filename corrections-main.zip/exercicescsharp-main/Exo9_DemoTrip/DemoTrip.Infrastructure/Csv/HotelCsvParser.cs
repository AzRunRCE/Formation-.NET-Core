﻿using DemoTrip.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DemoTrip.Infrastructure.Csv
{
    public class HotelCsvParser : ICsvParser<Hotel>
    {
        public char GetSeparator()
        {
            return ';';
        }

        public Hotel Parse(string[] values)
        {
            //Id,Name,Location,CheckInDate,CheckOutDate,PricePerNight
            return new Hotel()
            {
                Id = int.Parse(values[0]),
                Name = values[1],
                Location = values[2],
                CheckInDate = DateTime.Parse(values[3]),
                CheckOutDate = DateTime.Parse(values[4]),
                PricePerNight = decimal.Parse(values[5])
            };
        }
    }
}
