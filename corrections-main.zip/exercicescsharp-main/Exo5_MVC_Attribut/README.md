# Exercice 5 MVC Attributs

## Projet "Core"

### 1. Présentation
Le projet Core contient la couche Domain Service. Elle est entièrement indépendante de l'infrastructure (les données) et de l'IHM. De cette manière, on peut monter une API accessible en ligne de commande qui dépend de cette couche métier, ou toute autre application complémentaire, sans avoir à toucher à ce projet.

### 2. Entités
Le projet contient les entités suivantes : 
- Article : représente un article (Id, Nom, Descriptio, Prix) stocké dans un warehouse (ainsi que le stock disponible dans ce warehouse).
- Order : représente une commande passée dans un warehouse, ainsi que les coordonnées du client.
- OrderDetail : représente un type d'article au sein d'une commande. Cette entité décrit combien d'un même article se trouve associé à une commande (grâce à l'Id de l'order).
- OrderStatus : Enumeration contenant tous les états possibles d'une commande.
- Warehouse : représente un entrepôt à partir duquel on peut émettre des Orders. 

### 3. Interfaces
#### 3.1 Infrastructure 
Quatres interfaces sont disponibles pour poser les bases du dialogue avec les données de l'infrastructure, et permettre l'inversion des dépendances : 
- IArticleReferenceRepository :  expose la méthode permettant d'accèder aux données des articles.
- IOrderDetailsRepository : expose la méthode permettant d'accèder aux order détails (les articles commandés).
- IOrderRepository : expose la méthode permettant d'accèder aux Orders (commandes).
- IWarehouseRepository : expose la méthode permettant d'accèder aux Warehouses.

#### 3.2 Core
Deux interfaces sont disponibles pour poser les bases du dialogue avec les autres parties de l'application. Ces interfaces sont implémentées par les services associés afin de pouvoir injecter les dépendances. 
#### *IOrderService :*
- Implémente des fonctions pour récupérer les commandes (par Id, toutes les commandes, toutes les commandes associée à un Warehouse). 
- Implémente des fonctions pour de créer, mettre à jour ou supprimer un Order (une commade) et ses détails. 
- Implémente également des fonctions pour créer un OrderDetail, récupérer les détails associés à un Id de commande, ou récupérer la liste des Articles en stock.
- Enfin, l'interface implémente également le calcul du prochain ID de commande et du prochain ID de détail de commande.

#### *IWarehouseService :*  
- Implémente une fonction pour récupérer la liste des warehouses.
- Implémente une fonction pour générer un code pour un warehouse.
- Implemente les fonction de gestion de warehouse (Add, Update et Remove).

### 4. Services
Les deux services (**OrderService** et **WarehouseServices**) implémentent les interfaces précedemment décrites, et contiennent toute la logique associée aux opérations de gestions des données et du métier.

OrderService assure la bonne cohérence métier des données envoyés avant d'effectuer les opérations demandées.

Ces services sont les principaux point d'entrée de ce projet.

## Projet "Infrastructure"

### 1. Présentation
Ce projet contient tous les éléments qui permettent de stocker les données. Actuellement il est composé de "Faux" qui décrivent des données en dur pour permettre des tests et un développement initial facilité.

### 2. Fake Repositories et FakeApplicationDbContext
Les fake repositories implémentent chacun les interfaces à destination de l'infrastructure décrites dans le projet "Core". Ils retournent les valeurs créés par le FakeApplicationDbContext. C'est ce dernier que vous devrez modifier si vous souhaiter avoir des données différentes au lancement de l'application.

## Projet "MVC_Web"

### 1. Présentation
Ce projet contient l'IHM Web à proprement parler. Vous pourrez retrouver les ViewModels dans le dossier "Models" de ce projet. 

Les vues permettent de créer, modifier et supprimer des warehouse de la liste. Elles permettent aussi de créer, modifier ou supprimer des commandes associées à un warehouse. 

Les controllers dépendent des interfaces des services du projet Core, pour permettre d'injecter les dépendances (à voir dans le Program.cs).

### 2. Modèles
Le dossier "Models" contient tous les ViewModels qui correspondent aux entités décrites dans le projet "Core". Le ViewModel "OrderViewModel" contient les attributs nécéssaires à la complétion de l'énoncé.

Il existe un sous Dossier "Validation" qui contient les attributs personnalisés créés exprès pour ce projet (Validation de date, de montant, de détail et de statut de commande).

### 3. Vues
#### 3.1 Warehouse
Ce dossier contient toutes les vues pour gérer les warehouse (créer, éditer, voir, supprimer et lister).

#### 3.2 Order
Ce dossier contient toutes les vues pour gérer les commandes (créer, éditer, voir, supprimer et lister).

Attention, les vues associés aux détails de la commande ne sont pas dans ce dossier.

#### 3.3 Shared/EditorTemplates
Ce dossier content les deux vues qui permettent un affichage et un bon binding des OrderDetail et OrderDetailList.

Ces vues sont rendues directement en mode édition ou observation. Elles sont rendues au fur et à mesure en création (et en édition si l'on ajoute de nouveaux articles à une commande) via l'action `AddArticleToDetail` de l'OrderController.

Un peu de javascript permet de rebinder au Model les lignes générées ou supprimées lors de la création ou l'édition d'une commande (rechercher le fichier *"orderDetailsHelper.js"*).

### 4. Controllers
Le WarehouseController s'occupe des warehouse, leur affichage et les différents liens au sein du site web.

Le OrderController s'occupe quand à lui des commandes, et converse donc avec l'OrderService qui lui est injecté.


## Projet "UnitTests"

### 1. Présentation
Le projet UnitTests présente les tests unitaires associés à ce projet. On peut actuellement y retrouver 29 tests, exécutables indépendamment et à l'intérieur de Visual Studio.
Les tests sont des MSTests.
