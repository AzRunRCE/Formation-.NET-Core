﻿namespace Exo7_EF.Web.Models
{
    public class BestCustomerListViewModel : List<BestCustomerViewModel>
    {

        public int CurrentPage { get; set; }
        public int LastPage { get; set; }


        public bool CanGoToPreviousPage => CurrentPage > 0;
        public bool CanGoToNextPage => CurrentPage < LastPage - 1;

        public BestCustomerListViewModel(IEnumerable<BestCustomerViewModel> collection) : base(collection) { }
        public BestCustomerListViewModel() : base() { }
    }
}
