﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGarageApp.Options
{
    public class GPS : IOption
    {
        public double GetPrix()
        {
            return 113.5;
        }
    }
}
