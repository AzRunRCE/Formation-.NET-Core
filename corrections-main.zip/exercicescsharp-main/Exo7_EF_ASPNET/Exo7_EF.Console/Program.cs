﻿using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Interfaces.Core;
using Exo7_EF.Core.Interfaces.Infrastructure;
using Exo7_EF.Core.Services;
using Exo7_EF.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Exo7_EF.Infrastructure.Csv;
using System;

internal class Program
{
    private static ServiceProvider serviceProvider;

    private static void Main(string[] args)
    {
        serviceProvider = new ServiceCollection().GetServiceCollection().BuildServiceProvider();

        DisplayAllWarehouses();
        DisplayAllCustomers();
        DisplayAllArticles();
        DisplayAllOrders();

    }

    private static void DisplayAllCustomers()
    {
        Console.WriteLine("\r\n=== Customers ===");
        var customers = serviceProvider.GetService<ICustomerService>().GetAllWithOrders().Result;
        foreach (var customer in customers)
        {
            Console.WriteLine($"  ID: {customer.Id}, Name: {customer.Name}, Address: {customer.Address.RoadName}, PostalCode: {customer.Address.PostalCode}");
            customer.Orders.ForEach(x => Console.WriteLine($"      - Order n° {x.Id} : ordered on {x.OrderDate.ToShortDateString()}, status: {x.OrderStatus})"));
        }
    }

    private static void DisplayAllOrders()
    {
        Console.WriteLine("\r\n=== Orders ===");
        var orders = serviceProvider.GetService<IOrderService>().GetAllFullOrders().Result;

        foreach (var order in orders)
        {
            Console.WriteLine($"  ID: {order.Id}, Warehouse: {order.Warehouse.Name}, Customer: {order.Customer.Name}, Address: {order.ShippingAddress.RoadName}, {order.ShippingAddress.PostalCode} {order.ShippingAddress.City}, TotalAmount: {order.TotalAmount}, Status: {order.OrderStatus}");
            order.OrderDetails.ForEach(x => Console.WriteLine($"      - {x.Article.Name} (quantity: {x.Quantity}, unitPrice: {x.UnitPrice})"));
        }
    }

    private static void DisplayAllWarehouses()
    {
        Console.WriteLine("\r\n=== Warehouses ===");
        var warehouses = serviceProvider.GetService<IWarehouseService>().GetAllWarehouses().Result;
        foreach (var warehouse in warehouses)
        {
            Console.WriteLine($"  ID: {warehouse.Id}, Name: {warehouse.Name}, Address: {warehouse.Address.RoadName}, City: {warehouse.Address.PostalCode} {warehouse.Address.City}");
        }
    }

    private static void DisplayAllArticles()
    {
        Console.WriteLine("\r\n=== Articles ===");
        var articles = serviceProvider.GetService<IArticleService>().GetAll().Result;
        foreach (var article in articles)
        {
            Console.WriteLine($"  ID: {article.Id}, Name: {article.Name}, Price: {article.Price}, NbStock: {article.StockQuantity}");
        }
    }
}