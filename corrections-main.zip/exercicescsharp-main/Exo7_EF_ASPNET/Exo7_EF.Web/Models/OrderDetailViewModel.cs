﻿using Microsoft.AspNetCore.Mvc;

namespace Exo7_EF.Web.Models
{
    public class OrderDetailViewModel
    {
        public int DetailId { get; set; }
        public int ArticleId { get; set; }
        public string? ArticleName { get; set; }
        public int Quantity { get; set; }
        public string? UnitPrice { get; set; }

        public bool CanEditQuantity { get; internal set; }

        public int MaxQuantity  { get; internal set; }

        public int OrderId { get; set; }
    }
}