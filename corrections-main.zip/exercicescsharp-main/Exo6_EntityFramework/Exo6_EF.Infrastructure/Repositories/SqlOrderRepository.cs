﻿using Exo6_EF.Core.Interfaces.Infrastructure;
using Exo6_EF.Core.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo6_EF.Infrastructure.Repositories
{
    public class SqlOrderRepository : IOrderRepository
    {
        private readonly ApplicationDbContext context;

        public SqlOrderRepository(ApplicationDbContext context)
        {
            this.context = context;
        }

        public void Add(Order newOrder)
        {

            newOrder.Id = 0;
            newOrder.OrderDetails.ForEach(detail =>
            {
                detail.OrderId = 0;
                detail.ArticleId = 0;
                detail.Id = 0;
            });

            context.Orders.Add(newOrder);
            context.SaveChanges();
        }

        public void Delete(int orderId)
        {
            context.Orders.Remove(context.Orders.First(x => x.Id == orderId));
            context.SaveChanges();
        }

        public IQueryable<Order> GetAll()
        {
            return context.Orders.AsQueryable();
        }

        public void Update(int orderId, Order order)
        {
            context.Orders.Update(order);
            context.SaveChanges();
        }
    }
}
