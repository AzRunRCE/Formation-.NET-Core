﻿using Ardalis.Specification;
using DemoTrip.Core.Dtos;
using DemoTrip.Core.Entities;
using DemoTrip.Core.Interfaces;
using DemoTrip.Core.UseCases;
using DemoTrip.UnitTests.Extensions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoTrip.UnitTests
{
    [TestClass]
    public class BookTripUseCaseTests
    {
        [TestMethod]
        public void BookTrip_Returns_False_And_Zero_When_No_Flight_Found()
        {
            var request = new BookTripRequest("NY", "CDG", DateTime.Today, DateTime.Today.AddDays(2));

            var hotels = new List<Hotel>
            {
                new(){
                    Location="CDG",
                    CheckInDate= DateTime.Today,
                    CheckOutDate=DateTime.Today.AddDays(5)
                }
            };

            var fakeFlightSearch = new Mock<ISearchFlightUseCase>();
            fakeFlightSearch.Setup(x => x.Execute(It.IsAny<SearchFlightRequest>()))
                .ReturnsAsync(new SearchFlightResponse(false, []));

            var fakeHotelSearch = new Mock<ISearchHotelUseCase>();
            fakeHotelSearch.Setup(x => x.Execute(It.IsAny<SearchHotelRequest>()))
            .ReturnsAsync(new SearchHotelResponse(true, hotels));

            var response = new BookTripUseCase(fakeFlightSearch.Object, fakeHotelSearch.Object, new Mock<IReservationNotification>().Object).Execute(request).Result;

            Assert.IsFalse(response.Success);
            Assert.AreEqual(0, response.TotalPrice);
            Assert.AreEqual(string.Empty, response.HotelName);
        }

        [TestMethod]
        public void BookTrip_Returns_False_And_Zero_When_No_Hotel_Found()
        {
            var request = new BookTripRequest("NY", "CDG", DateTime.Today, DateTime.Today.AddDays(2));

            var flights = new List<Flight>
            {
                new(){
                    Origin="NY",
                    Destination="CDG",
                    DepartureTime = DateTime.Today.AddHours(12),
                    ArrivalTime=DateTime.Today.AddHours(20),
                    Price=100}
            };

            var fakeFlightSearch = new Mock<ISearchFlightUseCase>();
            fakeFlightSearch.Setup(x => x.Execute(It.IsAny<SearchFlightRequest>()))
                .ReturnsAsync(new SearchFlightResponse(true, flights));

            var fakeHotelSearch = new Mock<ISearchHotelUseCase>();
            fakeHotelSearch.Setup(x => x.Execute(It.IsAny<SearchHotelRequest>()))
            .ReturnsAsync(new SearchHotelResponse(false, []));

            var response = new BookTripUseCase(fakeFlightSearch.Object, fakeHotelSearch.Object, new Mock<IReservationNotification>().Object).Execute(request).Result;

            Assert.IsFalse(response.Success);
            Assert.AreEqual(0, response.TotalPrice);
            Assert.AreEqual(string.Empty, response.HotelName);
        }

        [TestMethod]
        public void BookTrip_Returns_Total_Trip_Price_And_HostelName_When_Can_Trip()
        {
            var request = new BookTripRequest("NY", "CDG", DateTime.Today, DateTime.Today.AddDays(2));

            var flights = new List<Flight>
            {
                new(){
                    ArrivalTime=DateTime.Today.AddHours(20),
                    Price=100}
            };

            var hotels = new List<Hotel>
            {
                new(){
                    Name="Hotel de Paris",
                    PricePerNight=70}
            };

            var fakeFlightSearch = new Mock<ISearchFlightUseCase>();
            fakeFlightSearch.Setup(x => x.Execute(It.IsAny<SearchFlightRequest>()))
                .ReturnsAsync(new SearchFlightResponse(true, flights));

            var fakeHotelSearch = new Mock<ISearchHotelUseCase>();
            fakeHotelSearch.Setup(x => x.Execute(It.IsAny<SearchHotelRequest>()))
            .ReturnsAsync(new SearchHotelResponse(true, hotels));

            var response = new BookTripUseCase(fakeFlightSearch.Object, fakeHotelSearch.Object, new Mock<IReservationNotification>().Object).Execute(request).Result;

            Assert.IsTrue(response.Success);
            Assert.AreEqual(240, response.TotalPrice);
            Assert.AreEqual(hotels.First().Name, response.HotelName);
        }

        [TestMethod]
        public void BookTrip_Sends_Notification_To_Interface()
        {
            var request = new BookTripRequest("NY", "CDG", DateTime.Today, DateTime.Today.AddDays(2));

            var flights = new List<Flight>
            {
                new(){
                    ArrivalTime=DateTime.Today.AddHours(20),
                    Price=100}
            };

            var hotels = new List<Hotel>
            {
                new(){
                    Name="Hotel de Paris",
                    PricePerNight=70}
            };

            var fakeFlightSearch = new Mock<ISearchFlightUseCase>();
            fakeFlightSearch.Setup(x => x.Execute(It.IsAny<SearchFlightRequest>()))
                .ReturnsAsync(new SearchFlightResponse(true, flights));

            var fakeHotelSearch = new Mock<ISearchHotelUseCase>();
            fakeHotelSearch.Setup(x => x.Execute(It.IsAny<SearchHotelRequest>()))
            .ReturnsAsync(new SearchHotelResponse(true, hotels));

            var fakeNotification = new Mock<IReservationNotification>();

            var response = new BookTripUseCase(fakeFlightSearch.Object, fakeHotelSearch.Object, fakeNotification.Object).Execute(request).Result;

            fakeNotification.Verify(x => x.NotifyTripBooked(It.IsAny<BookTripResponse>()), Times.Once); 
        }
    }
}
