﻿namespace GarageManagementWithDotNetCore
{
    public class SQLVehiculeRepository : IVehiculeRepository
    {
        private readonly ILoggingService _loggingService;

        public SQLVehiculeRepository(ILoggingService loggingService)
        {
            _loggingService = loggingService;
        }
        public void AddVehicule(string Vehicule)
        {
            _loggingService.Log($"Vehicule added: {Vehicule}");
        }
    }
}
