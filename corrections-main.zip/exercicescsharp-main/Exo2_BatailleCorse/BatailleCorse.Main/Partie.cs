﻿using BatailleCorse.Cartes;
using BatailleCorse.ListeChainee;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatailleCorse
{
    public class Partie
    {
        public Anneau<Joueur> joueurs = new Anneau<Joueur>();

        Anneau<Carte> cartesAuCentre = new Anneau<Carte>();

        Joueur joueurActif;
        Carte carteActive;

        Joueur joueurProvoqueEnDuel;
        Carte derniereCarteDuJoueurProvoqueEnDuel = null;

        public void AjouterJoueur(Joueur joueur)
        {
            joueurs.AjouterALaFin(joueur);
            Logger.Log($"Creation d'un joueur : {joueur}");
        }

        public void DistribuerLesCartesAuxJoueurs()
        {
            if (joueurs == null || joueurs.NbElements < 2)
                throw new Exception("Vous devez créer au moins deux joueurs pour distribuer les cartes et lancer une partie");

            Carte[] cartes = JeuDeCarteComplet.GetFreshAndShuffledCards();

            Joueur currentJoueurCachedForPerformance;

            for (int i = 0; i < cartes.Length; i++)
            {
                currentJoueurCachedForPerformance = joueurs.RetirerPremier();
                currentJoueurCachedForPerformance.Cartes.AjouterALaFin(cartes[i]);
                joueurs.AjouterALaFin(currentJoueurCachedForPerformance);
            }

            Logger.Log($"Les cartes sont distribuées aux joueurs.");
        }

        public void Jouer()
        {
            CheckIfThereIsEnoughPlayer();

            while (IsEnoughPlayers())
            {
                // J1 tire une carte
                joueurActif = joueurs.RetirerPremier();

                if(joueurActif.HasCards())
                {
                    Logger.Log($"Début du tour : il reste {joueurs.NbElements + 1} joueurs. Le joueur actif est {joueurActif} et il lui reste {joueurActif.Cartes.NbElements} cartes restantes");

                    carteActive = GetDrawnCardFrom(joueurActif);

                    if (carteActive.IsFigure)
                    {
                        joueurProvoqueEnDuel = joueurs.RetirerPremier();

                        PlayDuelBetweenPlayers();

                        Logger.Log($"Le défi est perdu, {joueurActif} remporte {cartesAuCentre.NbElements} cartes.");

                        GiveCartesAuCentreToActivePlayer();

                        TryToPutPlayerBackInQueue(joueurActif);
                        TryToPutPlayerBackInQueue(joueurProvoqueEnDuel);
                    }
                    else
                    {
                        TryToPutPlayerBackInQueue(joueurActif);
                    }
                }
                else
                {
                    Logger.Log($"{joueurActif} éliminé !");
                }
            }

            PartieTerminee();

        }

        public Joueur GetWinningPlayer()
        {
            if(joueurs.NbElements > 0)
            {
                throw new Exception("Partie has probably not ended because there is still players in queue");
            }
            return joueurActif;
        }

        private Carte GetDrawnCardFrom(Joueur joueur)
        {
            Carte drawnCard = joueur.Cartes.RetirerPremier();
            cartesAuCentre.AjouterALaFin(drawnCard);
            Logger.Log($"{joueur} joue un {drawnCard}");
            return drawnCard;
        }

        private void TryToPutPlayerBackInQueue(Joueur joueur)
        {
            if (joueur.HasCards())
            {
                joueurs.AjouterALaFin(joueur);
            }
            else
            {
                Logger.Log($"{joueur} n'a plus de cartes, il a perdu ! ");
            }
        }

        private void GiveCartesAuCentreToActivePlayer()
        {
            while (cartesAuCentre.NbElements > 0)
            {
                joueurActif.Cartes.AjouterALaFin(cartesAuCentre.RetirerPremier());
            }
        }

        private void PlayDuelBetweenPlayers()
        {
            int nbDeTentatives = carteActive.GetTentativesCountFromCard();

            while (nbDeTentatives > 0)
            {
                if (!joueurProvoqueEnDuel.HasCards())
                {
                    return;
                }

                derniereCarteDuJoueurProvoqueEnDuel = GetDrawnCardFrom(joueurProvoqueEnDuel);

                if (derniereCarteDuJoueurProvoqueEnDuel.IsFigure)
                {
                    ChangeActivePlayerWithDueledAndDuelNextPlayer();
                    nbDeTentatives = carteActive.GetTentativesCountFromCard();
                }
                else
                {
                    nbDeTentatives--;
                }
            }
        }

        private void ChangeActivePlayerWithDueledAndDuelNextPlayer()
        {
            joueurs.AjouterALaFin(joueurActif);
            joueurActif = joueurProvoqueEnDuel;
            joueurProvoqueEnDuel = joueurs.RetirerPremier();
            carteActive = derniereCarteDuJoueurProvoqueEnDuel;
        }

        private void PartieTerminee()
        {
            joueurActif = joueurs.RetirerPremier();
            GiveCartesAuCentreToActivePlayer();
            Logger.Log($"Il ne reste qu'un joueur en jeu, {joueurActif}, il a donc gagné la partie !");
        }

        private bool IsEnoughPlayers()
        {
            return joueurs.NbElements >= 2;
        }

        private void CheckIfThereIsEnoughPlayer()
        {
            if (joueurs == null || joueurs.NbElements < 2)
                throw new Exception("Vous devez créer au moins deux joueurs pour distribuer les cartes et lancer une partie");
        }
    }
}
