﻿using Exercice5.Core.Entities;
using Exercice5.MVC_Web.Models.Validation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;
using System.Configuration;

namespace Exercice5.MVC_Web.Models
{
    public class OrderViewModel
    {
        public int Id { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(100)]
        public string CustomerName { get; set; } = string.Empty;

        [Required(AllowEmptyStrings = false)]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required(AllowEmptyStrings = false)]
        [StringLength(200)]
        public string ShippingAddress { get; set; } = string.Empty;

        [ValidateDate]
        public DateTime? OrderDate { get; set; }

        [ValidateAmount]
        public string? TotalAmount { get; set; }

        [ValidateOrderStatus]
        public OrderStatus? Status { get; set; }

        [ValidateOrderDetail]
        public OrderDetailViewModelList OrderDetails { get; set; } = new OrderDetailViewModelList();
        public int WarehouseId { get; internal set; }
        public SelectList? AvailableArticlesInStock { get; internal set; }
        public bool CanEditQuantity => Status < OrderStatus.Processing;
    }
}
