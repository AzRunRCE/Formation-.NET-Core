﻿using Exo6_EF.Core.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo6_EF.Tests.Entities
{
    [TestClass]
    public class AddressTests
    {
        [TestMethod]
        public void Are_Addresses_Value_Objects()
        {
            var one = new Address("1 Rue Test", 35000, "Rennes");
            var two = new Address("1 Rue Test", 35000, "Rennes");

            Assert.AreEqual(one, two);
        }
    }
}
