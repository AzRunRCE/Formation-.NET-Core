﻿using Exercice5.Core.Entities;
using System.ComponentModel.DataAnnotations;

namespace Exercice5.MVC_Web.Models.Validation
{
    internal class ValidateOrderDetailAttribute : ValidationAttribute
    {
        public ValidateOrderDetailAttribute()
        {
            const string defaultErrorMessage = "Error with Order Detail";
            ErrorMessage ??= defaultErrorMessage;
        }

        protected override ValidationResult? IsValid(object? value,
                                             ValidationContext validationContext)
        {
            if (value == null || string.IsNullOrWhiteSpace(value.ToString()))
            {
                return new ValidationResult("Order Status is required.");
            }

            try
            {
                var detailList = value as List<OrderDetailViewModel>;
                if (detailList != null && detailList.Count != 0 && detailList.Any(x => x.Quantity > 0))
                {
                    return ValidationResult.Success;
                }
                else
                {
                    return new ValidationResult("List of details is empty or has no quantity.");
                }

            }
            catch (Exception)
            {
                return new ValidationResult(
                            FormatErrorMessage(validationContext.DisplayName));
            }

        }
    }
}