﻿$(window).on("load", function () {
    LinkDeleteDetailButtons();
});

function CalculateAndUpdateTotalPrice() {
    var totalPrice = 0.0;
    for (var i = 0; i < $('.articleId').length; i++) {
        totalPrice += GetArticleLinePrice(i);
    }
    $("#TotalAmount").val(totalPrice.toString().replace('.',','));
}

function OnQuantityChanged(event) {
    CalculateAndUpdateTotalPrice();
}

function LinkDeleteDetailButtons() {
    $('.delete-detail').off('click');
    $('.delete-detail').on('click', function (e) {
        e.preventDefault();
        $(e.target).parent().parent().remove();
        CheckAndUpdateBindingIndex();
        CalculateAndUpdateTotalPrice();
    })
}

function AddDetail() {
    var i = $("#DetailList").val();
    fetch('/Order/AddArticleToDetail?articleId=' + i + '&quantity=' + 1 + '&orderId=' + $('#Id').val(),
        {
            method: "POST",
            headers: {
                "RequestVerificationToken": $('input:hidden[name="__RequestVerificationToken"]').val()
            },
        }).then((response) => {
            if (!response.ok) {
                throw new Error(`HTTP error, status = ${response.status}`);
            }
            response.text().then(value => {

                var articleLineAlreadyExist = false;

                $('#detailRowContainer').children().each(function (index, element) {
                    if (AreArticleIdsEquals(element, value)) {
                        var newQuantity = GetArticleQuantity(element) + GetArticleQuantity(value);
                        SetArticleQuantity(element, newQuantity);
                        articleLineAlreadyExist = true;
                        return false;
                    }
                });
                if (!articleLineAlreadyExist) {
                    $('#detailRowContainer').append(value);

                    RebindToModel();

                }

                CalculateAndUpdateTotalPrice();
                LinkDeleteDetailButtons();
            })
        });
}

function AreArticleIdsEquals(first, second) {
    return GetArticleId(first) == GetArticleId(second);
}

function GetArticleId(element) {
    return $(element).children('.articleId').children(".text-box").val();
}
function GetArticleQuantity(element) {
    return parseInt($(element).children('.articleQuantity').children(".text-box").val());
}
function SetArticleQuantity(element, quantity) {
    $(element).children('.articleQuantity').children(".text-box").val(parseFloat(quantity));
}

function SetQuantityInStockErrorOn(element) {
    var quantityIssueSpan = $(element).children('.articleQuantity').children('.text-danger');
    console.log(quantityIssueSpan)
    quantityIssueSpan.removeAttr('hidden');
}
function RemoveQuantityInStockErrorOn(element) {
    var quantityIssueSpan = $(element).children('.articleQuantity').children('.text-danger');
    quantityIssueSpan.attr('hidden', true);
}

function CheckAndUpdateBindingIndex() {
    $('#detailRowContainer').children().each(function (index, element) {
        console.log($(element).children().eq(2).children().attr('id') + " " + index);
        $(element).children().eq(0).children().eq(0).attr('name', GetBindingName(index, 'ArticleId'));
        $(element).children().eq(0).children().eq(0).attr('id', GetBindingId(index, 'ArticleId'));

        $(element).children().eq(1).children().eq(0).attr('name', GetBindingName(index, 'ArticleName'));
        $(element).children().eq(1).children().eq(0).attr('id', GetBindingId(index, 'ArticleName'));

        $(element).children().eq(2).children().eq(0).attr('name', GetBindingName(index, 'Quantity'));
        $(element).children().eq(2).children().eq(0).attr('id', GetBindingId(index, 'Quantity'));
        $(element).children().eq(2).children().eq(1).attr('data-valmsg-for', GetBindingName(index, 'Quantity'));

        $(element).children().eq(3).children().eq(0).attr('name', GetBindingName(index, 'UnitPrice'));
        $(element).children().eq(3).children().eq(0).attr('id', GetBindingId(index, 'UnitPrice'));

        $(element).children().eq(4).children().eq(0).attr('name', GetBindingName(index, 'DetailId'));
        $(element).children().eq(4).children().eq(0).attr('id', GetBindingId(index, 'DetailId'));
        
        $(element).children().eq(4).children().eq(0).attr('name', GetBindingName(index, 'OrderId'));
        $(element).children().eq(4).children().eq(0).attr('id', GetBindingId(index, 'OrderId'));
    });
}

function RebindToModel() {
    let index = ($('.articleId').length - 1);

    ChangeIdAndNameToBindToModel('ArticleId', index);
    ChangeIdAndNameToBindToModel('ArticleName', index);

    BindValidationSpan(index);

    ChangeIdAndNameToBindToModel('Quantity', index);
    ChangeIdAndNameToBindToModel('UnitPrice', index);
    
    ChangeIdAndNameToBindToModel('DetailId', index);
    ChangeIdAndNameToBindToModel('OrderId', index);
}
function BindValidationSpan(index) {
    $('#Quantity').siblings("span").attr('data-valmsg-for', 'OrderDetails[' + index + '].Quantity');
}
function ChangeIdAndNameToBindToModel(targetId, index) {    
    $('#' + targetId).attr('name', GetBindingName(index, targetId));
    $('#' + targetId).attr('id', GetBindingId(index, targetId));
}

function GetBindingName(index, identifier) {
    return 'OrderDetails[' + index + '].' + identifier;
}

function GetBindingId(index, identifier) {
    return 'OrderDetails' + index + '__' + identifier;
}

function GetArticleLinePrice(index) {
    var quantity = parseInt($($('.articleId')[index]).siblings().eq(1).children().val());
    var unitPrice = parseFloat($($('.articleId')[index]).siblings().eq(2).children().val().replace(',', '.'));
    return quantity * unitPrice;
}