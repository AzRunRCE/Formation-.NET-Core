﻿using Ardalis.Specification;
using DemoTrip.Core.Interfaces;
using DemoTrip.Core.UseCases;
using DemoTrip.Web.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DemoTrip.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlightsController(ISearchFlightUseCase useCase) : ControllerBase
    {

        // POST api/<FlightsController>
        [HttpPost("Search")]
        public async Task<IActionResult> Post([FromBody] SearchFlightRequestViewModel value)
        {
            if (ModelState.IsValid)
            {

                var response = await useCase.Execute(new Core.Dtos.SearchFlightRequest(
                    value.Origin!,
                    value.Destination!,
                    value.DateFrom!.Value
                ));

                var responseVm = new SearchFlightResponseViewModel() { Flights = response.Flights };

                if (response.Success)
                    return Ok(responseVm);
                else
                    return NotFound(responseVm);
            }
            else return BadRequest();
        }
    }
}
