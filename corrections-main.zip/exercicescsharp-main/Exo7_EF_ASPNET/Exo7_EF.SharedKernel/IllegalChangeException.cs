﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.SharedKernel
{
    public class IllegalChangeException : Exception
    {
        public IllegalChangeException()
        {
        }

        public IllegalChangeException(string? message) : base(message)
        {
        }

        public IllegalChangeException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        protected IllegalChangeException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
