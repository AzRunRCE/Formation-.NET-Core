﻿using Exo7_EF.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Core.Interfaces.Core
{
    public interface IOrderService
    {
        // Method to add new Order
        Task<Order> Add(Order order);

        // Method to delete an order
        Task Delete(int orderId);

        // Method to fetch all orders made by a specific customer
        Task<List<Order>> GetAllByCustomerId(int customerId);

        // Method to get average order value
        Task<double> GetAverageOrderValue();

        // Method to get average number article by order
        Task<double> GetAverageArticlePerOrder();

        Task<List<Order>> GetAllLightOrders();

        Task<List<Order>> GetAllFullOrders();

        Task<Order> GetFullOrderById(int orderId);
        Task<Order> Update(Order order);

        Task<List<Order>> GetPaginedFullOrdersFromWarehouse(int warehouseId, int numberOfCustomerToGet, int pageNumber);
        Task<List<Order>> GetAllPaginedFullOrders(int numberOfCustomerToGet, int pageNumber);
        Task<int> GetAllOrderCount();
    }
}
