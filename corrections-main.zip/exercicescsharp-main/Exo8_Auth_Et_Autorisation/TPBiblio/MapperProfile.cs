﻿using AutoMapper;
using Core.Dto;
using Core.Entities;
using Web.Models;

namespace Web
{
    public class MapperProfile : Profile
    {
        public MapperProfile() { 
            CreateMap<GetLivreResponse, LivreViewModel>().ReverseMap();
        }
    }
}
