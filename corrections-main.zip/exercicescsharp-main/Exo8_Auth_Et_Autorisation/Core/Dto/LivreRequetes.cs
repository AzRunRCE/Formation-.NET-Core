﻿using Core.Entities;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Dto
{
    public record UpdateContentLivreRequete(int LivreId, string NewContent, IdentityUser User);
    public record DeleteLivreRequete(int LivreId, IdentityUser User);
    public record CreateLivreRequete(string Content, IdentityUser User);
    public record UpdateAcceptationLivreRequete(int LivreId, IdentityUser User, AcceptationStatus AcceptationStatus);
    public record UpdateEmpruntStatusRequete(int LivreId, IdentityUser User, EmpruntStatus EmpruntStatus);

    public record GetLivreResponse(
        int LivreId,
        string Content,
        DateTime CreatedDate,
        AcceptationStatus AcceptationStatus,
        EmpruntStatus EmpruntStatus,
        string UserName
        );

    public record CreatedLivreResponse(int LivreId);

    public record UpdatedLivreResponse(
        int LivreId,
        string Content,
        AcceptationStatus AcceptationStatus, 
        EmpruntStatus EmpruntStatus
        );
}