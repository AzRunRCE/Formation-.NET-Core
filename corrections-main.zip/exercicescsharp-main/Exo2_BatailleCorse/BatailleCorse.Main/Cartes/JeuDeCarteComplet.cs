﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BatailleCorse.Cartes
{
    public class JeuDeCarteComplet
    {
        public static Carte[] GetFreshAndShuffledCards()
        {
            Carte[] jeuCompletMelange = GetFreshCards();

            jeuCompletMelange = ShuffleCardArray(jeuCompletMelange);

            return jeuCompletMelange;
        }

        private static Carte[] ShuffleCardArray(Carte[] originalArray)
        {
            Random rng = new Random();
            for (int i = originalArray.Length - 1; i > 0; i--)
            {
                int j = rng.Next(i + 1);
                Carte temp = originalArray[i];
                originalArray[i] = originalArray[j];
                originalArray[j] = temp;
            }
            return originalArray;
        }

        private static Carte[] GetFreshCards()
        {
            Carte[] jeuComplet = new Carte[32];
            for (int i = 0; i < (int)Couleur.Length; i++)
            {
                for (int j = 0; j < (int)Valeur.Length; j++)
                {
                    jeuComplet[i * (int)Valeur.Length + j] = new Carte((Valeur)j, (Couleur)i);
                }
            }
            return jeuComplet;
        }
    }
}
