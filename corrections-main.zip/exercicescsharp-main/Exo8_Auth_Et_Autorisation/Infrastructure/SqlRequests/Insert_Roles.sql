INSERT INTO [dbo].[AspNetRoles] ([Id], [Name], [NormalizedName], [ConcurrencyStamp])
VALUES (N'1', N'administrator', N'ADMINISTRATOR', NULL);
INSERT INTO [dbo].[AspNetRoles] ([Id], [Name], [NormalizedName], [ConcurrencyStamp])
VALUES (N'2', N'bibliothecaire', N'BIBLIOTHECAIRE', NULL);
INSERT INTO [dbo].[AspNetRoles] ([Id], [Name], [NormalizedName], [ConcurrencyStamp])
VALUES (N'3', N'membre', N'MEMBRE', NULL);