﻿using Exo7_EF.Core.Entities;
using Exo7_EF.Infrastructure.Csv.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TinyCsvParser.Mapping;

namespace Exo7_EF.Infrastructure.Csv.CsvMapping
{
    internal class CsvArticleMapping : CsvReversibleMapping<Article>
    {
        public CsvArticleMapping() : base()
        {
            MapProperty(0, x => x.Id);
            MapProperty(1, x => x.Name);
            MapProperty(2, x => x.Description);
            MapProperty(3, x => x.Price);
            MapProperty(4, x => x.StockQuantity);
        }

        protected override List<object> GetInstanceValues(Article data)
        {
            return [
                data.Id,
                data.Name,
                data.Description,
                data.Price,
                data.StockQuantity,
                ];
        }
    }
}
