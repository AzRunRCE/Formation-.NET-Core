﻿using Ardalis.Specification;
using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Facades;
using Exo7_EF.Core.Interfaces.Core;
using Exo7_EF.Core.Interfaces.Facades;
using Exo7_EF.Core.Interfaces.Infrastructure;
using Exo7_EF.Core.Services;
using Exo7_EF.Infrastructure.Repositories;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Infrastructure
{
    public static class ServiceCollectionExtension
    {
        public static IServiceCollection GetServiceCollection(this IServiceCollection services)
        {
            return services
                .AddScoped<IArticleService, ArticleService>()
                .AddScoped<IOrderService, OrderService>()
                .AddScoped<IWarehouseService, WarehouseService>()
                .AddScoped<ICustomerService, CustomerService>()
                .AddScoped<IOrderSubEntitiesFacade, OrderSubEntitiesFacade>()
                .AddScoped<IStatisticsFacade, StatisticsFacade>()

                .AddScoped(typeof(IRepositoryBase<>), typeof(SqlRepository<>))

                .AddDbContext<ApplicationDbContext>();
        }
    }
}
