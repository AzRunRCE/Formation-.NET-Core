﻿using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Interfaces.Core;
using Exo7_EF.Core.Interfaces.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ardalis.GuardClauses;
using Exo7_EF.SharedKernel;
using Ardalis.Specification;
using Exo7_EF.Core.Specifications;
using Exo7_EF.Core.Interfaces.Facades;

namespace Exo7_EF.Core.Services
{
    public class OrderService : IOrderService
    {
        private readonly IRepositoryBase<Order> orderRepository;
        private readonly IOrderSubEntitiesFacade orderFacade;

        public OrderService(IRepositoryBase<Order> orderRepository, IOrderSubEntitiesFacade orderFacade)
        {
            this.orderRepository = orderRepository;
            this.orderFacade = orderFacade;
        }

        public async Task<Order> Add(Order order)
        {
            Validate(order);

            await orderFacade.RecoverWarehouseCustomerAndArticleFromRepositories(order);

            order.TotalAmount = (double)CalculateOrderTotalAmount(order.OrderDetails);

            await orderRepository.AddAsync(order);

            return order;
        }

        public async Task<Order> Update(Order updatedOrder)
        {
            Validate(updatedOrder);

            var orderBdd = Guard.Against.Null(await orderRepository.FirstOrDefaultAsync(new GetFullOrderById(updatedOrder.Id)));

            CheckForIllegalChanges(updatedOrder, orderBdd);

            await orderFacade.RecoverWarehouseCustomerAndArticleFromRepositories(updatedOrder);

            orderBdd.Customer = updatedOrder.Customer;
            orderBdd.Email = updatedOrder.Email;
            orderBdd.ShippingAddress = updatedOrder.ShippingAddress;
            orderBdd.OrderDate = updatedOrder.OrderDate;
            orderBdd.OrderStatus = updatedOrder.OrderStatus;
            orderBdd.OrderDetails = updatedOrder.OrderDetails;
            orderBdd.Warehouse = updatedOrder.Warehouse;
            orderBdd.TotalAmount = (double)CalculateOrderTotalAmount(orderBdd.OrderDetails);

            await orderRepository.UpdateAsync(orderBdd);

            return updatedOrder;
        }

        public async Task Delete(int orderId)
        {
            var foundOrder = Guard.Against.Null(await orderRepository.GetByIdAsync(orderId));
            await orderRepository.DeleteAsync(foundOrder);
        }

        public async Task<List<Order>> GetAllByCustomerId(int customerId)
        {
            return await orderRepository.ListAsync(new GetAllOrdersFromCustomerId(customerId));
        }

        public async Task<double> GetAverageOrderValue()
        {
            return (await orderRepository.ListAsync(new GetOrderAmounts())).Average();
        }

        public async Task<double> GetAverageArticlePerOrder()
        {
            return (await orderRepository.ListAsync(new GetOrderArticlesCount())).Average();
        }

        public async Task<List<Order>> GetAllLightOrders()
        {
            return await orderRepository.ListAsync();
        }

        public async Task<List<Order>> GetAllFullOrders()
        {
            var orderList = await orderRepository.ListAsync(new GetFullOrders());
            return orderList;
        }

        public async Task<List<Order>> GetPaginedFullOrdersFromWarehouse(int warehouseId, int numberToGet, int pageNumber)
        {
            var orderList = await orderRepository.ListAsync(new GetPaginedFullOrdersFromWarehouse(warehouseId, numberToGet, pageNumber));
            return orderList;
        }

        public async Task<List<Order>> GetAllPaginedFullOrders(int numberToGet, int pageNumber)
        {
            var orderList = await orderRepository.ListAsync(new GetAllPaginedFullOrders(numberToGet, pageNumber));
            return orderList;
        }
        
        public async Task<int> GetAllOrderCount()
        {
            return await orderRepository.CountAsync();
        }

        public async Task<Order> GetFullOrderById(int orderId)
        {
            var order = Guard.Against.Null(await orderRepository.FirstOrDefaultAsync(
                new GetFullOrderById(orderId)));
            return order;
        }


        private void Validate(Order order)
        {
            Guard.Against.NullOrEmpty(order.OrderDetails);
            Guard.Against.Negative(order.TotalAmount);
            Guard.Against.Null(order.ShippingAddress);

            Guard.Against.InvalidInput(order, "Customer or CustomerId", x => !(x.CustomerId == 0 && x.Customer == null));
            Guard.Against.InvalidInput(order, "Warehouse or WarehouseId", x => !(x.WarehouseId == 0 && x.Warehouse == null));

            order.OrderDetails.ForEach((detail) =>
            {
                Guard.Against.InvalidInput(detail, "Article or ArticleId", x => !(x.ArticleId == 0 && x.Article == null));
            });
        }

        private void CheckForIllegalChanges(Order incomingOrder, Order orderInRepo)
        {
            OrderStatus status = Enum.Parse<OrderStatus>(orderInRepo.OrderStatus);

            if (status >= OrderStatus.Processing)
            {
                if (orderInRepo.OrderDetails.Count != incomingOrder.OrderDetails.Count)
                    throw new IllegalChangeException("Cannot change detail when order is processing");
                else
                {
                    for (int i = 0; i < orderInRepo.OrderDetails.Count; i++)
                    {
                        if (orderInRepo.OrderDetails[i].Id != incomingOrder.OrderDetails[i].Id
                            || orderInRepo.OrderDetails[i].ArticleId != incomingOrder.OrderDetails[i].ArticleId
                            || orderInRepo.OrderDetails[i].UnitPrice != incomingOrder.OrderDetails[i].UnitPrice
                            || orderInRepo.OrderDetails[i].Quantity != incomingOrder.OrderDetails[i].Quantity)
                        {
                            throw new IllegalChangeException("Cannot change detail when order is processing");
                        }
                    }
                }
            }

            if (status >= OrderStatus.Shipped && orderInRepo.ShippingAddress != incomingOrder.ShippingAddress)
                throw new IllegalChangeException("Cannot change Shipping address when order is shipped");
        }
        
        private decimal CalculateOrderTotalAmount(List<OrderDetail> orderDetails)
        {
            decimal calculatedOrderTotalAmount = 0;

            foreach (var detail in orderDetails)
            {
                detail.UnitPrice = detail.Article.Price;
                calculatedOrderTotalAmount += detail.Article.Price * detail.Quantity;
            }

            return calculatedOrderTotalAmount;
        }

    }
}
