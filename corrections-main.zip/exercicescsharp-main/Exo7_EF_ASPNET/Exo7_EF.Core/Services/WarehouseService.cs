﻿using Ardalis.GuardClauses;
using Ardalis.Specification;
using Exo7_EF.Core.Entities;
using Exo7_EF.Core.Interfaces.Core;
using Exo7_EF.Core.Interfaces.Infrastructure;
using Exo7_EF.Core.Specifications;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exo7_EF.Core.Services
{
    public class WarehouseService : IWarehouseService
    {
        private readonly IRepositoryBase<Warehouse> warehouseRepository;

        public WarehouseService(IRepositoryBase<Warehouse> warehouseRepository)
        {
            this.warehouseRepository = warehouseRepository;
        }

        public async Task<List<Warehouse>> GetAllWarehouses()
        {
            return await warehouseRepository.ListAsync();
        }

        public async Task<Warehouse> Add(Warehouse warehouse)
        {
            Validate(warehouse);
            await warehouseRepository.AddAsync(warehouse);
            return warehouse;
        }

        public async Task<Warehouse> GetWarehouseById(int warehouseId)
        {
            return await warehouseRepository.FirstOrDefaultAsync(new GetFullWarehouseById(warehouseId));
        }

        private void Validate(Warehouse warehouse)
        {

        }
    }
}
