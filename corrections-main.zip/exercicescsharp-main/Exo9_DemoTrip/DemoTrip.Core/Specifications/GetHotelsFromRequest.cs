﻿using Ardalis.Specification;
using DemoTrip.Core.Dtos;
using DemoTrip.Core.Entities;

namespace DemoTrip.Core.Specifications
{
    internal class GetHotelsFromRequest : Specification<Hotel>
    {
        public GetHotelsFromRequest(SearchHotelRequest request) {
            Query.Where(hotel => hotel.Location== request.Location && hotel.CheckInDate <= request.DateFrom && hotel.CheckOutDate >= request.DateTo);
        }
    }
}